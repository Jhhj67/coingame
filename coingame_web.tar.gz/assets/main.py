import asyncio, sys, traceback
import pygame
import base64
import hashlib
import json
import math
import os
import random


LINES = []
def wrap(text, n=96):
    out = []
    for ln in text.splitlines():
        while len(ln) > n:
            out.append(ln[:n]); ln = ln[n:]
        out.append(ln)
    return out

async def show(title):
    tb = traceback.format_exc()
    print("DEBUG-ERROR", title); print(tb)
    pygame.init()
    scr = pygame.display.set_mode((800, 500))
    try: f = pygame.font.Font("font.ttf", 14)
    except Exception: f = pygame.font.Font(None, 16)
    lines = wrap(title + "\n" + tb)[-30:]
    while True:
        scr.fill((90, 0, 0))
        for i, ln in enumerate(lines):
            scr.blit(f.render(ln, True, (255, 255, 255)), (6, 6 + i * 16))
        pygame.display.flip()
        for e in pygame.event.get(): pass
        await asyncio.sleep(0.1)

async def boot():
    g = {"__name__": "gamemod", "__file__": __file__}
    try:
        src = open("game_main.py", encoding="utf-8").read()
        exec(compile(src, "game_main.py", "exec"), g)
    except BaseException:
        await show("IMPORT/INIT ERROR"); return
    try:
        await g["main"]()
    except BaseException:
        await show("RUNTIME ERROR")

asyncio.run(boot())
