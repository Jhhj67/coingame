import asyncio
import pygame
import sys
import os
import random
import math
import json
import base64
import hashlib

APP_DATA_DIR_NAME = "동전게임"

def save_path(name):
    appdata = os.getenv("APPDATA")
    if not appdata:
        appdata = os.path.join(os.path.expanduser("~"), ".config")
    base = os.path.join(appdata, APP_DATA_DIR_NAME)
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, name)

DIFFICULTIES = ["easy", "normal", "hard", "hell", "hellhell", "hellhellhell", "endless", "adversity", "speedrun"]
REVEALED_DIFFICULTIES = list(DIFFICULTIES)  # 1.5.1: 히든 난이도/모드도 최고기록에 표시
DIFFICULTY_LABELS = {"easy": "쉬움", "normal": "보통", "hard": "어려움", "hell": "지옥", "hellhell": "헬헬",
                      "hellhellhell": "헬헬헬", "endless": "엔드리스", "adversity": "역경", "speedrun": "스피드런"}
DEFAULT_HIGHSCORES = {d: 0 for d in DIFFICULTIES}

def _save_obfuscated(name, data):
    try:
        raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
        with open(save_path(name), "wb") as f:
            f.write(base64.b64encode(raw))
        return True
    except Exception as e:
        print(f"[저장 실패] {name}: {e}")
        return False

def _load_obfuscated(name, default):
    path = save_path(name)
    if not os.path.exists(path):
        return dict(default)
    try:
        with open(path, "rb") as f:
            raw = base64.b64decode(f.read())
        data = json.loads(raw.decode("utf-8"))
        merged = dict(default)
        if isinstance(data, dict):
            merged.update(data)
        return merged
    except Exception as e:
        print(f"[불러오기 실패, 기본값 사용] {name}: {e}")
        return dict(default)

if sys.platform == "emscripten":   # 웹: 파일 대신 브라우저 localStorage에 저장 (같은 브라우저에서만 유지)
    def _ls():
        import platform
        return platform.window.localStorage

    def _save_obfuscated(name, data):
        try:
            raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
            _ls().setItem("coingame_" + name, base64.b64encode(raw).decode("ascii"))
            return True
        except Exception as e:
            print(f"[저장 실패] {name}: {e}")
            return False

    def _load_obfuscated(name, default):
        try:
            v = _ls().getItem("coingame_" + name)
            if v is None or str(v) in ("", "null", "undefined"):
                return dict(default)
            data = json.loads(base64.b64decode(str(v)).decode("utf-8"))
            merged = dict(default)
            if isinstance(data, dict):
                merged.update(data)
            return merged
        except Exception as e:
            print(f"[불러오기 실패, 기본값 사용] {name}: {e}")
            return dict(default)

def load_highscores():
    return _load_obfuscated("highscore.json", DEFAULT_HIGHSCORES)

def save_highscores(scores):
    return _save_obfuscated("highscore.json", scores)

def try_update_highscore(diff, s):
    scores = load_highscores()
    if diff == "speedrun":
        # speedrun: 낮은 시간이 좋음 (새 기록 없거나 기존보다 빠르면 업데이트)
        if s == 0 or scores.get(diff, 0) == 0 or s < scores.get(diff, s):
            scores[diff] = s
            save_highscores(scores)
            return True
    else:
        # 일반 난이도/모드: 높은 점수가 좋음
        if s > scores.get(diff, 0):
            scores[diff] = s
            save_highscores(scores)
            return True
    return False

DEFAULT_SETTINGS = {"volume": 1.0, "bgm_on": True, "fps_limit": 60, "equipped_skin": "normal", "lang": "ko", "twisted_on": True, "anim_on": True, "halloween_on": True, "nick": "", "net_rate": 30}
FPS_OPTIONS = [20, 25, 30, 40, 50, 60]
NET_RATE_OPTIONS = [60, 30, 20, 15]   # 2.4 온라인 전송 횟수(초당, 방장일 때). 60 = 프레임마다

def load_settings():
    return _load_obfuscated("settings.json", DEFAULT_SETTINGS)

def save_settings(s):
    return _save_obfuscated("settings.json", s)

_settings = load_settings()
volume = _settings.get("volume", 1.0)
bgm_on = _settings.get("bgm_on", True)
equipped_skin = _settings.get("equipped_skin", "normal")
lang = _settings.get("lang", "ko")
anim_on = _settings.get("anim_on", True)   # 1.9 코드 애니메이션 효과 사용 여부
twisted_on = _settings.get("twisted_on", True)   # 1.8 신규 콘텐츠(지그재그/분열탄/금색·폭탄 코인) 사용 여부
net_rate = _settings.get("net_rate", 30)   # 2.4 온라인 대결에서 방장이 상태를 보내는 횟수(초당)
if net_rate not in (60, 30, 20, 15): net_rate = 30
halloween_on = _settings.get("halloween_on", True)   # 2.0.2 할로윈 콘텐츠(호박 장애물/보라 배경/트릭 오어 트릿) 사용 여부

# 2.0.2 할로윈 기간 (월, 일) - 이 기간에만 할로윈 콘텐츠가 켜짐. 날짜는 여기서만 바꾸면 됨
HALLOWEEN_START = (10, 24)
HALLOWEEN_END = (10, 31)
BG_HALLOWEEN = (43, 15, 77)
_hp_cache = [0.0, False]   # [마지막 계산 시각, 결과] - 프레임마다 날짜를 읽지 않도록 30초 동안 캐시

def halloween_period():
    import time as _time
    from datetime import datetime
    now = _time.time()
    if _hp_cache[0] == 0.0 or now - _hp_cache[0] > 30:
        d = datetime.now()
        _hp_cache[0] = now
        _hp_cache[1] = HALLOWEEN_START <= (d.month, d.day) <= HALLOWEEN_END
    return _hp_cache[1]

def halloween_now():
    return halloween_on and halloween_period()

# 2.4 1주년 기념 기간 (한국 시간 월, 일) - 날짜는 여기서만 바꾸면 됨
ANNIV_START = (11, 19)
ANNIV_END = (11, 25)
_ap_cache = [0.0, False]

def anniv_now():
    import time as _time
    from datetime import datetime, timedelta, timezone
    now = _time.time()
    if _ap_cache[0] == 0.0 or now - _ap_cache[0] > 30:
        d = datetime.fromtimestamp(now, timezone(timedelta(hours=9)))   # 한국 시간 (UTC+9) 기준
        _ap_cache[0] = now
        _ap_cache[1] = ANNIV_START <= (d.month, d.day) <= ANNIV_END
    return _ap_cache[1]

def bg_color():
    return BG_HALLOWEEN if halloween_now() else DARKBLUE

# 다국어
STRINGS = {
    "title":            {"ko": "동전게임", "en": "Coin Game"},
    "anniv_badge":      {"ko": '기념 칭호 : 1주년 개근 동전', "en": 'Title : 1st Anniversary Regular'},
    "bubble_on":        {"ko": '거품 ○ (재충전 {n})', "en": 'Bubble ON (reloads {n})'},
    "bubble_reload":    {"ko": '거품 {sec}초', "en": 'Bubble {sec}s'},
    "bubble_none":      {"ko": '거품 없음', "en": 'No bubble'},
    "anniv_title":      {"ko": "동전게임 1주년 기념", "en": "Coin Game 1st Anniversary"},
    "anniv_banner":     {"ko": "기념 기간 중 한 판을 클리어하면 꼰대 동전이 해금돼요! (11/19~11/25)", "en": "Clear one round during the event to unlock the Old-Timer Coin! (11/19-11/25)"},
    "start":            {"ko": "게임 시작", "en": "Start Game"},
    "new_feature":      {"ko": "새로운 기능", "en": "What's New"},
    "highscore":        {"ko": "최고기록", "en": "High Scores"},
    "settings":         {"ko": "설정", "en": "Settings"},
    "missions_achv":    {"ko": "미션/업적", "en": "Missions/Achv"},
    "family":           {"ko": "동전 가족", "en": "Coin Family"},
    "back":             {"ko": "뒤로 가기", "en": "Back"},
    "howto": {"ko": '사용 방법', "en": 'How to Play'},
    "history": {"ko": '역사서', "en": 'History'},
    "credits": {"ko": '저작권', "en": 'Credits'},
    "prev": {"ko": '< 이전', "en": '< Prev'},
    "next": {"ko": '다음 >', "en": 'Next >'},
    "howto_p1": {"ko": '[기본 조작]\n방향키 : 상하좌우로 이동\nSpace : 체력 1을 점수 5점으로 바꿉니다\nShift : 점수 5점을 체력 1로 바꿉니다\n\n[목표]\n제한 시간 안에 동전을 최대한 많이 모으세요.\n장애물에 닿으면 체력이 1 줄고, 맞은 직후 0.7초 동안은 무적입니다.\n체력이 0이 되면 게임 오버입니다.', "en": '[Controls]\nArrow keys : move\nSpace : trade 1 HP for 5 points\nShift : trade 5 points for 1 HP\n\n[Goal]\nCollect as many coins as you can before time runs out.\nTouching an obstacle costs 1 HP, then you are invincible for 0.7s.\nWhen HP reaches 0, the game is over.'},
    "howto_p2": {"ko": '[콤보]\n1.5초 안에 코인을 계속 먹으면 콤보가 쌓입니다.\n콤보 6마다 코인 한 개의 점수가 1점씩 올라갑니다.\n\n[특별한 코인] (미션으로 해금)\n황금 코인 : 크게 나타나 3초 뒤 사라지고, 먹으면 5점\n폭탄 코인 : 먹으면 콤보가 초기화되고 자석에도 끌려오지 않음\n\n설정탭의 TWISTED 콘텐츠를 끄면 새 코인과 새 장애물이 나오지 않습니다.', "en": '[Combo]\nKeep collecting coins within 1.5s to build a combo.\nEvery 6 combo adds +1 point to each coin.\n\n[Special coins] (unlocked by missions)\nGold Coin : appears big, vanishes after 3s, worth 5 points\nBomb Coin : resets your combo and is not pulled by the magnet\n\nTurn TWISTED Content OFF in Settings to remove the new coins and obstacles.'},
    "howto_p3": {"ko": '[아이템 1/2]\n자석 : 5초 동안 가까운 코인을 끌어당깁니다\n슬로우 : 5초 동안 장애물, 코인, 아이템이 절반 속도로 느려집니다\n실드 : 장애물 한 번을 막아 줍니다 (여러 개 모을 수 있음)\n회복 : 체력 +1\n김치 : 5초 동안 무적\nL : 16초 동안 장애물이 천천히 플레이어를 따라옵니다 (함정!)\n트릭 오어 트릿 : 할로윈 기간에만 나옵니다. 먹으면 트릿(이득)이나 트릭(함정)이 랜덤으로 걸립니다\n\n남은 시간은 화면 위 아이템 칸의 흰 막이 내려오는 것으로 알 수 있습니다.', "en": '[Items 1/2]\nMagnet : pulls nearby coins for 5s\nSlow : obstacles, coins and items move at half speed for 5s\nShield : blocks one hit (you can hold several)\nHeal : +1 HP\nKimchi : invincible for 5s\nL : for 16s, obstacles slowly home in on you (a trap!)\nTrick or Treat : Halloween only. A random Treat (good) or Trick (bad) takes effect\n\nThe white veil sliding down an item slot at the top shows the time left.'},
    "howto_p4": {"ko": '[아이템 2/2] (미션으로 해금)\n타임프리즈 : 5초 동안 장애물이 멈춥니다\n골드러시 : 5초 동안 코인이 훨씬 많이 나옵니다\n   (골드러시 중에는 자석이 나오지 않고, 먹으면 켜져 있던 자석이 꺼집니다)\n미니미 : 5초 동안 몸이 절반으로 작아져 피하기 쉬워집니다\n되감기 : 충전식. 장애물에 맞을 때 약 1초 전 위치로 돌아가 피해를 피합니다', "en": '[Items 2/2] (unlocked by missions)\nTime Freeze : obstacles stop for 5s\nGold Rush : many more coins appear for 5s\n   (no Magnets spawn during Gold Rush, and picking it up ends an active Magnet)\nMini Me : your body shrinks to half for 5s, making it easier to dodge\nRewind : charge-based. When an obstacle hits you, you jump back about 1s and take no damage'},
    "howto_p5": {"ko": '[난이도]\n쉬움 / 보통 / 어려움 / 지옥 순으로 제한 시간이 짧아지고 장애물이 빠르고 많아집니다.\n헬헬, 헬헬헬은 장애물이 보이지 않습니다. (미션으로 해금)\n\n[모드] (미션으로 해금)\n엔드리스 : 시간 제한 없이 점점 어려워집니다\n역경 : 방향키가 반대로 움직입니다\n스피드런 : 30초 안에 100점을 채우면 걸린 시간이 기록됩니다\n\n[해금]\n미션을 깨면 새 난이도, 모드, 아이템, 장애물이 열립니다.\n업적을 깨면 동전 가족 스킨이 열립니다. 조건은 각 탭에서 확인하세요.\n(숨겨진 스킨도 있습니다)', "en": '[Difficulty]\nFrom Easy / Normal / Hard / Hell the time limit gets shorter and obstacles get faster and more frequent.\nHell² and Hell³ have invisible obstacles. (unlocked by missions)\n\n[Modes] (unlocked by missions)\nEndless : no time limit, it keeps getting harder\nAdversity : the arrow keys are reversed\nSpeedrun : reach 100 points within 30s; your time is recorded\n\n[Unlocks]\nMissions unlock new difficulties, modes, items and obstacles.\nAchievements unlock Coin Family skins. Check each tab for the conditions.\n(There is a hidden skin too)'},
    "history_p1": {"ko": "[탄생]\n2025.11.19  도서관에서 우연히 집은 파이썬 책이 시작이었습니다.\n책 속의 '잠수함 게임'에서 잠수함을 캐릭터로, 공기 방울을 동전으로 바꿔 만들었습니다.\n2025.12.19  학예회에서 첫 공개. 친구들에게 큰 인기를 얻었습니다.\n\n[0.x  초기 버전]\n0.3 장애물 업데이트 / 0.4 새로운 기능 / 0.5 HP 업데이트\n게임의 기본 틀이 하나씩 갖춰졌습니다.", "en": "[Birth]\n2025.11.19  It started with a Python book picked up by chance in the library.\nFrom the book's 'Submarine game', the submarine became a character and the bubbles became coins.\n2025.12.19  First shown at the school talent show, where it was a big hit with friends.\n\n[0.x  Early versions]\n0.3 Obstacles / 0.4 New features / 0.5 HP\nThe basics of the game came together step by step."},
    "history_p2": {"ko": '[1.0 ~ 1.3  자리잡기]\n1.0 ~ 1.2  게임을 다듬으며 pygame 에디션이 갈라져 나왔습니다\n1.3 HALL OF FAME  최고기록 시스템\n1.3.1 PIXEL SHIFT  픽셀 아트 이미지 적용\n1.3.2 BALANCE PATCH  밸런스 조정, 설정 탭, 계급 6단계\n\n[1.4 ~ 1.6  콘텐츠 확장]\n1.4  업적 시스템\n1.4.1  미션 시스템과 동전 가족 스킨\n1.5  숨겨진 난이도 1종과 모드 3종 공개\n1.6  새 아이템 4종 (타임프리즈 / 골드러시 / 미니미 / 되감기)', "en": '[1.0 ~ 1.3  Settling in]\n1.0 ~ 1.2  The game was polished and the pygame edition branched off\n1.3 HALL OF FAME  high score system\n1.3.1 PIXEL SHIFT  pixel art images\n1.3.2 BALANCE PATCH  balance changes, Settings tab, 6 ranks\n\n[1.4 ~ 1.6  More content]\n1.4  achievement system\n1.4.1  missions and Coin Family skins\n1.5  hidden difficulty and 3 hidden modes revealed\n1.6  4 new items (Time Freeze / Gold Rush / Mini Me / Rewind)'},
    "history_p3": {"ko": '[1.7 ~ 1.9  더 풍성하게]\n1.7 COIN FAMILY 2  새 스킨 4종 (누나 / 삼촌 / 반려동전 / 쌍둥이)\n1.8 TWISTED  새 장애물 2종, 새 코인 2종\n1.9 ANIMATED  코드 애니메이션, 아이템 슬롯 표시\n\n[2.0  웹으로]\n웹 브라우저에서도 즐길 수 있게 되었습니다.\n사용 방법, 역사서, 저작권 탭이 생기고 메뉴 버튼이 작아졌습니다.\n\n[2.0.1 ~ 2.0.2  1119, 할로윈]\n숨겨진 스킨, 새 아이템 L, 호박 장애물,\n트릭 오어 트릿, 할로윈 동전이 생겼습니다.', "en": '[1.7 ~ 1.9  Getting richer]\n1.7 COIN FAMILY 2  4 new skins (Sister / Uncle / Pet Coin / Twins)\n1.8 TWISTED  2 new obstacles, 2 new coins\n1.9 ANIMATED  code animations, item slot display\n\n[2.0  To the web]\nNow you can play in a web browser too.\nAdded How to Play, History and Credits tabs, and the menu buttons got smaller.\n\n[2.0.1 ~ 2.0.2  1119, Halloween]\nHidden skin, item L, pumpkin obstacles,\nTrick or Treat and the Halloween Coin were added.'},
    "credits_body": {"ko": '동전게임  {ver}\n\nDeveloped by jhhj67\n\n코드 : Claude (Anthropic)\n이미지 : Gemini (Google)\n배경음악 : Suno\n폰트(웹 버전) : 갈무리14 © Lee Minseo (SIL Open Font License 1.1)\n\nPython 과 pygame 으로 만들었습니다.', "en": 'Coin Game  {ver}\n\nDeveloped by jhhj67\n\nCode : Claude (Anthropic)\nImages : Gemini (Google)\nMusic : Suno\nFont (web version) : Galmuri14 © Lee Minseo (SIL Open Font License 1.1)\n\nMade with Python and pygame.'},
    "new_feature_20": {"ko": '사용 방법 / 역사서 / 저작권 탭 추가,\n메인 메뉴 버튼을 작게 줄여 2줄 8개로 정리', "en": 'Added How to Play / History / Credits tabs,\nshrank the main menu buttons into 2 rows of 4'},
    "new_feature_201": {"ko": '숨겨진 스킨 1종 추가,\n새 아이템 L 추가 (16초 동안 장애물이 따라붙어요)', "en": 'Added 1 hidden skin,\nnew item L (obstacles home in on you for 16s)'},
    "new_feature_202": {"ko": '할로윈 업데이트! 호박 장애물과 보라색 배경,\n새 아이템 트릭 오어 트릿, 새 스킨 1종', "en": 'Halloween update! Pumpkin obstacles and a purple theme,\nnew item Trick or Treat, 1 new skin'},
    "new_feature_21": {"ko": '2인 대결 모드 추가! 한 키보드로 1P(WASD)와\n2P(방향키)가 30초 동안 점수를 겨룹니다', "en": 'Added 2-player Versus! 1P (WASD) and 2P (arrow keys)\ncompete for 30 seconds on one keyboard'},
    "new_feature_24": {"ko": '1주년 기념! 꼰대 동전·잠수함 동전 (11/19~11/25 해금), 온라인 관전,\n랭킹 명예의 전당, 모바일 터치, 친구 고유 동전 3종(코드 해금)\n(로컬 대결은 키보드가 필요해요)', "en": '1st Anniversary! Old-Timer & Submarine Coins (unlock 11/19-11/25),\nonline spectating, Hall of Fame, mobile touch, 3 friend coins (code unlock)\n(Local Versus needs a keyboard)'},
    "howto_p9": {"ko": '[모바일 조작]\n폰/태블릿은 가로로 돌려서 하세요.\n\n왼쪽 화면을 누른 채 밀면 그 자리에\n조이스틱이 생기고, 밀린 방향으로 움직입니다.\n(키보드와 같은 8방향, 속도도 같아요)\n\n오른쪽 버튼 : 체력→점수 / 점수→체력\n개발자/꼰대 동전이면 능력 버튼도 나옵니다.\n\n[참고]\n로컬 대결(한 키보드)은 터치로는 할 수 없고,\n온라인 대결은 터치로도 할 수 있어요.', "en": '[Mobile controls]\nRotate your phone/tablet to landscape.\n\nPress and drag on the left side to get a\njoystick; you move in the dragged direction.\n(Same 8 directions and speed as the keyboard)\n\nRight buttons: HP→Score / Score→HP\nThe Developer / Old-Timer Coin also gets a skill button.\n\n[Note]\nLocal Versus (one keyboard) is not available\non touch; Online Versus works with touch.'},
    "new_feature_23": {"ko": '온라인 랭킹 추가! 최고기록 > 온라인 랭킹에서\n난이도/모드별 Top 10을 볼 수 있습니다 (웹/PC)\n대결에서는 골드러시가 나오지 않습니다', "en": 'Added the Online Ranking! See the Top 10 of each\ndifficulty/mode in High Scores > Online Ranking (web / PC)\nGold Rush no longer appears in Versus'},
    "new_feature_22": {"ko": '온라인 대결 추가! 랜덤매칭이나 방 코드로\n인터넷 친구와 겨룰 수 있습니다 (웹/PC)', "en": 'Added Online Versus! Play a friend over the internet\nby random match or a room code (web / PC)'},
    "local_vs": {"ko": "로컬 대결 (한 키보드)", "en": "Local Versus (one keyboard)"},
    "online_vs": {"ko": "온라인 대결", "en": "Online Versus"},
    "online_title": {"ko": "온라인 대결", "en": "Online Versus"},
    "online_random": {"ko": "랜덤매칭", "en": "Random Match"},
    "online_create": {"ko": "방 만들기", "en": "Create Room"},
    "online_join": {"ko": "방 참가", "en": "Join Room"},
    "online_join_btn": {"ko": "참가", "en": "Join"},
    "online_connecting": {"ko": "서버에 연결하는 중", "en": "Connecting"},
    "online_finding": {"ko": "상대를 찾는 중", "en": "Finding an opponent"},
    "online_cancel": {"ko": "취소", "en": "Cancel"},
    "online_code_label": {"ko": "방 코드", "en": "Room Code"},
    "online_code_hint": {"ko": "영어 키보드 상태에서 입력하세요 (한/영 키)", "en": "Type with the English keyboard"},
    "online_enter_code": {"ko": "방 코드 4글자를 입력하세요", "en": "Enter the 4-character room code"},
    "online_wait_friend": {"ko": "친구가 이 방 코드를 입력하면 시작할 수 있어요", "en": "Your friend can join by entering this room code"},
    "online_opp_wait": {"ko": "상대를 기다리는 중", "en": "Waiting for opponent"},
    "online_you": {"ko": "나", "en": "Me"},
    "online_opp": {"ko": "상대", "en": "Opp"},
    "online_ready": {"ko": "준비", "en": "Ready"},
    "online_unready": {"ko": "준비 취소", "en": "Cancel Ready"},
    "online_leave": {"ko": "나가기", "en": "Leave"},
    "spec_btn": {"ko": "관전하기", "en": "Spectate"},
    "spec_join_title": {"ko": "관전하기", "en": "Spectate"},
    "spec_join_hint": {"ko": "관전할 방의 코드 4글자를 입력하세요 (방당 최대 4명)", "en": "Enter the 4-letter code of the room to watch (max 4 per room)"},
    "spec_wait_title": {"ko": "관전 중", "en": "Spectating"},
    "spec_wait_msg": {"ko": "다음 대결이 시작되기를 기다리는 중...", "en": "Waiting for the next match..."},
    "spec_tag": {"ko": "관전 중  방 {code}", "en": "Spectating  Room {code}"},
    "spec_continue": {"ko": "계속 관전", "en": "Keep Watching"},
    "err_specfull": {"ko": "관전 자리가 가득 찼어요 (최대 4명)", "en": "The spectator seats are full (max 4)"},
    "err_specend": {"ko": "방이 닫혔어요", "en": "The room has closed"},
    "online_controls": {"ko": "이동: WASD 또는 방향키 / 체력→점수: Space / 점수→체력: Shift / 개발자 능력: R 또는 O", "en": "Move: WASD or arrows / HP→points: Space / points→HP: Shift / Dev ability: R or O"},
    "rank_tab_mine":   {"ko": "내 기록", "en": "My records"},
    "rank_tab_online": {"ko": "이번 시즌", "en": "This Season"},
    "rank_tab_hall": {"ko": "명예의 전당", "en": "Hall of Fame"},
    "rank_hall_season": {"ko": "시즌 {n}   ({date})", "en": "Season {n}   ({date})"},
    "rank_hall_empty": {"ko": "아직 마감된 시즌이 없어요", "en": "No season has ended yet"},
    "rank_hall_none": {"ko": "기록 없음", "en": "No records"},
    "rank_updated":    {"ko": "{n}초 전 갱신", "en": "Updated {n}s ago"},
    "rank_loading":    {"ko": "불러오는 중...", "en": "Loading..."},
    "rank_err":        {"ko": "서버에 연결할 수 없어요", "en": "Cannot reach the server"},
    "rank_empty":      {"ko": "아직 기록이 없어요", "en": "No records yet"},
    "rank_nick":       {"ko": "닉네임", "en": "Nickname"},
    "rank_nick_hint":  {"ko": "눌러서 정하기", "en": "Click to set"},
    "rank_sending":    {"ko": "온라인 랭킹에 올리는 중...", "en": "Sending to the online ranking..."},
    "rank_got":        {"ko": "온라인 {n}위!", "en": "Online rank #{n}!"},
    "rank_kept":       {"ko": "온라인에는 더 높은 기록이 있어요", "en": "A better record is already online"},
    "rank_pending":    {"ko": "검토 후 순위에 올라가요", "en": "It will appear after review"},
    "rank_fail":       {"ko": "온라인 랭킹에 올리지 못했어요", "en": "Could not send to the online ranking"},
    "rank_more":       {"ko": "내 순위", "en": "You"},
    "touch_sh":        {"ko": "체력→점수", "en": "HP→Score"},
    "touch_ss":        {"ko": "점수→체력", "en": "Score→HP"},
    "touch_dev":       {"ko": "능력", "en": "Skill"},
    "touch_need_kb":   {"ko": "로컬 대결은 키보드가 필요해요", "en": "Local Versus needs a keyboard"},
    "rank_me_line":    {"ko": "내 순위: {n}위", "en": "Your rank: #{n}"},
    "online_pc_only": {"ko": "이 환경에서는 온라인을 쓸 수 없어요", "en": "Online play is not available here"},
    "online_go_stub": {"ko": "대결 시작! (게임 화면은 다음 단계)", "en": "Match start! (game screen: next step)"},
    "err_closed": {"ko": "서버와 연결이 끊겼어요", "en": "Connection to the server was lost"},
    "err_full": {"ko": "방이 가득 찼어요", "en": "The room is full"},
    "err_nocode": {"ko": "없는 방 코드예요", "en": "That room code does not exist"},
    "err_version": {"ko": "업데이트가 필요해요. 새로고침하세요", "en": "Update needed. Please refresh the page"},
    "err_busy": {"ko": "지금은 방을 만들 수 없어요", "en": "Cannot create a room right now"},
    "err_noconnect": {"ko": "서버에 연결할 수 없어요. 학교 같은 곳은 막혀 있을 수 있어요", "en": "Cannot reach the server. Some networks like schools may block it"},
    "err_left": {"ko": "상대가 나갔어요", "en": "The opponent left"},
    "online_me_tag": {"ko": "(나)", "en": "(Me)"},
    "err_banned": {"ko": "이용이 제한되었어요", "en": "Your access has been restricted"},
    "closed_title":    {"ko": "지금은 게임이 닫혀 있어요", "en": "The game is closed right now"},
    "closed_reopen":   {"ko": "{t}에 열려요", "en": "Opens at {t}"},
    "closed_recheck":  {"ko": "다시 확인", "en": "Check again"},
    "closed_checking": {"ko": "확인하는 중...", "en": "Checking..."},
    "closed_still":    {"ko": "아직 닫혀 있어요", "en": "Still closed"},
    "closed_wait":     {"ko": "잠시 뒤에 다시 눌러 주세요", "en": "Please try again in a moment"},
    "err_gameclosed":  {"ko": "지금은 게임이 닫혀 있어요", "en": "The game is closed right now"},
    "admin_game_close": {"ko": "게임 닫기", "en": "Close Game"},
    "admin_game_open":  {"ko": "게임 열기", "en": "Open Game"},
    "admin_game_default_msg": {"ko": "점검 중이에요", "en": "Under maintenance"},
    "admin_game_on":   {"ko": "게임: 열림", "en": "Game: open"},
    "admin_game_off":  {"ko": "게임: 닫힘", "en": "Game: closed"},
    "err_offline": {"ko": "지금은 온라인이 닫혀 있어요", "en": "Online play is closed right now"},
    "err_kicked": {"ko": "관리자에 의해 나가게 되었어요", "en": "You were removed by the admin"},
    "admin_title": {"ko": "관리자", "en": "Admin"},
    "admin_stats": {"ko": "접속 {a}  대기 {b}  방 {c}  오늘 {d}판  사용량 {e}%", "en": "Online {a}  Waiting {b}  Rooms {c}  Today {d}  Usage {e}%"},
    "admin_open_on": {"ko": "온라인: 열림", "en": "Online: OPEN"},
    "admin_open_off": {"ko": "온라인: 닫힘", "en": "Online: CLOSED"},
    "admin_online_close": {"ko": "온라인 닫기", "en": "Close Online"},
    "admin_online_open": {"ko": "온라인 열기", "en": "Open Online"},
    "admin_end_all": {"ko": "닫고 모두 종료", "en": "Close & End All"},
    "admin_dur": {"ko": "밴 기간: {d}", "en": "Ban: {d}"},
    "admin_dur_10": {"ko": "10분", "en": "10 min"},
    "admin_dur_60": {"ko": "1시간", "en": "1 hour"},
    "admin_dur_1440": {"ko": "1일", "en": "1 day"},
    "admin_dur_0": {"ko": "영구", "en": "Forever"},
    "admin_refresh": {"ko": "새로고침", "en": "Refresh"},
    "admin_tab_players": {"ko": "접속자", "en": "Players"},
    "admin_tab_recent": {"ko": "최근 24시간", "en": "Last 24h"},
    "admin_tab_bans": {"ko": "밴 목록", "en": "Bans"},
    "admin_kick": {"ko": "강퇴", "en": "Kick"},
    "admin_ban": {"ko": "밴", "en": "Ban"},
    "admin_unban": {"ko": "해제", "en": "Unban"},
    "admin_none": {"ko": "없음", "en": "None"},
    "admin_noname": {"ko": "(이름 없음)", "en": "(no name)"},
    "admin_state_lobby": {"ko": "로비", "en": "Lobby"},
    "admin_state_queue": {"ko": "매칭 대기", "en": "Queue"},
    "admin_state_room": {"ko": "방", "en": "Room"},
    "admin_state_play": {"ko": "대결 중", "en": "Playing"},
    "admin_ago_min": {"ko": "{n}분 전", "en": "{n} min ago"},
    "admin_ago_hour": {"ko": "{n}시간 전", "en": "{n} h ago"},
    "admin_done": {"ko": "완료", "en": "Done"},
    "admin_error": {"ko": "서버에 연결하지 못했어요", "en": "Could not reach the server"},
    "admin_expired": {"ko": "관리자 로그인이 끝났어요", "en": "Admin session ended"},
    "admin_exit": {"ko": "나가기", "en": "Exit"},
    "play_type_title": {"ko": "게임 방식", "en": "Play Mode"},
    "single_play": {"ko": "싱글플레이", "en": "Single Player"},
    "multi_play": {"ko": "멀티플레이 (2인 대결)", "en": "Multiplayer (2P Versus)"},
    "vs_title": {"ko": "2인 대결", "en": "2-Player Versus"},
    "vs_nick_hint": {"ko": "닉네임", "en": "Nickname"},
    "vs_controls_1p": {"ko": "1P : 이동 W A S D / 체력→점수 Space / 점수→체력 왼쪽 Shift / 개발자 능력 R", "en": "1P : Move W A S D / HP→points Space / points→HP Left Shift / Dev ability R"},
    "vs_controls_2p": {"ko": "2P : 이동 방향키 / 체력→점수 Enter / 점수→체력 오른쪽 Shift / 개발자 능력 O", "en": "2P : Move arrow keys / HP→points Enter / points→HP Right Shift / Dev ability O"},
    "vs_pick_hint": {"ko": "스킨을 클릭해서 고르세요 (잠긴 스킨은 고를 수 없습니다). 둘 다 준비하면 시작합니다", "en": "Click a skin to pick it (locked skins can't be picked). The match starts when both are ready"},
    "vs_win": {"ko": "{name} 승리!", "en": "{name} wins!"},
    "vs_draw": {"ko": "무승부", "en": "Draw"},
    "vs_dev_cd": {"ko": '{k} : {sec}초', "en": '{k} : {sec}s'},
    "vs_dev_ready": {"ko": '{k} : 준비', "en": '{k} : Ready'},
    "howto_p6": {"ko": '[2인 대결]\n게임 시작 > 멀티플레이. 한 키보드로 둘이 같은 화면에서\n30초 동안 점수를 겨룹니다. 시간이 끝났을 때 점수가 높은 쪽이 이깁니다.\n\n[조작]\n1P : 이동 W A S D, 체력→점수 Space, 점수→체력 왼쪽 Shift\n2P : 이동 방향키, 체력→점수 Enter, 점수→체력 오른쪽 Shift\n개발자 동전 능력 : 1P는 R, 2P는 O\n준비 : 1P는 Q, 2P는 Enter\n\n[규칙]\n코인과 아이템은 먼저 닿는 사람이 가져갑니다.\n체력이 0이 되면 터져서 사라지고, 남은 사람이 계속합니다.\n슬로우, 타임프리즈, 골드러시는 두 사람 모두에게 적용됩니다.\n대결 결과는 기록되지 않습니다.', "en": '[2-Player Versus]\nStart Game > Multiplayer. Two players share one screen and one keyboard\nand compete for 30s. Whoever has more points when time is up wins.\n\n[Controls]\n1P : move W A S D, HP→points Space, points→HP Left Shift\n2P : move arrow keys, HP→points Enter, points→HP Right Shift\nDev Coin ability : R for 1P, O for 2P\nReady : Q for 1P, Enter for 2P\n\n[Rules]\nWhoever touches a coin or item first takes it.\nAt 0 HP you burst and disappear; the other player keeps playing.\nSlow, Time Freeze and Gold Rush affect both players.\nVersus results are not recorded.'},
    "howto_p7": {"ko": '[온라인 대결]\n게임 시작 > 멀티플레이 > 온라인 대결\n랜덤매칭 : 같은 메뉴에서 기다리는 사람과 자동으로 만납니다\n방 만들기 : 4글자 방 코드가 생깁니다. 친구에게 알려 주세요\n방 참가 : 친구의 방 코드를 영어 키보드 상태로 입력합니다\n\n[진행]\n둘 다 준비를 누르면 시작합니다. 30초 동안 점수를 겨루고\n조작은 한 화면 대결과 같습니다. (이동 WASD 또는 방향키)\n끝나면 같은 방에서 바로 한 판 더 할 수 있습니다.\n\n[참고]\n인터넷이 느리면 상대 화면이 조금 늦게 보일 수 있습니다.\n5초 동안 연결이 끊기면 대결이 끝나고,\n온라인 결과도 기록되지 않습니다.', "en": '[Online Versus]\nStart Game > Multiplayer > Online Versus\nRandom Match : automatically meets someone waiting in the same menu\nCreate Room : makes a 4-character room code. Share it with a friend\nJoin Room : type your friend\'s room code with the English keyboard\n\n[Flow]\nThe match starts when both players press Ready. You compete for 30s\nwith the same controls as local Versus. (move with WASD or arrows)\nAfter a match you can play again in the same room.\n\n[Notes]\nOn a slow connection the opponent may look a little delayed.\nThe match ends if the connection is lost for 5 seconds,\nand online results are not recorded either.'},
    "howto_p8": {"ko": '[온라인 랭킹]\n게임 시작 > 최고기록 > 온라인 랭킹\n난이도/모드마다 Top 10과 내 순위를 볼 수 있습니다.\n< > 버튼이나 좌우 방향키로 보드를 바꿉니다.\n\n[기록 올리기]\n서버에 있는 내 기록을 넘으면 자동으로 올라갑니다.\n닉네임은 온라인 랭킹 화면에서 정할 수 있고,\n온라인 대결과 같은 닉네임을 씁니다.\n\n[참고]\n똥쩐꼐임을 쓴 판과 대결 기록은 올라가지 않습니다.\n점수가 너무 높으면 확인 뒤에 올라갈 수 있고,\n이상한 기록은 지워질 수 있습니다.', "en": '[Online Ranking]\nStart Game > High Scores > Online Ranking\nSee the Top 10 and your own rank for each difficulty/mode.\nChange the board with the < > buttons or the arrow keys.\n\n[Submitting]\nA score that beats your online record is sent automatically.\nSet your nickname on the Online Ranking screen;\nit is shared with Online Versus.\n\n[Notes]\nRuns that used the cheat and Versus results are not sent.\nVery high scores may appear after review,\nand suspicious records may be removed.'},
    "history_p4": {"ko": '[2.1  VERSUS]\n한 키보드로 둘이 겨루는 2인 대결 모드가 생겼습니다.\n\n[2.2  ONLINE]\n인터넷으로 겨루는 온라인 대결이 생겼습니다. (웹/PC)\n랜덤매칭이나 방 코드로 친구와 만나고,\n관리자 기능으로 접속 제한도 할 수 있습니다.\n\n[2.3  HALL OF FAME 2]\n난이도/모드별 온라인 랭킹이 생겼습니다.\n\n[2.4  ANNIVERSARY]\n1주년! 새 동전 2종, 관전, 명예의 전당, 모바일 지원.\n\n처음 만든 지 1년, 앞으로도 동전게임은 계속됩니다.', "en": '[2.1  VERSUS]\nA 2-player Versus mode for one keyboard was added.\n\n[2.2  ONLINE]\nOnline Versus over the internet was added (web / PC).\nMeet a friend by random match or room code,\nand an admin tool can restrict access when needed.\n\n[2.3  HALL OF FAME 2]\nOnline rankings for every difficulty/mode were added.\n\n[2.4  ANNIVERSARY]\n1st anniversary: 2 new coins, spectating, Hall of Fame, mobile.\n\nOne year since the beginning, and Coin Game goes on.'},
    "difficulty_title": {"ko": "난이도를 선택하세요", "en": "Select Difficulty"},
    "mode_title":       {"ko": "모드 선택", "en": "Select Mode"},
    "basic_mode":       {"ko": "기본 모드", "en": "Basic Mode"},
    "easy":             {"ko": "쉬움", "en": "Easy"},
    "normal":           {"ko": "보통", "en": "Normal"},
    "hard":             {"ko": "어려움", "en": "Hard"},
    "hell":             {"ko": "지옥", "en": "Hell"},
    "hellhell":         {"ko": "헬헬", "en": "Hell\u00b2"},
    "hellhellhell":     {"ko": "헬헬헬", "en": "Hell\u00b3"},
    "endless":          {"ko": "엔드리스", "en": "Endless"},
    "adversity":        {"ko": "역경", "en": "Adversity"},
    "speedrun":         {"ko": "스피드런", "en": "Speedrun"},
    "settings_title":   {"ko": "설정", "en": "Settings"},
    "volume":           {"ko": "음량", "en": "Volume"},
    "bgm":              {"ko": "BGM", "en": "BGM"},
    "toggle":           {"ko": "전환", "en": "Toggle"},
    "twisted_content":  {"ko": "TWISTED 콘텐츠", "en": "TWISTED Content"},
    "twisted_desc":     {"ko": "끄면 지그재그·분열탄·금색/폭탄 코인이 나오지 않습니다", "en": "When OFF: no Zigzag, Splitter, Gold or Bomb Coins"},
    "equip":            {"ko": "장착", "en": "Equip"},
    "invincible_buff":  {"ko": "무적!", "en": "INVINCIBLE!"},
    "max_frame":        {"ko": "최대 프레임", "en": "Max FPS"},
    "language":         {"ko": "언어", "en": "Language"},
    "achievements":     {"ko": "업적", "en": "Achievements"},
    "missions":         {"ko": "미션", "en": "Missions"},
    "progress_total":   {"ko": "전체 진행", "en": "Overall Progress"},
    "next_goal":        {"ko": "다음 목표", "en": "Next Goal"},
    "hidden_achv":      {"ko": "??? (히든 업적)", "en": "??? (Hidden Achievement)"},
    "item_cat":         {"ko": "아이템", "en": "Item"},
    "mode_cat":         {"ko": "모드", "en": "Mode"},
    "mode_hidden":      {"ko": "??? (조건도 히든)", "en": "??? (condition hidden too)"},
    "current_equip":    {"ko": "현재 장착", "en": "Currently Equipped"},
    "equipped":         {"ko": "(장착중)", "en": "(equipped)"},
    "unlock_cond":      {"ko": "해금 조건", "en": "Unlock"},
    "ability":          {"ko": "능력", "en": "Ability"},
    "game_over":        {"ko": "게임 오버!", "en": "Game Over!"},
    "retry":            {"ko": "다시 하기", "en": "Retry"},
    "to_main":          {"ko": "바탕 화면으로", "en": "To Main Menu"},
    "rank_rookie": {"ko": "하수", "en": "Rookie"},
    "rank_regular": {"ko": "중수", "en": "Regular"},
    "rank_expert": {"ko": "고수", "en": "Expert"},
    "rank_master": {"ko": "초고수", "en": "Master"},
    "rank_pro": {"ko": "동전게임 프로", "en": "Coin Game Pro"},
    "rank_dev": {"ko": "동전게임 개발자", "en": "Coin Game Developer"},
    "cat_입문": {"ko": "입문", "en": "Intro"},
    "cat_콤보": {"ko": "콤보", "en": "Combo"},
    "cat_난이도": {"ko": "난이도", "en": "Difficulty"},
    "cat_점수": {"ko": "점수", "en": "Score"},
    "cat_아이템": {"ko": "아이템", "en": "Item"},
    "cat_히든": {"ko": "히든", "en": "Hidden"},
    "cat_모드": {"ko": "모드", "en": "Mode"},
    "cat_신규": {"ko": "장애물/코인", "en": "Hazards/Coins"},
    "mode_coming_soon": {"ko": "[{name}] 모드는 미션으로 해금하세요!", "en": "[{name}] mode unlocked via mission!"},
    "diff_coming_soon_msg": {"ko": "[{name}] 난이도는 미션으로 해금하세요!", "en": "[{name}] difficulty unlocked via mission!"},
    "new_record_msg": {"ko": "축하합니다! {label} 난이도의 최고기록을 갱신하셨습니다!",
                        "en": "Congrats! New high score for {label} difficulty!"},
    "score_result": {"ko": "{score}점을 기록한 당신은 {rank}입니다", "en": "You scored {score} points — rank: {rank}"},
    "speedrun_done": {"ko": "{sec}초만에 100점 달성!", "en": "Reached 100 points in {sec}s!"},
    "speedrun_fail": {"ko": "100점을 채우지 못하고 쓰러졌습니다 (미완주)", "en": "Fell before reaching 100 points (incomplete)"},
    "speedrun_timeout": {"ko": "30초 안에 100점을 채우지 못했습니다 (시간 초과)", "en": "Didn't reach 100 points within 30s (time over)"},
    "no_record": {"ko": "기록없음", "en": "No record"},
    "sec_unit": {"ko": "초", "en": "s"},
    "achv_unlocked_toast": {"ko": "\U0001F3C6 업적 달성: {name}", "en": "\U0001F3C6 Achievement: {name}"},
    "mission_unlocked_toast": {"ko": "\U0001F381 미션 해금: {name}", "en": "\U0001F381 Mission unlocked: {name}"},
    "achv_progress": {"ko": "달성: {n} / {total}", "en": "Unlocked: {n} / {total}"},
    "unlock_achv_of": {"ko": "'{name}' 업적", "en": "'{name}' achievement"},
    "unlock_label": {"ko": "해금 조건", "en": "Unlock"},
    "no_score": {"ko": "점", "en": " pts"},
    "new_feature_1421": {"ko": "바탕화면 하단에 아이콘 툴바 신설", "en": "Added icon toolbar to the main menu"},
    "new_feature_1411": {"ko": "미션 시스템 + 동전 블로브 가족 스킨(업적 깨면 캐릭터+고유능력 해금)",
                          "en": "New mission system + Coin Blob Family skins (unlock characters + unique abilities via achievements)"},
    "new_feature_1412": {"ko": "모드 선택 화면 신설 - 신규 모드 4종은 1.5에서 공개 예정",
                          "en": "New mode-select screen - 4 new modes coming in 1.5"},
    "new_feature_14":   {"ko": "업적 시스템 신설 - 18종", "en": "New achievement system - 18 achievements"},
    "new_feature_132":  {"ko": "밸런스 조정, 설정 탭, 최고기록 시스템, 픽셀아트 이미지",
                          "en": "Balance tuning, settings tab, high score system, pixel art"},
    "new_feature_15":   {"ko": "4개 신규 콘텐츠 해금: 난이도 1종(헬헬헬), 모드 3종(엔드리스/역경/스피드런)",
                          "en": "4 new contents unlocked: 1 difficulty (Hell³) + 3 modes (Endless/Adversity/Speedrun)"},
    "new_feature_151":  {"ko": "버그수정: 헬헬 난이도 버튼이 엉뚱한 문구를 표시하던 문제 수정, 헬헬헬 난이도 표기 통일",
                          "en": "Bugfix: fixed the Hell² button showing the wrong label, unified the Hell³ name"},
    "new_feature_151d": {"ko": "버그수정: all_clear 업적 자기참조 문제, 게임오버 정독 업적(pygame) 미작동, 히든 난이도/모드 최고기록 미표시, 실드 판정 오류, 게임오버 후 한 프레임 더 진행되던 문제, 연승 기록 미저장, 미션 해금 알림 없음, 오디오 초기화 크래시 위험 수정",
                          "en": "Bugfix: all_clear self-reference, gameover-stare achievement not firing (pygame), hidden difficulty/mode records not shown, shield-use flag set on pickup instead of block, one extra update frame after game over, win-streak not saved across restarts, no mission-unlock toast, audio-init crash risk"},
    "new_feature_151e": {"ko": "버그수정: 역경 모드에 조작키 반전 로직이 빠져 있어서 일반 난이도와 완전히 동일하게 동작하던 문제 수정 (pygame)",
                          "en": "Bugfix: Adversity mode was missing its control-inversion logic and played identically to Normal (pygame)"},
    "new_feature_16":   {"ko": "4개 신규 아이템 추가: 타임프리즈/골드러시/미니미/되감기 (미션으로 해금)",
                          "en": "4 new items added: TimeFreeze/Gold Rush/Mini Me/Rewind (unlocked via missions)"},
    "new_feature_17": {"ko": "동전 가족 4명 추가: 누나(콤보 면역)/삼촌(변덕)/\n반려동전(상시 자석)/쌍둥이(두 몸체 동시 조종),\n스킨 탭에 스킨 이미지 표시(잠금 시 실루엣)",
                     "en": "4 new Coin Family skins: Sister (combo immunity)/Uncle (fickle)/\nPet Coin (passive magnet)/Twins (two bodies at once),\nskin previews in the skin tab (silhouette when locked)"},
    "hud_immune":    {"ko": "면역", "en": "IMMUNE"},
    "item_name_magnet":    {"ko": "자석", "en": "MAGNET"},
    "item_name_slow":      {"ko": "슬로우", "en": "SLOW"},
    "item_name_shield":    {"ko": "실드", "en": "SHIELD"},
    "item_name_heal":      {"ko": "회복 +1", "en": "HEAL +1"},
    "item_name_kimchi":    {"ko": "김치", "en": "KIMCHI"},
    "item_name_timefreeze":{"ko": "타임프리즈", "en": "TIME FREEZE"},
    "item_name_goldrush":  {"ko": "골드러시", "en": "GOLD RUSH"},
    "item_name_minime":    {"ko": "미니미", "en": "MINI ME"},
    "item_name_rewind":    {"ko": "되감기", "en": "REWIND"},
    "item_name_l": {"ko": 'L', "en": 'L'},
    "item_name_bat": {"ko": '빠따', "en": 'Bat'},
    "touch_bat": {"ko": "빠따", "en": "Bat"},
    "code_btn": {"ko": "코드 입력", "en": "Enter Code"},
    "code_prompt": {"ko": "해금 코드를 입력하고 Enter", "en": "Type an unlock code, then Enter"},
    "code_ok": {"ko": "{name} 해금!", "en": "{name} unlocked!"},
    "code_bad": {"ko": "없는 코드입니다", "en": "Invalid code"},
    "code_have": {"ko": "이미 해금한 코드입니다", "en": "Already unlocked"},
    "code_locked": {"ko": "해금 코드를 입력하면 열려요", "en": "Enter an unlock code to open"},
    "item_name_tot": {"ko": '트릭 오어 트릿', "en": 'TRICK OR TREAT'},
    "tot_treat_hp": {"ko": '트릿! 체력 +1', "en": 'TREAT! HP +1'},
    "tot_treat_score": {"ko": '트릿! 점수 +{n}', "en": 'TREAT! Score +{n}'},
    "tot_treat_shield": {"ko": '트릿! 실드 +1', "en": 'TREAT! Shield +1'},
    "tot_trick_fast": {"ko": '트릭! 장애물이 빨라집니다', "en": 'TRICK! Obstacles speed up'},
    "tot_trick_invert": {"ko": '트릭! 방향키가 반대로!', "en": 'TRICK! Controls reversed'},
    "halloween_content": {"ko": '할로윈 테마', "en": 'Halloween Theme'},
    "halloween_desc": {"ko": '끄면 호박 장애물·보라 배경·트릭 오어 트릿이 나오지 않습니다 (기간 한정)', "en": 'When OFF: no pumpkins, purple theme or Trick or Treat (event only)'},
    "dev_ready": {"ko": 'O : 준비', "en": 'O : Ready'},
    "dev_cd": {"ko": 'O : {sec}초', "en": 'O : {sec}s'},
    "fx_combo_reset":      {"ko": "콤보 리셋", "en": "COMBO RESET"},
    "fx_immune":           {"ko": "면역!", "en": "IMMUNE!"},
    "anim_label":          {"ko": "애니메이션", "en": "Animations"},
    "net_rate":            {"ko": "온라인 전송(방장)", "en": "Online send (host)"},
    "net_rate_unit":       {"ko": "회/초", "en": "/sec"},
    "new_feature_19": {"ko": "코드 애니메이션 추가(코인/피격/아이템/분열/콤보/게임오버),\n아이템 효과를 아이콘 슬롯으로 표시(남은 시간은 흰 막이 내려옴),\n설정탭에 애니메이션 ON/OFF 추가",
                     "en": "Added code animations (coin/hit/item/split/combo/game over),\nitem effects shown in icon slots (white veil = time left),\nAnimations ON/OFF in Settings"},
    "new_feature_182": {"ko": "설정탭에 TWISTED 콘텐츠 ON/OFF 추가(끄면 1.7처럼 플레이),\n설정탭 UI 정리, 영어 모드에서 누나 [면역] 표시 번역",
                      "en": "Added TWISTED Content ON/OFF in Settings (OFF = 1.7 style),\nSettings tab layout cleanup, translated Sister's [IMMUNE] HUD"},
    "new_feature_181": {"ko": "밸런스/버그수정: 폭탄 코인 스폰율 절반으로 감소,\n똥쩐꼐임에서 폭탄 코인 제외 + 골드러시 30초 기본 지급,\n아이템 표시를 언어에 맞게 통일(자석 3.2초 / MAGNET ON 3.2s)",
                      "en": "Balance/Bugfix: Bomb Coin spawn rate halved,\nno Bomb Coins in the cheat + 30s Gold Rush by default,\nunified item HUD per language (자석 3.2초 / MAGNET ON 3.2s)"},
    "new_feature_18": {"ko": "새 장애물 2종(지그재그/분열탄), 새 코인 2종\n(황금/폭탄) 추가 - 미션으로 해금,\n밸런스: 골드러시 중에는 자석이 나오지 않고,\n골드러시를 먹으면 자석 효과가 끊김",
                     "en": "2 new obstacles (Zigzag/Splitter), 2 new coins\n(Gold/Bomb) - unlocked via missions,\nBalance: no Magnet spawns during Gold Rush,\npicking up Gold Rush cancels active Magnet"},
    "new_feature_171": {"ko": "버그수정: 창 제목을 '동전게임'으로 통일,\n새 기능 탭의 긴 문장을 줄바꿈해 화면에 다 보이도록 수정",
                      "en": "Bugfix: unified the window title to '동전게임',\nline-wrapped long lines in the What's New tab to fit the screen"},
    "new_feature_161": {"ko": "버그수정: 미션 해금 전에도 엔드리스/역경/스피드런/헬헬헬을\n바로 시작할 수 있던 문제 수정,\nFPS 설정을 바꾸면 게임 전체 속도가 달라지던 문제 수정",
                      "en": "Bugfix: Endless/Adversity/Speedrun/Hell³ could be started before\ntheir unlock mission was met,\noverall game speed no longer changes with the FPS setting"},
    "new_feature_151c": {"ko": "버그수정: 아이템을 먹은 뒤 김치 효과 표시/게임 종료 시 게임이 튕기던 문제 수정",
                          "en": "Bugfix: fixed crash on Kimchi buff display / game over after picking up an item"},
    "new_feature_151b": {"ko": "버그수정: 스피드런 목표 100점으로 복구 + 30초 시간제한 적용, 스피드런 결과/기록 처리 수정, 엔드리스·스피드런 최고기록 표시 추가",
                          "en": "Bugfix: Speedrun goal restored to 100 pts + 30s limit enforced, Speedrun result/record handling fixed, Endless/Speedrun high scores now shown"},
    "new_feature_143a": {"ko": "가족 스킨 밸런스 조정 (엄마/아기/할아버지 고유능력 강화)",
                          "en": "Family skin balance pass (Mom/Baby/Grandpa ability tuning)"},
    "new_feature_143b": {"ko": "가족 스킨별 실드/김치 전용 이미지 8종 추가",
                          "en": "Added 8 skin-specific Shield/Kimchi images for the Coin Family"},
    "new_feature_143c": {"ko": "버그수정: 게임오버 정독 업적이 조기 발동되던 문제 수정",
                          "en": "Bugfix: fixed the gameover-screen achievement triggering too early"},
}

def t(key, **kwargs):
    text = STRINGS.get(key, {}).get(lang, key)
    return text.format(**kwargs) if kwargs else text

def rank_for_score(s):
    if s <= 100: return t("rank_rookie")
    elif s <= 200: return t("rank_regular")
    elif s <= 300: return t("rank_expert")
    elif s <= 400: return t("rank_master")
    elif s <= 500: return t("rank_pro")
    else: return t("rank_dev")

def diff_label(d):
    return t(d)

def cat_label(cat_ko):
    return t(f"cat_{cat_ko}")

def current_settings_dict():
    return {"volume": volume, "bgm_on": bgm_on, "fps_limit": FPS,
            "equipped_skin": equipped_skin, "lang": lang, "twisted_on": twisted_on, "anim_on": anim_on, "halloween_on": halloween_on, "dev_streak": dev_streak, "nick": vs_nick[0], "net_rate": net_rate}

ACHIEVEMENTS = {
    "first_coin":      ({"ko": "아, 이래서 동전게임이구나", "en": "Oh, THAT'S the Point"}, "입문", False),
    "coin_1000":       ({"ko": "적금 만기", "en": "Matured Savings"}, "입문", False),
    "first_hit":       ({"ko": "장애물과 첫 만남", "en": "First Contact"}, "입문", False),
    "combo_20":        ({"ko": "손가락에 모터 달았나", "en": "Got a Motor in Your Fingers?"}, "콤보", False),
    "combo_50":        ({"ko": "이 정도면 재능기부", "en": "Talent, Wasted on Us"}, "콤보", False),
    "combo_100":       ({"ko": "손목보호대 추천드립니다", "en": "Wrist Guard Recommended"}, "콤보", False),
    "clear_hell":      ({"ko": "지옥 관광 후기: 별로였음", "en": "Hell: 2 Stars, Would Not Recommend"}, "난이도", False),
    "clear_hellhell":  ({"ko": "개발자 퇴사각", "en": "Dev's Two Weeks' Notice"}, "난이도", False),
    "no_hit_clear":    ({"ko": "무사고 경력 갱신", "en": "Spotless Record"}, "난이도", False),
    "score_401":       ({"ko": "명함 파도 되겠다", "en": "Business Card Worthy"}, "점수", False),
    "score_501":       ({"ko": "이력서에 한 줄 추가요", "en": "Resume-Worthy"}, "점수", False),
    "score_1119":      ({"ko": '커밋 메시지: 1119', "en": 'Commit Message: 1119'}, "점수", True),   # 2.0.1: 숨겨진 업적 (개발자 동전)
    "dev_streak_3":    ({"ko": "운도 실력이다", "en": "Luck IS a Skill"}, "점수", False),
    "kimchi_100":      ({"ko": "김치냉장고 필요함", "en": "Time for a Kimchi Fridge"}, "아이템", False),
    "tot_10":          ({"ko": '과자 안 주면 장난칠 거야', "en": 'Trick or Treat!'}, "아이템", False),   # 2.0.2: 할로윈 한정 (할로윈 동전)
    "anniv_nohit":     ({"ko": '잠수 타는 중', "en": 'Going Under'}, "난이도", False),   # 2.4: 기념 기간 한정 (잠수함 동전)
    "anniv_clear":     ({"ko": '라떼는 말이야', "en": 'Back in My Day'}, "난이도", False),   # 2.4: 기념 기간 한정 (꼰대 동전)
    "magnet_500":      ({"ko": "자석이 아니라 블랙홀", "en": "Not a Magnet, a Black Hole"}, "아이템", False),
    "shield_3":        ({"ko": "방탄인간", "en": "Bulletproof"}, "아이템", False),
    "fps_changer":     ({"ko": "설정 탭에 뼈를 묻었다", "en": "Buried in the Settings Tab"}, "히든", True),
    "gameover_stare":  ({"ko": "이 정보가 왜 필요하지", "en": "Why Do I Even Need This"}, "히든", True),
    "all_clear":       ({"ko": "모든 업적 달성", "en": "Completionist"}, "히든", True),
}

def ach_name(aid):
    if aid.startswith("code_"): return "???"
    entry = ACHIEVEMENTS.get(aid)
    return entry[0][lang] if entry else aid

def mission_name(mid):
    entry = MISSIONS.get(mid)
    return entry[0][lang] if entry else mid

ACHIEVEMENT_REWARDS = {
    "combo_100": "콘텐츠 언락(신규 아이템) - 1.4.1에서 확정 예정",
    "clear_hellhell": "콘텐츠 언락(신규 난이도/모드) - 1.4.1에서 확정 예정 + 아빠 동전 스킨",
    "no_hit_clear": "아기 동전 스킨",
    "score_501": "엄마 동전 스킨",
    "score_1119": "개발자 동전 스킨 (숨겨진 스킨)",
    "tot_10": "할로윈 동전 스킨",
    "anniv_clear": "꼰대 동전 스킨 (기념 기간 한정)",
    "anniv_nohit": "잠수함 동전 스킨 (기념 기간 한정)",
    "dev_streak_3": "플레이어 이동속도 영구 2배 증가",
    "all_clear": "할아버지 동전 스킨",
}

DEFAULT_ACHIEVEMENTS = {
    "unlocked": {aid: False for aid in ACHIEVEMENTS},
    "counters": {
        "total_coins": 0, "total_hits": 0, "total_kimchi": 0, "total_tot": 0,
        "total_magnet_coins": 0, "dev_streak": 0, "fps_change_count": 0,
    },
}

def load_achievements():
    data = _load_obfuscated("achievements.json", DEFAULT_ACHIEVEMENTS)
    merged_unlocked = dict(DEFAULT_ACHIEVEMENTS["unlocked"]); merged_unlocked.update(data.get("unlocked", {}))
    merged_counters = dict(DEFAULT_ACHIEVEMENTS["counters"]); merged_counters.update(data.get("counters", {}))
    return {"unlocked": merged_unlocked, "counters": merged_counters}

def save_achievements(data):
    return _save_obfuscated("achievements.json", data)

_ach_data = load_achievements()
ach_unlocked = _ach_data["unlocked"]
ach_counters = _ach_data["counters"]
newly_unlocked_queue = []

def unlock_achievement(aid):
    if ach_unlocked.get(aid):
        return False
    ach_unlocked[aid] = True
    newly_unlocked_queue.append(aid)
    save_achievements({"unlocked": ach_unlocked, "counters": ach_counters})
    if not ach_unlocked.get("all_clear") and all(v for k, v in ach_unlocked.items() if k not in ("all_clear", "score_1119", "tot_10", "anniv_clear", "anniv_nohit") and not k.startswith("code_")):
        unlock_achievement("all_clear")
    return True

def add_counter(name, amount=1):
    ach_counters[name] = ach_counters.get(name, 0) + amount
    return ach_counters[name]

def flush_achievements():
    save_achievements({"unlocked": ach_unlocked, "counters": ach_counters})

CATEGORY_ORDER = ["입문", "콤보", "난이도", "점수", "아이템", "히든"]

MISSIONS = {
    "unlock_timefreeze":   ({"ko": "타임프리즈", "en": "TimeFreeze"}, "아이템",
                             {"ko": "누적 장애물 회피 300회", "en": "Dodge 300 obstacles (lifetime)"}),
    "unlock_goldrush":     ({"ko": "골드러시", "en": "Gold Rush"}, "아이템",
                             {"ko": "누적 코인 5,000개", "en": "Collect 5,000 coins (lifetime)"}),
    "unlock_minime":       ({"ko": "미니미", "en": "Mini Me"}, "아이템",
                             {"ko": "쉬움 난이도 10회 클리어", "en": "Clear Easy difficulty 10 times"}),
    "unlock_rewind":       ({"ko": "되감기", "en": "Rewind"}, "아이템",
                             {"ko": "실드 없이 지옥 난이도 클리어", "en": "Clear Hell difficulty without using a Shield"}),
    "unlock_endless":      ({"ko": "엔드리스 모드", "en": "Endless Mode"}, "모드",
                             {"ko": "누적 플레이 20판", "en": "Play 20 rounds (lifetime)"}),
    "unlock_hellhellhell": ({"ko": "헬헬헬", "en": "Hell\u00b3"}, "모드",
                             {"ko": "헬헬 난이도에서 300점 이상", "en": "Score 300+ on Hell\u00b2 difficulty"}),
    "unlock_adversity":    ({"ko": "역경 모드", "en": "Adversity Mode"}, "모드",
                             {"ko": "김치 없이 지옥 난이도 클리어", "en": "Clear Hell difficulty without using Kimchi"}),
    "unlock_speedrun":     ({"ko": "스피드런 모드", "en": "Speedrun Mode"}, "모드",
                             {"ko": "30초 안에 1000점 달성", "en": "Reach 1000 points within 30 seconds"}),
    # 1.8 신규 장애물/코인
    "unlock_zigzag":       ({"ko": "지그재그", "en": "Zigzag"}, "신규",
                             {"ko": "보통 난이도 10회 클리어", "en": "Clear Normal difficulty 10 times"}),
    "unlock_split":        ({"ko": "분열탄", "en": "Splitter"}, "신규",
                             {"ko": "어려움 난이도 클리어", "en": "Clear Hard difficulty"}),
    "unlock_goldcoin":     ({"ko": "황금 코인", "en": "Gold Coin"}, "신규",
                             {"ko": "콤보 30 달성", "en": "Reach a 30 combo"}),
    "unlock_bombcoin":     ({"ko": "폭탄 코인", "en": "Bomb Coin"}, "신규",
                             {"ko": "콤보 50 달성", "en": "Reach a 50 combo"}),
}

MISSION_CATEGORY_ORDER = ["아이템", "모드", "신규"]
DEFAULT_MISSIONS = {
    "unlocked": {mid: False for mid in MISSIONS},
    "counters": {"total_obstacles_dodged": 0, "easy_clear_count": 0, "endless_play_count": 0, "normal_clear_count": 0},
}

def load_missions():
    data = _load_obfuscated("missions.json", DEFAULT_MISSIONS)
    merged_unlocked = dict(DEFAULT_MISSIONS["unlocked"]); merged_unlocked.update(data.get("unlocked", {}))
    merged_counters = dict(DEFAULT_MISSIONS["counters"]); merged_counters.update(data.get("counters", {}))
    return {"unlocked": merged_unlocked, "counters": merged_counters}

def save_missions(data):
    return _save_obfuscated("missions.json", data)

_mission_data = load_missions()
mission_unlocked = _mission_data["unlocked"]
mission_counters = _mission_data["counters"]
newly_unlocked_mission_queue = []

def unlock_mission(mid):
    if mission_unlocked.get(mid):
        return False
    mission_unlocked[mid] = True
    newly_unlocked_mission_queue.append(mid)
    save_missions({"unlocked": mission_unlocked, "counters": mission_counters})
    return True

def add_mission_counter(name, amount=1):
    mission_counters[name] = mission_counters.get(name, 0) + amount
    return mission_counters[name]

def flush_missions():
    save_missions({"unlocked": mission_unlocked, "counters": mission_counters})

SKIN_MAP = {
    "normal":  {"image_key": "p_normal",  "label": {"ko": "기본", "en": "Default"}, "unlock": None,
                "ability": {"ko": "-", "en": "-"}},
    "dad":     {"image_key": "p_dad",     "label": {"ko": "아빠 동전", "en": "Dad Coin"}, "unlock": "clear_hellhell",
                "ability": {"ko": "최대 HP +1", "en": "Max HP +1"}},
    "mom":     {"image_key": "p_mom",     "label": {"ko": "엄마 동전", "en": "Mom Coin"}, "unlock": "score_501",
                "ability": {"ko": "콤보 유지시간 +0.5초, 보너스 주기 6→5개",
                            "en": "Combo window +0.5s, bonus interval 6→5"}},
    "baby":    {"image_key": "p_baby",    "label": {"ko": "아기 동전", "en": "Baby Coin"}, "unlock": "no_hit_clear",
                "ability": {"ko": "충돌판정 축소 + 이동속도 +10%", "en": "Smaller hitbox + move speed +10%"}},
    "grandpa": {"image_key": "p_grandpa", "label": {"ko": "할아버지 동전", "en": "Grandpa Coin"}, "unlock": "all_clear",
                "ability": {"ko": "이동속도 -10%, 시작 실드 3개, 아이템 지속 7.5초, 자석 사거리 1.5배",
                            "en": "Move speed -10%, starts with 3 Shields, item duration 7.5s, magnet range x1.5"}},
    "sister":  {"image_key": "p_sister",  "label": {"ko": "누나 동전", "en": "Sister Coin"}, "unlock": "combo_50",
                "ability": {"ko": "콤보가 끊겨도 라운드당 5회 면역", "en": "Combo break immunity x5 per round"}},
    "uncle":   {"image_key": "p_uncle",   "label": {"ko": "삼촌 동전", "en": "Uncle Coin"}, "unlock": "clear_hell",
                "ability": {"ko": "장애물 충돌 50% 무시, 이동속도 x0.7~1.3 변동",
                            "en": "50% chance to ignore obstacle hits, move speed varies x0.7~1.3"}},
    "puppy":   {"image_key": "p_puppy",   "label": {"ko": "반려동전", "en": "Pet Coin"}, "unlock": "magnet_500",
                "ability": {"ko": "상시 약한 자동 자석 (자석 사거리 절반)", "en": "Always-on weak magnet (half range)"}},
    "twins":   {"image_key": "p_twins",   "preview_key": "p_twins_pair",
                "label": {"ko": "쌍둥이 동전", "en": "Twins Coin"}, "unlock": "combo_100",
                "ability": {"ko": "두 몸체를 100px 간격으로 동시 조종 (HP 공유)", "en": "Control two bodies 100px apart at once (shared HP)"}},
    "halloween": {"image_key": "p_halloween", "label": {"ko": '할로윈 동전', "en": 'Halloween Coin'}, "unlock": "tot_10",
                "ability": {"ko": '시작할 때 실드 1개 + 트릭 오어 트릿에서 트릿 확률 75% (기본 50%)', "en": 'Start with 1 shield + Treat chance 75% in Trick or Treat (default 50%)'}},
    "submarine": {"image_key": "p_submarine", "label": {"ko": '잠수함 동전', "en": 'Submarine Coin'}, "unlock": "anniv_nohit",
                "ability": {"ko": '시작할 때 거품 방패 1개, 터지면 2초 뒤 다시 생김 (한 판에 최대 3번)', "en": '1 bubble shield; re-forms 2s after popping (max 3x)'}},
    "kkondae": {"image_key": "p_kkondae", "label": {"ko": '꼰대 동전', "en": 'Old-Timer Coin'}, "unlock": "anniv_clear",
                "ability": {"ko": 'O 키 : 10초간 반경 300px 장애물 밀어내기 (쿨타임 25초)', "en": 'O: push obstacles within 300px for 10s (25s cooldown)'}},
    "siyoon": {"image_key": "p_siyoon", "code": True, "label": {"ko": '박시윤 동전', "en": 'Siyoon Coin'}, "unlock": "code_siyoon",
                "ability": {"ko": 'O 키 : 빠따로 반경 120px 장애물 삭제 + 상대 타격 (쿨타임 2.5초)', "en": 'O: bat clears obstacles in 120px, hits rivals (2.5s)'}},
    "yoonjae": {"image_key": "p_yoonjae", "code": True, "label": {"ko": '정윤재 동전', "en": 'Yoonjae Coin'}, "unlock": "code_yoonjae",
                "ability": {"ko": 'O 키 : 샨셴부(1초 회피) / 랑게티치오 25% / 룽둥 쾅 25% (쿨 1.5초)', "en": 'O: dodge 1s / fling 25% / L effect 25% (1.5s)'}},
    "yoonchae": {"image_key": "p_yoonchae", "code": True, "label": {"ko": '송윤채 동전', "en": 'Yoonchae Coin'}, "unlock": "code_yoonchae",
                "ability": {"ko": '장애물/빠따 피격을 75% 확률로 무시합니다', "en": '75% chance to ignore obstacle and bat hits'}},
    "devcoin": {"image_key": "p_devcoin", "label": {"ko": '개발자 동전', "en": 'Developer Coin'}, "unlock": "score_1119",
                "ability": {"ko": 'O 키 : 반경 300px 안의 장애물을 모두 지웁니다 (쿨타임 1초)', "en": 'Press O : clear all obstacles within 300px (1s cooldown)'}},
}
SKIN_ORDER = ["normal", "dad", "mom", "baby", "grandpa", "sister", "uncle", "puppy", "twins", "halloween", "kkondae", "submarine", "siyoon", "yoonjae", "yoonchae", "devcoin"]
HIDDEN_SKIN = "devcoin"   # 2.0.1: 해금 전에는 이름/조건을 ???로 숨김
# 2.0.2 트릭 오어 트릿: 할로윈 기간에만 등장. 먹으면 트릿(이득) 또는 트릭(함정)이 랜덤으로 걸림
TOT_TREAT_CHANCE = 0.5           # 트릿이 나올 확률 (할로윈 동전 스킨은 TOT_TREAT_CHANCE_SKIN)
TOT_TREAT_CHANCE_SKIN = 0.75
TOT_UNLOCK_COUNT = 5             # 누적 이만큼 먹으면 할로윈 동전 해금
TOT_TREATS = ["hp", "score", "shield"]
TOT_TREAT_SCORE = 30
TOT_TRICKS = ["fast", "invert"]
TOT_TRICK_MS = 5000
TOT_FAST_MULT = 1.5              # 트릭: 장애물 속도 배율
TOT_MSG_MS = 2500                # 트릿 메시지 표시 시간
# 2.0.1 L 아이템: 먹으면 L_DURATION_MS 동안 자막 8줄(줄당 L_LINE_MS)이 나오고, 장애물이 천천히 플레이어를 따라옴
L_DURATION_MS = 16000
L_LINE_MS = 2000
L_TURN_DEG = 40   # 장애물이 방향을 틀 수 있는 최대 각속도(도/초). 속도는 그대로, 방향만 서서히 틀어짐
L_CAPTIONS = ['L을 가져가', '크림치즈 허니', 'L을 가져가', '크리스 크로스', 'L을 가져가', '야채', 'L을 가져가', '셀~카!']
# 2.0.1 개발자 동전: O 키로 반경 DEV_CLEAR_RADIUS px 안의 장애물 삭제
DEV_CLEAR_RADIUS = 300
DEV_COOLDOWN_MS = 1000
# 2.4 꼰대 동전: O 키로 10초 동안 자막 5줄(줄당 2초) + 반경 300px 안의 장애물이 밀려남. 쿨타임은 발동 시점부터 25초
KK_DURATION_MS = 10000
KK_LINE_MS = 2000
KK_COOLDOWN_MS = 25000
KK_RADIUS = 300
KK_PUSH_SPD = 7.0   # 60fps 기준 프레임당 밀려나는 거리(px)
# 2.4 잠수함 동전: 시작할 때 거품 방패 1개. 거품이 터지면 2초 뒤 다시 생기고 (한 판에 최대 3번), 실드 아이템이 있으면 그것부터 씀
BUBBLE_RELOAD_MS = 2000
BUBBLE_MAX_RELOADS = 3
KK_CAPTIONS = ['라떼는 말이야...', '장기자랑 때는 노트북 한 대로 시작했어.', '그땐 코인 하나 먹는 것도 큰일이었어.', 'HP가 어딨어, 한 방이었다고!', '요즘 것들은 콤보도 쉽게 올리지.']

# 2.4 친구 고유 동전 (해금 코드로 열림. 코드는 해시만 저장: tools/make_code_hash.py 로 만듦)
CODE_SALT = "coingame24|"
CUSTOM_CODE_HASH = {
    "siyoon": "78e6632334718a196d3cc53f299aacaa06bb720067b9cf1300a4e04be0b955fc",
    "yoonjae": "5b524f50a0ec564fc3c52058b17efc1e97708d1b12d4aecf9e9691468468b757",
    "yoonchae": "e38725ab14f0bf41720f35250563c504799a2c67835504af5d35a3f96515824e",
}
BAT_RADIUS = 120
SIYOON_COOLDOWN_MS = 2500
BAT_ITEM_USES = 3          # 빠따 아이템: 먹으면 I 키로 3번
BAT_ITEM_COOLDOWN_MS = 800
YJ_COOLDOWN_MS = 1500
YJ_DODGE_MS = 1000
YJ_FLING_RADIUS = 300
YJ_P_DODGE, YJ_P_FLING = 0.5, 0.25   # 나머지 0.25는 룽둥 쾅 (L 효과)
YC_IGNORE_CHANCE = 0.75
CAST_TEXT = {1: {"ko": "샨셴부!", "en": "Shanxianbu!"}, 2: {"ko": "랑게티치오!", "en": "Langetichio!"},
             3: {"ko": "룽둥 쾅 룽둥 쾅 룽둥 룽둥 룽둥 쾅", "en": "Rungdung KWANG x4"}, 4: {"ko": "빠따!", "en": "Bat!"}}
CAST_MS = {1: 1200, 2: 1200, 3: 3000, 4: 900}
code_edit = False; code_buf = ""; code_msg = ""; code_msg_until = 0

def code_hash(text):
    return hashlib.sha256((CODE_SALT + text.strip().lower()).encode("utf-8")).hexdigest()

def try_unlock_code(text):
    """입력한 코드가 맞으면 해당 스킨을 해금. 돌려주는 값: 스킨 id / None"""
    hh = code_hash(text)
    for sid, ch in CUSTOM_CODE_HASH.items():
        if hh == ch: return sid
    return None

def hit_ignore_chance(sk):
    if sk == "uncle": return UNCLE_IGNORE_CHANCE
    if sk == "yoonchae": return YC_IGNORE_CHANCE
    return 0.0

# 1.7 신규 스킨 수치
SISTER_IMMUNITY = 5            # 누나: 라운드당 콤보 끊김 면역 횟수
UNCLE_IGNORE_CHANCE = 0.5      # 삼촌: 장애물 충돌 무시 확률
UNCLE_SPEED_RANGE = (0.7, 1.3) # 삼촌: 이동속도 변동 범위
UNCLE_ROLL_MS = 2000           # 삼촌: 속도 재추첨 주기
PUPPY_MAGNET_RATIO = 0.5       # 반려동전: 상시 자석 사거리 비율
TWIN_GAP = 100                 # 쌍둥이: 두 몸체 가로 간격(px)
uncle_speed_mult = 1.0
uncle_roll_at = 0

def is_skin_unlocked(skin_id):
    req = SKIN_MAP[skin_id]["unlock"]
    return req is None or ach_unlocked.get(req, False)

def eff_player_r():
    r = PLAYER_R - 3 if equipped_skin == "baby" else PLAYER_R
    if player.minime_active:
        r = r / 2
    return r

def eff_combo_window_ms():
    return COMBO_WINDOW_MS + 500 if equipped_skin == "mom" else COMBO_WINDOW_MS

def eff_combo_bonus_step():
    return 5 if equipped_skin == "mom" else COMBO_BONUS_STEP

def eff_move_speed(base_spd):
    if equipped_skin == "uncle": return base_spd * uncle_speed_mult
    if equipped_skin == "baby": return base_spd * 1.10
    if equipped_skin == "grandpa": return base_spd * 0.90
    return base_spd

def eff_item_duration_ms(base_ms):
    return base_ms * 1.5 if equipped_skin == "grandpa" else base_ms

def eff_magnet_range():
    if cheat_on:
        return CHEAT_MAGNET_RANGE
    return MAGNET_RANGE * 1.5 if equipped_skin == "grandpa" else MAGNET_RANGE

os.environ.setdefault("SDL_IME_SHOW_UI", "1")
pygame.init()
try:
    pygame.mixer.init()
except Exception as e:
    print(f"[오디오 초기화 실패, 소리 없이 진행합니다] {e}")

WIDTH, HEIGHT = 800, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("동전게임")
clock = pygame.time.Clock()
FPS = _settings.get("fps_limit", 60)
REFERENCE_FPS = 60  # 이동/스폰 속도의 기준 FPS - FPS 설정을 바꿔도 체감 속도가 그대로이도록 고정 기준점 사용

DARKBLUE = (0, 0, 139)
WHITE = (255, 255, 255)
RED = (255, 50, 50)
ORANGE = (255, 140, 0)
YELLOW = (255, 230, 0)
CYAN = (0, 240, 240)
GRAY = (200, 200, 200)
PURPLE = (170, 90, 220)
PINK = (255, 180, 190)
BLACK = (0, 0, 0)

FONT_FILE = "font.ttf"   # 웹: 브라우저에는 gulim이 없어서 폰트 파일을 같이 올림
font_large = pygame.font.Font(FONT_FILE, 40)
font_mid = pygame.font.Font(FONT_FILE, 22)
font_small = pygame.font.Font(FONT_FILE, 16)
font_buff = pygame.font.Font(FONT_FILE, 13)

def draw_text_center(surface, font, text, color, pos):
    txt = font.render(text, True, color)
    surface.blit(txt, txt.get_rect(center=pos))

ASSET_SPECS = {
    "p_normal":    ("player_normal.png", (30, 30)),
    "p_shield":    ("player_shield.png", (30, 30)),
    "p_kimchi":    ("player_kimchi.png", (30, 30)),
    "coin":        ("coin.png", (30, 30)),
    "obstacle":    ("obstacle.png", (20, 20)),
    "item_magnet": ("item_magnet.png", (24, 24)),
    "item_slow":   ("item_slow.png", (24, 24)),
    "item_shield": ("item_shield.png", (24, 24)),
    "item_heal":   ("item_heal.png", (24, 24)),
    "item_kimchi": ("item_kimchi.png", (24, 24)),
    "item_timefreeze": ("item_timefreeze.png", (24, 24)),  # 1.6
    "item_goldrush": ("item_goldrush.png", (24, 24)),  # 1.6
    "item_minime": ("item_minime.png", (24, 24)),  # 1.6
    "item_rewind": ("item_rewind.png", (24, 24)),  # 1.6
    "p_dad":     ("player_dad.png", (30, 30)),
    "p_mom":     ("player_mom.png", (30, 30)),
    "p_baby":    ("player_baby.png", (30, 30)),
    "p_grandpa": ("player_grandpa.png", (30, 30)),
    "p_dad_shield":     ("player_dad_shield.png", (30, 30)),
    "p_dad_kimchi":     ("player_dad_kimchi.png", (30, 30)),
    "p_mom_shield":     ("player_mom_shield.png", (30, 30)),
    "p_mom_kimchi":     ("player_mom_kimchi.png", (30, 30)),
    "p_baby_shield":    ("player_baby_shield.png", (30, 30)),
    "p_baby_kimchi":    ("player_baby_kimchi.png", (30, 30)),
    "p_grandpa_shield": ("player_grandpa_shield.png", (30, 30)),
    "p_grandpa_kimchi": ("player_grandpa_kimchi.png", (30, 30)),
    "p_sister":     ("player_sister.png", (30, 30)),
    "p_sister_shield":     ("player_sister_shield.png", (30, 30)),
    "p_sister_kimchi":     ("player_sister_kimchi.png", (30, 30)),
    "p_uncle":     ("player_uncle.png", (30, 30)),
    "p_uncle_shield":     ("player_uncle_shield.png", (30, 30)),
    "p_uncle_kimchi":     ("player_uncle_kimchi.png", (30, 30)),
    "p_puppy":     ("player_puppy.png", (30, 30)),
    "p_puppy_shield":     ("player_puppy_shield.png", (30, 30)),
    "p_puppy_kimchi":     ("player_puppy_kimchi.png", (30, 30)),
    "p_twins":     ("player_twins.png", (30, 30)),
    "p_twins_shield":     ("player_twins_shield.png", (30, 30)),
    "p_twins_kimchi":     ("player_twins_kimchi.png", (30, 30)),
    "p_twins_pair":     ("player_twins_pair.png", (34, 34)),  # 스킨 탭 미리보기용 (두 코인이 붙은 그림)
    "icon_settings":  ("icon_settings.png", (24, 24)),   # 2.0: 메인 메뉴 아이콘 소형화(32→24)
    "icon_highscore": ("icon_highscore.png", (24, 24)),
    "icon_missions":  ("icon_missions.png", (24, 24)),
    "icon_family":    ("icon_family.png", (24, 24)),
    "icon_new":       ("icon_new.png", (24, 24)),
    "icon_howto":     ("icon_howto.png", (24, 24)),
    "icon_history":   ("icon_history.png", (24, 24)),
    "icon_credits":   ("icon_credits.png", (24, 24)),
    "p_kkondae":        ("player_kkondae.png", (30, 30)),   # 2.4
    "p_kkondae_shield": ("player_kkondae_shield.png", (30, 30)),
    "p_kkondae_kimchi": ("player_kkondae_kimchi.png", (30, 30)),
    "p_submarine":        ("player_submarine.png", (30, 30)),   # 2.4
    "p_submarine_shield": ("player_submarine_shield.png", (30, 30)),
    "p_submarine_kimchi": ("player_submarine_kimchi.png", (30, 30)),
    "p_devcoin":        ("player_devcoin.png", (30, 30)),   # 2.0.1
    "p_devcoin_shield": ("player_devcoin_shield.png", (30, 30)),
    "p_devcoin_kimchi": ("player_devcoin_kimchi.png", (30, 30)),
    "item_l":           ("item_l.png", (24, 24)),
    "item_bat":           ("item_bat.png", (24, 24)),   # 2.4 빠따 아이템
    "p_siyoon": ("player_siyoon.png", (30, 30)), "p_siyoon_shield": ("player_siyoon_shield.png", (30, 30)), "p_siyoon_kimchi": ("player_siyoon_kimchi.png", (30, 30)),
    "p_yoonjae": ("player_yoonjae.png", (30, 30)), "p_yoonjae_shield": ("player_yoonjae_shield.png", (30, 30)), "p_yoonjae_kimchi": ("player_yoonjae_kimchi.png", (30, 30)),
    "p_yoonchae": ("player_yoonchae.png", (30, 30)), "p_yoonchae_shield": ("player_yoonchae_shield.png", (30, 30)), "p_yoonchae_kimchi": ("player_yoonchae_kimchi.png", (30, 30)),
    "p_halloween":        ("player_halloween.png", (30, 30)),   # 2.0.2 할로윈
    "p_halloween_shield": ("player_halloween_shield.png", (30, 30)),
    "p_halloween_kimchi": ("player_halloween_kimchi.png", (30, 30)),
    "item_tot":           ("item_tot.png", (24, 24)),
    "obstacle_pk":        ("obstacle_pumpkin.png", (20, 20)),
}

FALLBACK_COLOR = {
    "item_magnet": CYAN,
    "item_slow": PURPLE,
    "item_shield": GRAY,
    "item_heal": PINK,
    "item_kimchi": RED,
    "item_timefreeze": (173, 216, 230),  # 1.6
    "item_goldrush": (255, 215, 0),  # 1.6
    "item_minime": (144, 238, 144),  # 1.6
    "item_rewind": ORANGE,  # 1.6
    "item_bat": (200, 150, 90),  # 2.4
    "item_l": (255, 120, 220),  # 2.0.1
    "item_tot": (255, 140, 0),  # 2.0.2
}

def resource_path(relative_path):
    return relative_path   # 웹: 에셋은 main.py와 같은 폴더에 있음

try:
    pygame.mixer.music.load(resource_path("bgm.ogg"))
except Exception:
    print("BGM 파일을 찾을 수 없습니다. 음악 없이 진행합니다.")

def load_and_scale(filename, size):
    try:
        surface = pygame.image.load(filename).convert_alpha()
        if os.path.basename(filename).startswith("icon_") and surface.get_width() != size[0] and surface.get_width() % size[0]:
            return pygame.transform.smoothscale(surface, size)   # 2.0: 32px 도트 아이콘을 24px로 줄일 때만 부드럽게
        return pygame.transform.scale(surface, size)
    except Exception:
        return None

img = {key: load_and_scale(resource_path(path), size) for key, (path, size) in ASSET_SPECS.items()}
# 스킨 탭 잠금 표시용 실루엣 (알파 유지, 색은 검정에 가깝게)
for _k in [k for k in list(img) if k.startswith("p_")]:
    if img[_k] is not None:
        _sil = img[_k].copy()
        _sil.fill((20, 20, 20, 255), special_flags=pygame.BLEND_RGBA_MULT)
        img["sil_" + _k] = _sil

# 1.8: 새 이미지 파일 없이 기존 coin.png / obstacle.png 에서 파생
GOLD_COIN_SIZE = 45                    # 일반 코인(30)의 1.5배
SPLIT_SIZES = [20, 16, 13, 10]         # 분열탄 세대별 크기 (0세대 = 원본 장애물과 같은 크기)

def _recolor(surface, sat=1.0, val=1.0):
    """채도/밝기만 바꾼 복사본 (알파 유지). 스프라이트가 작아서 픽셀 루프 비용은 무시 가능"""
    import colorsys
    out = surface.copy()
    w, h = out.get_size()
    for px in range(w):
        for py in range(h):
            r, g, b, a = out.get_at((px, py))
            if a == 0: continue
            hh, ss, vv = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
            nr, ng, nb = colorsys.hsv_to_rgb(hh, min(1.0, ss * sat), min(1.0, vv * val))
            out.set_at((px, py), (int(nr * 255), int(ng * 255), int(nb * 255), a))
    return out

def _tint(surface, hue, sat_min, val_mul):
    """전체를 한 가지 색조로 물들임 (밝기 구조는 유지). 원본 장애물이 회색조라 색조만 돌려서는 색이 안 바뀌기 때문"""
    import colorsys
    out = surface.copy()
    w, h = out.get_size()
    for px in range(w):
        for py in range(h):
            r, g, b, a = out.get_at((px, py))
            if a == 0: continue
            hh, ss, vv = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
            nr, ng, nb = colorsys.hsv_to_rgb(hue / 360, max(ss, sat_min), min(1.0, vv * val_mul))
            out.set_at((px, py), (int(nr * 255), int(ng * 255), int(nb * 255), a))
    return out

def make_variant_images():
    try:
        coin_raw = pygame.image.load(resource_path("coin.png")).convert_alpha()
        obs_raw = pygame.image.load(resource_path("obstacle.png")).convert_alpha()
    except Exception:
        return  # 원본이 없으면 파생 이미지도 없이 기본 도형으로 그림
    try:
        img["coin_gold"] = pygame.transform.scale(coin_raw, (GOLD_COIN_SIZE, GOLD_COIN_SIZE))
        img["coin_bomb"] = _recolor(pygame.transform.scale(coin_raw, (30, 30)), sat=0.5, val=0.35)
        img["ob_zigzag"] = _tint(pygame.transform.scale(obs_raw, (20, 20)), 130, 0.65, 1.2)
        split_base = _tint(obs_raw, 355, 0.75, 1.3)
        for g, sz in enumerate(SPLIT_SIZES):
            img[f"ob_split_{g}"] = pygame.transform.scale(split_base, (sz, sz))
    except Exception as e:
        print("경고: 1.8 파생 이미지 생성 실패, 기본 도형으로 대체합니다:", e)

def make_halloween_images():
    """2.0.2: 호박 장애물에서 지그재그(초록)/분열탄(빨강) 변형을 만듦. 키 끝에 _pk"""
    try:
        pk_raw = pygame.image.load(resource_path("obstacle_pumpkin.png")).convert_alpha()
        img["ob_zigzag_pk"] = _tint(pygame.transform.scale(pk_raw, (20, 20)), 130, 0.65, 1.2)
        split_base = _tint(pk_raw, 355, 0.75, 1.3)
        for g, sz in enumerate(SPLIT_SIZES):
            img[f"ob_split_{g}_pk"] = pygame.transform.scale(split_base, (sz, sz))
    except Exception as e:
        print("경고: 2.0.2 호박 파생 이미지 생성 실패, 기본 장애물로 대체합니다:", e)

make_variant_images()
make_halloween_images()
missing_assets = [k for k, v in img.items() if v is None]
if missing_assets:
    print(f"경고: {len(missing_assets)}개 에셋을 찾을 수 없어 기본 도형으로 대체합니다.")

def ob_img(key):
    """2.0.2: 할로윈 기간이면 호박 버전(키 끝 _pk) 이미지를 사용"""
    pk = key + "_pk"
    return pk if (halloween_now() and img.get(pk)) else key

def draw_sprite_or_fallback(key, x, y, fallback_draw):
    surf = img.get(key)
    if surf:
        screen.blit(surf, (int(x - surf.get_width() / 2), int(y - surf.get_height() / 2)))
    else:
        fallback_draw()

# ===================== 1.9 코드 애니메이션 (이미지 파일 없이 도형/글자만 사용) =====================
FX_MAX_PARTICLES, FX_MAX_POPUPS, FX_MAX_RINGS = 80, 12, 10   # 동시에 존재할 수 있는 최대 개수 (넘으면 오래된 것부터 삭제)
FX_RGB = {"magnet": (0, 255, 255), "slow": (170, 90, 255), "shield": (200, 200, 200), "heal": (255, 150, 190),
          "kimchi": (255, 70, 70), "timefreeze": (150, 210, 255), "goldrush": (255, 215, 0),
          "minime": (140, 240, 140), "rewind": (255, 165, 0), "l": (255, 120, 220), "tot": (255, 140, 0), "bat": (200, 150, 90)}
COMBO_MILESTONES = [10, 25, 50, 100]
FX_FLASH_MS = 300
fx_particles, fx_popups, fx_rings = [], [], []
fx_last_tick = 0
fx_blink_until = 0
fx_combo_pop_until = 0
fx_milestone_done = 0
fx_flash_start = -10**9
font_pop = pygame.font.Font(FONT_FILE, 20)
font_cap = pygame.font.Font(FONT_FILE, 28)

def fx_color(rgb, k):
    """rgb를 배경색(DARKBLUE) 쪽으로 k(0~1)만큼 섞은 색 - 알파 서피스 없이 가볍게 사라지게 함"""
    k = min(1.0, max(0.0, k))
    bg = bg_color()
    return tuple(int(rgb[j] + (bg[j] - rgb[j]) * k) for j in range(3))

def fx_trim(lst, limit):
    while len(lst) >= limit:
        lst.pop(0)

def fx_burst(x, y, rgb, n, now):
    if not anim_on: return
    for _ in range(n):
        fx_trim(fx_particles, FX_MAX_PARTICLES)
        ang, sp = random.uniform(0, 2*math.pi), random.uniform(60, 170)   # sp: px/초
        fx_particles.append({"x": x, "y": y, "vx": math.cos(ang)*sp, "vy": math.sin(ang)*sp,
                             "born": now, "life": random.randint(300, 500), "rgb": rgb})

def fx_popup(text, x, y, rgb, now, life=800):
    if not anim_on: return
    fx_trim(fx_popups, FX_MAX_POPUPS)
    fx_popups.append({"text": text, "x": x, "y": y, "born": now, "life": life, "rgb": rgb})

def fx_ring(x, y, rgb, now, r1=34, life=350):
    if not anim_on: return
    fx_trim(fx_rings, FX_MAX_RINGS)
    fx_rings.append({"x": x, "y": y, "born": now, "life": life, "rgb": rgb, "r1": r1})

def fx_clear():
    global fx_blink_until, fx_combo_pop_until, fx_milestone_done
    fx_particles.clear(); fx_popups.clear(); fx_rings.clear()
    fx_blink_until = 0; fx_combo_pop_until = 0; fx_milestone_done = 0

def fx_draw(now):
    """효과 갱신 + 그리기 (경과 시간은 실제 ms 기준이라 FPS 설정과 무관하게 같은 시간 동안 보임)"""
    global fx_last_tick, fx_particles, fx_popups, fx_rings
    dt = (now - fx_last_tick) / 1000 if fx_last_tick else 0
    fx_last_tick = now
    fx_particles = [p for p in fx_particles if now - p["born"] < p["life"]]
    fx_popups = [p for p in fx_popups if now - p["born"] < p["life"]]
    fx_rings = [p for p in fx_rings if now - p["born"] < p["life"]]
    for p in fx_rings:
        a = (now - p["born"]) / p["life"]
        pygame.draw.circle(screen, fx_color(p["rgb"], a), (int(p["x"]), int(p["y"])), int(6 + (p["r1"] - 6) * a), 2)
    for p in fx_particles:
        p["x"] += p["vx"] * dt; p["y"] += p["vy"] * dt
        pygame.draw.circle(screen, fx_color(p["rgb"], (now - p["born"]) / p["life"]), (int(p["x"]), int(p["y"])), 2)
    for p in fx_popups:
        a = (now - p["born"]) / p["life"]
        draw_text_center(screen, font_buff, p["text"], fx_color(p["rgb"], max(0, (a - .5) * 2)), (p["x"], p["y"] - 40 * a))

def fx_coin_pickup(pos, gain, is_gold, now):
    x, y = pos
    rgb = (255, 200, 0) if is_gold else (255, 235, 120)
    fx_burst(x, y, rgb, 10 if is_gold else 5, now)
    fx_popup(f"+{gain}", x, y - 10, rgb if is_gold else (255, 245, 160), now)

def fx_bomb_pickup(pos, had_combo, immune, now):
    x, y = pos
    if immune:
        fx_popup(t("fx_immune"), x, y - 10, (120, 220, 255), now); return
    fx_burst(x, y, (230, 50, 50), 8, now)
    if had_combo >= 2: fx_popup(t("fx_combo_reset"), x, y - 10, (255, 110, 110), now)

def fx_item_pickup(item_t, pos, now):
    x, y = pos
    rgb = FX_RGB.get(item_t, (255, 255, 255))
    fx_ring(x, y, rgb, now)
    fx_popup(t("item_name_" + item_t), x, y - 16, rgb, now, life=1000)

def fx_hit(now):
    global fx_blink_until
    if not anim_on: return
    fx_ring(player.x, player.y, (255, 60, 60), now, r1=44, life=400)
    fx_burst(player.x, player.y, (255, 90, 90), 6, now)
    fx_blink_until = now + INV_SEC

def fx_shield_block(now):
    fx_ring(player.x, player.y, (110, 190, 255), now, r1=40, life=350)

def fx_draw_flash(now):
    """피격으로 죽었을 때만: 붉은 화면이 0.3초 동안 배경색으로 돌아옴"""
    if anim_on and now - fx_flash_start < FX_FLASH_MS:
        screen.fill(fx_color((170, 0, 0), (now - fx_flash_start) / FX_FLASH_MS))

# ---- 아이템 슬롯 HUD: 켜져 있는 효과만 왼쪽부터 빈틈없이 칸으로 나열.
#      시간형 아이템은 흰 반투명 막이 위에서 아래로 내려오며 남은 시간을 표시 (마리오 카트 월드 방식), 개수형(실드/되감기)은 모서리 숫자 ----
HUD_ORDER = ["magnet", "slow", "kimchi", "timefreeze", "goldrush", "minime", "shield", "rewind", "bat", "l"]
HUD_LETTER = {"magnet": "M", "slow": "S", "kimchi": "K", "timefreeze": "T", "goldrush": "G", "minime": "m", "shield": "D", "rewind": "R", "bat": "B", "l": "L"}
HUD_COUNT_KEYS = ("shield", "rewind", "bat")
HUD_SLOT, HUD_STEP, HUD_Y = 38, 46, 68
HUD_X0 = 269   # 첫 칸의 중심 x (칸 8개가 동시에 켜져도 화면 안)
HUD_INNER = HUD_SLOT - 4   # 막이 덮는 안쪽 영역 한 변
HUD_BLINK_MS = 2000   # 끝나기 전 이 시간 동안 아이콘 깜빡임
HUD_VEIL_ALPHA = 150
hud_veil = pygame.Surface((HUD_INNER, HUD_INNER), pygame.SRCALPHA)
hud_veil.fill((255, 255, 255, HUD_VEIL_ALPHA))
hud_prev = set()
hud_total = {}   # 효과가 켜진 순간(또는 시간이 늘어난 순간)의 남은 시간(ms) = 막 비율의 기준(100%)
hud_last = {}

def hud_active(now):
    out = []
    if player.magnet_active: out.append(("magnet", player.magnet_end_tick - now))
    if player.slow_active: out.append(("slow", player.slow_end_tick - now))
    if player.kimchi_active: out.append(("kimchi", player.kimchi_end_tick - now))
    if player.freeze_active: out.append(("timefreeze", player.freeze_end_tick - now))
    if player.goldrush_active: out.append(("goldrush", player.goldrush_end_tick - now))
    if player.minime_active: out.append(("minime", player.minime_end_tick - now))
    if player.l_active: out.append(("l", player.l_end_tick - now))
    if player.shield_count > 0: out.append(("shield", None))
    if player.rewind_charges > 0: out.append(("rewind", None))
    if player.bat_count > 0: out.append(("bat", None))
    return out

def hud_veil_height(key, rem):
    """남은 시간 rem(ms)으로 막 높이(0~HUD_INNER) 계산. 켜진 순간 0, 끝나는 순간 가득"""
    if key not in hud_total or rem > hud_last.get(key, 0) + 50:   # 새로 켜짐 또는 다시 먹어서 시간이 늘어남
        hud_total[key] = max(rem, 1)
    hud_last[key] = rem
    frac = 1 - max(0, rem) / hud_total[key]
    return max(0, min(HUD_INNER, int(round(frac * HUD_INNER))))

def draw_hud_icons(now):
    shown = set()
    half = HUD_SLOT // 2
    for idx, (key, rem) in enumerate(hud_active(now)):
        x = HUD_X0 + idx * HUD_STEP
        shown.add(key)
        if key not in hud_prev:   # 새로 켜진 효과: 칸 자리에 작은 링
            fx_ring(x, HUD_Y, FX_RGB.get(key, (255, 255, 255)), now, r1=26, life=300)
        box = pygame.Rect(x - half, HUD_Y - half, HUD_SLOT, HUD_SLOT)
        pygame.draw.rect(screen, (0, 0, 96), box, border_radius=5)
        blink = rem is not None and rem < HUD_BLINK_MS and (now // 200) % 2 == 1
        if not blink:
            def fallback(x=x, key=key):
                pygame.draw.circle(screen, FALLBACK_COLOR.get(f"item_{key}", WHITE), (x, HUD_Y), 12)
                draw_text_center(screen, font_buff, HUD_LETTER[key], BLACK, (x, HUD_Y))
            draw_sprite_or_fallback(f"item_{key}", x, HUD_Y, fallback)
        if key in HUD_COUNT_KEYS:
            n = player.shield_count if key == "shield" else player.bat_count if key == "bat" else player.rewind_charges
            badge = font_buff.render(f"x{n}", True, WHITE)
            screen.blit(badge, badge.get_rect(bottomright=(x + half - 3, HUD_Y + half - 2)))
        else:
            vh = hud_veil_height(key, rem)
            if vh > 0:
                screen.blit(hud_veil, (x - HUD_INNER // 2, HUD_Y - HUD_INNER // 2), area=pygame.Rect(0, 0, HUD_INNER, vh))
        pygame.draw.rect(screen, (16, 16, 48), box, 2, border_radius=5)
    for key in HUD_ORDER:
        if key not in shown:
            hud_total.pop(key, None); hud_last.pop(key, None)
    hud_prev.clear(); hud_prev.update(shown)

game_state = "MAIN"
versus_mode = False   # 2.1: 2인 대결 진행 중 (True면 기록/업적 카운트 제외)

difficulty = "normal"
score = 0
time_left = 31
last_hit_time = 0
INV_SEC = 700

PLAYER_R = 15
PLAYER_SPD = 6

class PlayerState:
    def __init__(self):
        self.hp = 5
        self.x = WIDTH // 2
        self.y = HEIGHT // 2
        self.shield_count = 0
        self.magnet_active = False
        self.magnet_end_tick = 0
        self.slow_active = False
        self.slow_end_tick = 0
        self.kimchi_active = False
        self.kimchi_end_tick = 0
        self.combo = 0
        self.combo_hit_count = 0
        self.session_hits = 0
        self.session_shield_used = False
        self.session_kimchi_used = False
        # 1.6 신규 아이템 상태
        self.freeze_active = False
        self.freeze_end_tick = 0
        self.goldrush_active = False
        self.goldrush_end_tick = 0
        self.minime_active = False
        self.minime_end_tick = 0
        self.rewind_charges = 0
        self.l_active = False      # 2.0.1 L 아이템
        self.l_start_tick = 0
        self.l_end_tick = 0
        self.dev_cd_until = 0      # 2.0.1 개발자 동전 O 키 쿨타임 끝나는 시각 (2.4 꼰대 동전도 같이 씀)
        self.bubble = False        # 2.4 잠수함 동전 거품 방패
        self.bubble_at = 0         # 거품이 다시 생기는 시각 (0이면 예약 없음)
        self.bubble_left = 0       # 남은 재충전 횟수
        self.session_bubble_hits = 0   # 거품이 막아 준 충돌 횟수 (anniv_nohit 판정용)
        self.bat_count = 0         # 2.4 빠따 아이템 남은 횟수
        self.bat_cd_until = 0
        self.dodge_until = 0       # 2.4 정윤재 샨셴부: 이 시각까지 장애물 충돌 무시
        self.cast_id = 0           # 2.4 능력 말풍선 (CAST_TEXT 번호)
        self.cast_until = 0
        self.kk_active = False     # 2.4 꼰대 동전 능력 (자막 + 장애물 밀어내기)
        self.kk_start_tick = 0
        self.kk_end_tick = 0
        self.tot_trick = None      # 2.0.2 트릭 오어 트릿: 걸려 있는 트릭 ("fast"/"invert"/None)
        self.tot_end_tick = 0
        self.tot_msg = ""
        self.tot_msg_until = 0
        self.sister_charges = 0  # 1.7 누나 콤보 면역 잔여 횟수
        self.pos_history = []  # [(tick, x, y), ...] 최근 REWIND_LOOKBACK_MS + 여유분만 유지

    def reset_session_flags(self):
        self.session_hits = 0
        self.session_bubble_hits = 0
        self.session_shield_used = False
        self.session_kimchi_used = False

    def reset_combo(self):
        self.combo = 0
        self.combo_hit_count = 0

player = PlayerState()

def is_twins():
    return equipped_skin == "twins"

def player_bodies():
    """플레이어 몸체 좌표 목록. 쌍둥이는 player.x가 왼쪽 몸체, 오른쪽 몸체는 TWIN_GAP만큼 오른쪽"""
    if is_twins():
        return [(player.x, player.y), (player.x + TWIN_GAP, player.y)]
    return [(player.x, player.y)]

def player_dist(x, y):
    return min(math.hypot(bx - x, by - y) for bx, by in player_bodies())

def resolve_tot(x, y, now):
    """트릭 오어 트릿: 누적 카운트 + (트릿) 체력/점수/실드 중 하나, (트릭) 장애물 가속/조작 반전 5초. 얻은 점수를 돌려줌"""
    if not versus_mode and add_counter("total_tot") >= TOT_UNLOCK_COUNT: unlock_achievement("tot_10")   # 2.1: 대결은 기록하지 않음
    chance = TOT_TREAT_CHANCE_SKIN if equipped_skin == "halloween" else TOT_TREAT_CHANCE
    if random.random() < chance:
        kind = random.choices(TOT_TREATS, k=1)[0]
        bonus = 0
        if kind == "hp":
            player.hp += 1; player.tot_msg = t("tot_treat_hp")
        elif kind == "score":
            bonus = TOT_TREAT_SCORE; player.tot_msg = t("tot_treat_score", n=TOT_TREAT_SCORE)
        else:
            player.shield_count += 1; player.tot_msg = t("tot_treat_shield")
            if player.shield_count >= 3: unlock_achievement("shield_3")
        player.tot_msg_until = now + TOT_MSG_MS
        fx_burst(x, y, (255, 170, 40), 8, now)
        return bonus
    player.tot_trick = "invert" if versus_mode else random.choices(TOT_TRICKS, k=1)[0]   # 2.1: 대결에서는 먹은 사람에게만 적용되는 조작 반전만
    player.tot_end_tick = now + TOT_TRICK_MS
    player.tot_msg = ""; player.tot_msg_until = 0
    fx_burst(x, y, (170, 90, 255), 8, now)
    return 0

def dev_clear(now):
    """개발자 동전: 플레이어 중심 반경 DEV_CLEAR_RADIUS px 안의 장애물을 모두 지움 (쿨타임 DEV_COOLDOWN_MS)"""
    global obstacles
    if now < player.dev_cd_until: return
    px, py = player.x, player.y
    keep = []
    for ob in obstacles:
        if (ob["x"] - px) ** 2 + (ob["y"] - py) ** 2 <= DEV_CLEAR_RADIUS ** 2:
            fx_burst(ob["x"], ob["y"], (120, 255, 160), 3, now)
        else:
            keep.append(ob)
    obstacles = keep
    player.dev_cd_until = now + DEV_COOLDOWN_MS
    fx_ring(px, py, (120, 255, 160), now, r1=DEV_CLEAR_RADIUS, life=450)

_bubble_cache = {}

def draw_bubble(x, y, has, reload_at, now):
    """잠수함 동전 거품: 있으면 몸 주위에 반투명 거품, 재장전 중이면 2초 진행 막대"""
    if has:
        r = PLAYER_R + 6
        surf = _bubble_cache.get(r)
        if surf is None:
            surf = pygame.Surface((r * 2 + 4, r * 2 + 4), pygame.SRCALPHA)
            pygame.draw.circle(surf, (190, 235, 255, 70), (r + 2, r + 2), r)
            pygame.draw.circle(surf, (235, 250, 255, 190), (r + 2, r + 2), r, 2)
            pygame.draw.circle(surf, (255, 255, 255, 200), (r // 2 + 2, r // 2 + 2), 3)
            _bubble_cache[r] = surf
        screen.blit(surf, (int(x - r - 2), int(y - r - 2)))
    elif reload_at:
        k = 1.0 - max(0, min(1.0, (reload_at - now) / BUBBLE_RELOAD_MS))
        w = 26
        bx, by = int(x - w // 2), int(y + PLAYER_R + 6)
        pygame.draw.rect(screen, (40, 70, 110), (bx, by, w, 4))
        pygame.draw.rect(screen, (170, 225, 255), (bx, by, max(1, int(w * k)), 4))

def bubble_init(ps):
    ps.bubble = True; ps.bubble_at = 0; ps.bubble_left = BUBBLE_MAX_RELOADS

def bubble_tick(now):
    """잠수함 동전: 터진 거품이 정해진 시각이 되면 다시 생김"""
    if equipped_skin == "submarine" and not player.bubble and player.bubble_at and now >= player.bubble_at:
        player.bubble = True; player.bubble_at = 0

def bubble_block(now):
    """잠수함 동전: 충돌을 거품이 막아 주면 True (거품은 터지고, 남은 횟수가 있으면 2초 뒤 다시 생김)"""
    if equipped_skin == "submarine" and player.bubble:
        player.bubble = False
        player.session_bubble_hits += 1
        if player.bubble_left > 0:
            player.bubble_left -= 1; player.bubble_at = now + BUBBLE_RELOAD_MS
        else:
            player.bubble_at = 0
        return True
    return False

def kk_activate(now):
    """꼰대 동전: 쿨타임이 아니면 KK_DURATION_MS 동안 능력 발동 (쿨타임은 발동 시점부터 KK_COOLDOWN_MS)"""
    if now < player.dev_cd_until or player.kk_active: return
    player.kk_active = True; player.kk_start_tick = now; player.kk_end_tick = now + KK_DURATION_MS
    player.dev_cd_until = now + KK_COOLDOWN_MS
    fx_ring(player.x, player.y, (255, 200, 90), now, r1=KK_RADIUS, life=450)

bat_pending = False   # 대결에서 빠따를 휘둘렀다: vs_apply_action 이 상대에게 피해를 줄지 확인

def cast_set(cid, now):
    player.cast_id = cid; player.cast_until = now + CAST_MS[cid]

def bat_clear(now):
    """반경 BAT_RADIUS 안의 장애물 삭제"""
    global obstacles
    px, py = player.x, player.y
    keep = []
    for ob in obstacles:
        if (ob["x"] - px) ** 2 + (ob["y"] - py) ** 2 <= BAT_RADIUS ** 2:
            fx_burst(ob["x"], ob["y"], (230, 190, 120), 3, now)
        else:
            keep.append(ob)
    obstacles = keep
    fx_ring(px, py, (230, 190, 120), now, r1=BAT_RADIUS, life=350)

def bat_swing(now):
    """빠따 휘두르기 (박시윤 O 키 / 빠따 아이템 I 키): 장애물 삭제 + (대결이면) 상대 확인 예약"""
    global bat_pending
    bat_clear(now); cast_set(4, now)
    if versus_mode: bat_pending = True

def siyoon_ability(now):
    if now < player.dev_cd_until: return
    player.dev_cd_until = now + SIYOON_COOLDOWN_MS
    bat_swing(now)

def bat_item_use(now):
    if player.bat_count <= 0 or now < player.bat_cd_until: return
    player.bat_count -= 1
    player.bat_cd_until = now + BAT_ITEM_COOLDOWN_MS
    bat_swing(now)

def yoonjae_ability(now):
    global obstacles
    if now < player.dev_cd_until: return
    player.dev_cd_until = now + YJ_COOLDOWN_MS
    r = random.random()
    if r < YJ_P_DODGE:    # 샨셴부: 잠깐 장애물을 통과
        player.dodge_until = now + YJ_DODGE_MS; cast_set(1, now)
        fx_ring(player.x, player.y, (190, 140, 255), now, r1=50, life=400)
    elif r < YJ_P_DODGE + YJ_P_FLING:   # 랑게티치오: 주변 장애물을 날려 버림
        px, py = player.x, player.y
        keep = []
        for ob in obstacles:
            if (ob["x"] - px) ** 2 + (ob["y"] - py) ** 2 <= YJ_FLING_RADIUS ** 2:
                fx_burst(ob["x"], ob["y"], (190, 140, 255), 3, now)
            else:
                keep.append(ob)
        obstacles = keep
        cast_set(2, now)
        fx_ring(px, py, (190, 140, 255), now, r1=YJ_FLING_RADIUS, life=450)
    else:   # 룽둥 쾅: L 아이템과 같은 효과
        player.l_active = True; player.l_start_tick = now; player.l_end_tick = now + L_DURATION_MS
        cast_set(3, now)

def o_ability(now):
    """O 키 능력: 개발자 / 꼰대 / 박시윤 / 정윤재"""
    if equipped_skin == "devcoin": dev_clear(now)
    elif equipped_skin == "kkondae": kk_activate(now)
    elif equipped_skin == "siyoon": siyoon_ability(now)
    elif equipped_skin == "yoonjae": yoonjae_ability(now)

def skin_has_o(sk):
    return sk in ("devcoin", "kkondae", "siyoon", "yoonjae")

def kk_push(bodies, dt_scale, slow_mult=1.0):
    """꼰대 동전 능력 중: 몸체 기준 KK_RADIUS 안의 장애물을 바깥쪽으로 밀어냄"""
    step = KK_PUSH_SPD * dt_scale * slow_mult
    r2 = KK_RADIUS ** 2
    for ob in obstacles:
        best = None
        for bx, by in bodies:
            dx, dy = ob["x"] - bx, ob["y"] - by
            d2 = dx * dx + dy * dy
            if d2 <= r2 and (best is None or d2 < best[0]): best = (d2, dx, dy)
        if best is None: continue
        d = math.sqrt(best[0]) + 0.01
        mx, my = best[1] / d * step, best[2] / d * step
        ob["x"] += mx; ob["y"] += my
        if ob["kind"] == "zigzag" and "bx" in ob: ob["bx"] += mx

def sister_save_combo():
    """누나 스킨: 콤보(2 이상)가 끊길 상황이면 면역 1회를 소모하고 True"""
    if equipped_skin == "sister" and player.sister_charges > 0 and player.combo >= 2:
        player.sister_charges -= 1
        return True
    return False

dev_streak = _settings.get("dev_streak", 0)
endless_mode = False
endless_start_tick = 0
speedrun_mode = False
speedrun_start_tick = 0
speedrun_final_sec = 0
speedrun_result_key = "speedrun_fail"
SPEEDRUN_GOAL = 100
ENDLESS_SPD_START, ENDLESS_SPD_CEIL = 2, 6
ENDLESS_CHANCE_START, ENDLESS_CHANCE_CEIL = 60, 25
ENDLESS_RAMP_MS = 180000

def update_endless_difficulty(elapsed_ms):
    progress = min(1.0, elapsed_ms / ENDLESS_RAMP_MS)
    spd = int(round(ENDLESS_SPD_START + (ENDLESS_SPD_CEIL - ENDLESS_SPD_START) * progress))
    chance = int(round(ENDLESS_CHANCE_START + (ENDLESS_CHANCE_CEIL - ENDLESS_CHANCE_START) * progress))
    return spd, chance

last_coin_time = 0

render_count = 0
fps_current = 0
fps_avg = 0
_fps_frame_accum = 0
_fps_timer_start = 0
COMBO_WINDOW_MS = 1500
COMBO_BONUS_STEP = 6

MAGNET_DURATION_MS = 5000
MAGNET_RANGE = 120

SLOW_DURATION_MS = 5000
SLOW_FACTOR = 0.5

KIMCHI_DURATION_MS = 5000

coins = []
obstacles = []
items = []

ITEM_TYPES = ["magnet", "slow", "shield", "heal", "kimchi"]
ITEM_SPAWN_CHANCE = 100

# 1.6 신규 아이템: 미션 해금 후에만 스폰 풀에 등장, 기존 아이템과 동일 가중치
NEW_ITEM_MISSION = {
    "timefreeze": "unlock_timefreeze",
    "goldrush": "unlock_goldrush",
    "minime": "unlock_minime",
    "rewind": "unlock_rewind",
}
NEW_ITEM_TYPES = ["timefreeze", "goldrush", "minime", "rewind"]
NEW_ITEM_DURATION_MS = 5000  # 되감기 제외 - 되감기는 1회성 충전형
GOLDRUSH_COIN_ROLLS = 7  # 프레임당 코인 스폰 시도 횟수 (약 6.7배 근사)
REWIND_LOOKBACK_MS = 1000

# 1.8 신규 장애물/코인: 미션 해금 후에만 스폰 풀에 등장
OB_KIND_MISSION = {"zigzag": "unlock_zigzag", "split": "unlock_split"}
COIN_KIND_MISSION = {"gold": "unlock_goldcoin", "bomb": "unlock_bombcoin"}
ZIGZAG_AMP = 40            # 지그재그: 좌우 흔들림 폭(±px)
ZIGZAG_PERIOD_SEC = 1.0    # 지그재그: 한 번 왕복하는 데 걸리는 시간
SPLIT_INTERVAL_MS = 1000   # 분열탄: 분열 주기 - 타임프리즈 중에도 카운트 진행
SPLIT_SPREADS = [32, 16, 8]   # 세대별 좌우 벌림(px): 겹치지 않는 간격
SPLIT_MAX_GEN = 3          # 3세대까지만 분열 (1→2→4→8조각), 마지막 세대는 더 안 쪼개짐
SPLIT_RADII = [10, 8, 6, 5]   # 세대별 충돌 반지름
GOLD_COIN_RATE = 0.02      # 코인 스폰 중 황금 코인 비율
BOMB_COIN_RATE = 0.05      # 코인 스폰 중 폭탄 코인 비율 (1.8.1: 0.10 → 0.05)
GOLD_COIN_R = 22           # 일반 코인(15)의 1.5배
GOLD_COIN_SCORE_MULT = 5
GOLD_COIN_LIFE_MS = 3000
GOLD_COIN_BLINK_MS = 1000  # 사라지기 전 마지막 1초는 깜빡임

def choose_coin_kind():
    """해금된 신규 코인 종류를 비율대로 섞어서 하나 선택 (미해금이면 항상 일반 코인)"""
    if not twisted_on:
        return "normal"
    if mission_unlocked.get(COIN_KIND_MISSION["gold"]) and random.random() < GOLD_COIN_RATE:
        return "gold"
    if mission_unlocked.get(COIN_KIND_MISSION["bomb"]) and not cheat_on and random.random() < BOMB_COIN_RATE:  # 치트 중에는 폭탄 코인 없음
        return "bomb"
    return "normal"

def spawn_coin(coin_diff, now):
    kind = choose_coin_kind()
    if kind == "gold":  # 황금 코인: 화면 안 아무 데나 나타나 3초 머무르다 사라짐 (1.5배 크기)
        coins.append({"x": float(random.randint(80, WIDTH - 80)), "y": float(random.randint(60, HEIGHT - 60)),
                      "speed": 0, "r": GOLD_COIN_R, "kind": "gold", "expire": now + GOLD_COIN_LIFE_MS})
        return
    spd = random.randint(2, 10) if coin_diff else 5
    coins.append({"x": float(WIDTH + 100), "y": random.randint(20, HEIGHT - 20), "speed": spd, "r": 15,
                  "kind": kind, "expire": 0})

def choose_obstacle_kind():
    """일반 장애물 + 해금된 신규 장애물 중 동일 가중치로 하나 선택"""
    if not twisted_on:
        return "normal"
    pool = ["normal"] + [k for k, mid in OB_KIND_MISSION.items() if mission_unlocked.get(mid)]
    return random.choices(pool, k=1)[0]

def spawn_obstacle(max_spd, now):
    kind = choose_obstacle_kind()
    ob = {"x": random.randint(50, WIDTH - 50), "y": float(HEIGHT + 100),
          "speed": random.randint(2, max_spd), "r": 10, "kind": kind, "gen": 0}
    if kind == "zigzag":
        ob["bx"] = float(ob["x"]); ob["ph"] = 0.0
    elif kind == "split":
        ob["next"] = now + SPLIT_INTERVAL_MS
    obstacles.append(ob)

def update_splits(now):
    """분열탄: SPLIT_INTERVAL_MS마다 이분법. 타임프리즈 중에도 카운트는 계속 진행되고, 정지한 채 그 자리에서 분열"""
    global obstacles
    out = []
    for ob in obstacles:
        if ob["kind"] == "split" and ob["gen"] < SPLIT_MAX_GEN and now >= ob["next"]:
            spread = SPLIT_SPREADS[ob["gen"]]
            fx_burst(ob["x"], ob["y"], (255, 130, 90), 4, now)
            for sx in (-spread, spread):
                nx = min(max(ob["x"] + sx, 10), WIDTH - 10)  # 화면 가장자리에서 벗어나지 않게
                out.append({"x": nx, "y": ob["y"], "speed": ob["speed"], "r": SPLIT_RADII[ob["gen"] + 1],
                            "kind": "split", "gen": ob["gen"] + 1, "next": ob["next"] + SPLIT_INTERVAL_MS})
        else:
            out.append(ob)
    obstacles = out

def choose_item_type():
    """기존 5종 + 해금된 1.6 신규 아이템에서 동일 가중치로 하나 선택"""
    pool = list(ITEM_TYPES)
    if player.goldrush_active and not cheat_on:  # 1.8 밸런스: 골드러시 중에는 자석 아이템이 스폰되지 않음 (치트는 예외)
        pool.remove("magnet")
    pool.append("l")   # 2.0.1: L 아이템은 처음부터 등장 (동일 가중치)
    pool.append("bat")   # 2.4 빠따 아이템
    if halloween_now(): pool.append("tot")   # 2.0.2: 할로윈 기간에만 등장
    weights = [1] * len(pool)
    for nt in NEW_ITEM_TYPES:
        if mission_unlocked.get(NEW_ITEM_MISSION[nt]):
            pool.append(nt)
            weights.append(1)
    return random.choices(pool, weights=weights, k=1)[0]

diff_settings = {
    "easy":     {"max_ob_spd": 2,  "ob_chance": 60, "coin_diff": False, "ob_spawn": False, "time": 31, "inv_obs": False},
    "normal":   {"max_ob_spd": 4,  "ob_chance": 40, "coin_diff": False, "ob_spawn": True,  "time": 31, "inv_obs": False},
    "hard":     {"max_ob_spd": 6,  "ob_chance": 25, "coin_diff": True,  "ob_spawn": True,  "time": 20, "inv_obs": False},
    "hell":     {"max_ob_spd": 10, "ob_chance": 12, "coin_diff": True,  "ob_spawn": True,  "time": 15, "inv_obs": False},
    "hellhell": {"max_ob_spd": 20, "ob_chance": 7,  "coin_diff": True,  "ob_spawn": True,  "time": 10, "inv_obs": True},
    "hellhellhell": {"max_ob_spd": 30, "ob_chance": 5, "coin_diff": True, "ob_spawn": True, "time": 10, "inv_obs": True},
    "endless": {"max_ob_spd": 2, "ob_chance": 60, "coin_diff": True, "ob_spawn": True, "time": 999, "inv_obs": False},
    "adversity": {"max_ob_spd": 4, "ob_chance": 40, "coin_diff": False, "ob_spawn": True, "time": 31, "inv_obs": False},
    "speedrun": {"max_ob_spd": 4, "ob_chance": 40, "coin_diff": False, "ob_spawn": True, "time": 30, "inv_obs": False},
}

BUTTON_PAD_X = 24
BUTTON_HEIGHT = 42
BUTTON_MIN_WIDTH = 140

ICON_BUTTON_H = 54       # 2.0: 소형화 (예전 78x78)
ICON_BUTTON_MIN_W = 64

class Button:
    def __init__(self, x, y, text, callback, width=None, height=BUTTON_HEIGHT, icon=None, text_key=None, onoff=None):
        self.onoff = onoff   # 설정 토글용: ON/OFF 상태를 돌려주는 함수 (ON 초록 / OFF 회색)
        self.text = text
        self.text_key = text_key
        self.callback = callback
        self.is_hover = False
        self.icon = icon
        if icon is not None:
            height = ICON_BUTTON_H
            if width is None:   # 언어를 바꿔도 라벨이 넘치지 않도록 한국어/영어 중 긴 쪽 기준
                labels = [STRINGS[text_key][lg] for lg in ("ko", "en")] if text_key in STRINGS else [text]
                width = max(ICON_BUTTON_MIN_W, max(font_buff.size(s)[0] for s in labels) + 14)
        elif width is None:
            text_w, _ = font_mid.size(text)
            width = max(BUTTON_MIN_WIDTH, text_w + BUTTON_PAD_X * 2)
        self.rect = pygame.Rect(x - width // 2, y - height // 2, width, height)

    def draw(self, surface):
        color = GRAY if self.is_hover else WHITE
        label = t(self.text_key) if self.text_key else self.text
        if self.onoff is not None:
            on = self.onoff()
            label = "ON" if on else "OFF"
            color = (120, 220, 120) if on else (150, 150, 150)
            if self.is_hover: color = tuple(min(255, ch + 30) for ch in color)
        pygame.draw.rect(surface, color, self.rect, border_radius=5)
        pygame.draw.rect(surface, BLACK, self.rect, 2, border_radius=5)
        if self.icon is not None:
            icon_rect = self.icon.get_rect(midtop=(self.rect.centerx, self.rect.top + 6))
            surface.blit(self.icon, icon_rect)
            txt_surf = font_buff.render(label, True, BLACK)
            surface.blit(txt_surf, txt_surf.get_rect(midtop=(self.rect.centerx, icon_rect.bottom + 3)))
        else:
            txt_surf = font_mid.render(label, True, BLACK)
            surface.blit(txt_surf, txt_surf.get_rect(center=self.rect.center))

    def check_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.is_hover = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1 and self.rect.collidepoint(event.pos):
                self.callback()

def set_state_main():
    global game_state
    game_state = "MAIN"

mode_select_status = ""
def set_state_mode_select():
    global game_state, mode_select_status
    mode_select_status = ""
    game_state = "MODE_SELECT"

def mode_coming_soon(name_key):
    global mode_select_status
    mode_select_status = t("mode_coming_soon", name=t(name_key))

diff_select_status = ""
def diff_coming_soon(name_key):
    global diff_select_status
    diff_select_status = t("diff_coming_soon_msg", name=t(name_key))

def guarded_start(diff_name, mission_id, on_locked):
    """미션으로 해금되는 난이도/모드: 해금 전에는 시작을 막고 안내 메시지만 표시"""
    if mission_unlocked.get(mission_id):
        start_game_with_diff(diff_name)
    else:
        on_locked(diff_name)

def set_state_diff():
    global game_state, diff_select_status
    diff_select_status = ""
    game_state = "DIFF_SELECT"

def set_state_info():
    global game_state
    game_state = "UPDATE_INFO"

# 2.0: 사용 방법 / 역사서 / 저작권 화면
HOWTO_PAGES, HISTORY_PAGES = 9, 4
page_idx = {"HOWTO": 0, "HISTORY": 0}
VERSION_NUMBER = "ver 2.4 ANNIVERSARY".replace("ver ", "")

def set_state_howto():
    global game_state
    page_idx["HOWTO"] = 0
    game_state = "HOWTO"

def set_state_history():
    global game_state
    page_idx["HISTORY"] = 0
    game_state = "HISTORY"

def set_state_credits():
    global game_state
    game_state = "CREDITS"

def turn_page(group, delta):
    total = HOWTO_PAGES if group == "HOWTO" else HISTORY_PAGES
    page_idx[group] = min(total - 1, max(0, page_idx[group] + delta))

def wrap_text(font, text, max_w):
    """\\n 으로 나뉜 줄을 다시 max_w 픽셀 안으로 단어 단위로 줄바꿈"""
    out = []
    for line in text.split("\n"):
        if not line or font.size(line)[0] <= max_w:
            out.append(line); continue
        indent = len(line) - len(line.lstrip(" "))
        cur = ""
        for word in line.split(" "):
            trial = word if not cur else cur + " " + word
            if cur and font.size(trial)[0] > max_w:
                out.append(cur); cur = " " * indent + word if indent else word
            else:
                cur = trial
        out.append(cur)
    return out

def set_state_highscore():
    global game_state, rank_tab
    game_state = "HIGHSCORE"
    rank_tab = "mine"

def set_state_settings():
    global game_state
    game_state = "SETTINGS"

def set_state_achievements():
    global game_state
    game_state = "ACHIEVEMENTS"

def set_state_missions():
    global game_state
    game_state = "MISSIONS"

def set_state_skins():
    global game_state, skin_page
    game_state = "SKINS"
    skin_page = 0   # 메뉴에서 열 때는 항상 첫 쪽부터

def equip_skin(sid):
    global equipped_skin
    if not is_skin_unlocked(sid):
        return
    equipped_skin = sid
    save_settings(current_settings_dict())

# 똥쩐꼐임 치트 (숨겨진 기능): 메인 화면에서 "똥쩐꼐임" 입력 시 켜짐/꺼짐
# 두벌식 자판 위치(Shift+E,H,D,Shift+W,J,S,Shift+R,Shift+P,D,L,A)로도 인식 -> 한/영 상태 무관
cheat_on = False
CHEAT_KEYS = [(pygame.K_e, True), (pygame.K_h, False), (pygame.K_d, False), (pygame.K_w, True),
              (pygame.K_j, False), (pygame.K_s, False), (pygame.K_r, True), (pygame.K_p, True),
              (pygame.K_d, False), (pygame.K_l, False), (pygame.K_a, False)]
CHEAT_WORD = "똥쩐꼐임"
CHEAT_MAGNET_RANGE = 800
CHEAT_MAGNET_MS = 30000
CHEAT_KIMCHI_MS = 30000
CHEAT_GOLDRUSH_MS = 30000
_cheat_key_idx = 0
_cheat_text_buf = ""
_cheat_last_toggle = -10000
_EV_TEXTINPUT = getattr(pygame, "TEXTINPUT", None)
_EV_TEXTEDITING = getattr(pygame, "TEXTEDITING", None)

def _toggle_cheat():
    global cheat_on, _cheat_key_idx, _cheat_text_buf, _cheat_last_toggle
    _cheat_key_idx = 0
    _cheat_text_buf = ""
    now = pygame.time.get_ticks()
    if now - _cheat_last_toggle < 1000:
        return  # 한글 입력기에서 키 이벤트와 글자 이벤트가 둘 다 들어와 두 번 토글되는 것 방지
    _cheat_last_toggle = now
    cheat_on = not cheat_on
    if cheat_on: rank_taint()   # 2.3: 이번 판은 랭킹 제출 안 함

def check_cheat_input(event):
    global _cheat_key_idx, _cheat_text_buf
    if event.type == pygame.KEYDOWN:
        if event.key in (pygame.K_LSHIFT, pygame.K_RSHIFT):
            return
        pressed = (event.key, bool(event.mod & pygame.KMOD_SHIFT))
        if pressed == CHEAT_KEYS[_cheat_key_idx]:
            _cheat_key_idx += 1
            if _cheat_key_idx == len(CHEAT_KEYS):
                _toggle_cheat()
        else:
            _cheat_key_idx = 1 if pressed == CHEAT_KEYS[0] else 0
    elif _EV_TEXTINPUT is not None and event.type == _EV_TEXTINPUT:
        _cheat_text_buf = (_cheat_text_buf + event.text)[-10:]
        if _cheat_text_buf.endswith(CHEAT_WORD):
            _toggle_cheat()
    elif _EV_TEXTEDITING is not None and event.type == _EV_TEXTEDITING:
        # 마지막 글자 '임'은 조합 중 상태라 조합 중인 글자까지 합쳐서 확인
        if event.text and (_cheat_text_buf + event.text).endswith(CHEAT_WORD):
            _toggle_cheat()

dev_mode = False
_dev_combo_prev = False
dev_fps_current = 0
_dev_frame_accum = 0
_dev_timer_start = 0

def check_dev_mode_toggle():
    global dev_mode, _dev_combo_prev
    keys = pygame.key.get_pressed()
    combo_now = ((keys[pygame.K_LCTRL] or keys[pygame.K_RCTRL])
                 and (keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT])
                 and keys[pygame.K_6] and keys[pygame.K_7])
    if combo_now and not _dev_combo_prev:
        dev_mode = not dev_mode
    _dev_combo_prev = combo_now

def update_dev_info(current_tick):
    global dev_fps_current, _dev_frame_accum, _dev_timer_start
    _dev_frame_accum += 1
    if current_tick - _dev_timer_start >= 1000:
        dev_fps_current = _dev_frame_accum
        _dev_frame_accum = 0
        _dev_timer_start = current_tick
    lines = [f"FPS:{dev_fps_current}(limit {FPS})  pos:({player.x:.0f},{player.y:.0f})",
             f"coins:{len(coins)} obs:{len(obstacles)} items:{len(items)}",
             f"combo:{player.combo} hit_ct:{player.combo_hit_count} session_hits:{player.session_hits}"]
    y = HEIGHT - 55
    for line in lines:
        txt = font_small.render(line, True, (0, 255, 0))
        screen.blit(txt, (8, y))
        y += 16

def change_volume(delta):
    global volume
    volume = round(min(1.0, max(0.0, volume + delta)), 2)
    try:
        pygame.mixer.music.set_volume(volume)
    except Exception:
        pass
    save_settings(current_settings_dict())

def toggle_anim():
    global anim_on
    anim_on = not anim_on
    if not anim_on: fx_clear()
    save_settings(current_settings_dict())

def set_net_rate(v):
    global net_rate
    net_rate = v
    save_settings(current_settings_dict())

def toggle_halloween():
    global halloween_on
    halloween_on = not halloween_on
    save_settings(current_settings_dict())

def toggle_twisted():
    global twisted_on
    twisted_on = not twisted_on
    save_settings(current_settings_dict())

def toggle_bgm():
    global bgm_on
    bgm_on = not bgm_on
    try:
        if bgm_on and game_state == "PLAYING":
            pygame.mixer.music.set_volume(volume)
            pygame.mixer.music.play(-1)
        else:
            pygame.mixer.music.stop()
    except Exception:
        pass
    save_settings(current_settings_dict())

def set_fps_limit(v):
    global FPS
    FPS = v
    save_settings(current_settings_dict())
    if add_counter("fps_change_count") >= 5:
        unlock_achievement("fps_changer")
        flush_achievements()

def toggle_lang():
    global lang
    lang = "en" if lang == "ko" else "ko"
    save_settings(current_settings_dict())

def reset_combo():
    player.combo = 0
    player.combo_hit_count = 0

new_record = False
new_record_diff_label = ""
gameover_entered_tick = 0
achievement_toast_until = 0
achievement_toast_msg = ""

def end_game(survived=False, timeout=False):
    global game_state, new_record, new_record_diff_label, dev_streak, gameover_entered_tick, score
    global speedrun_final_sec, speedrun_result_key
    if game_state == "GAMEOVER":
        return  # 같은 프레임 중복 호출 방지
    game_state = "GAMEOVER"
    try:
        pygame.mixer.music.stop()
    except Exception:
        pass
    
    if difficulty == "speedrun":
        speedrun_final_sec = int((pygame.time.get_ticks() - speedrun_start_tick) / 1000)
        if survived:
            new_record = try_update_highscore("speedrun", speedrun_final_sec)
            speedrun_result_key = "speedrun_done"
        else:
            # 실패(사망/시간초과)는 기록 갱신 안 함 - 점수가 시간 기록으로 저장되던 버그 수정
            new_record = False
            speedrun_result_key = "speedrun_timeout" if timeout else "speedrun_fail"
        new_record_diff_label = difficulty
    else:
        new_record = try_update_highscore(difficulty, score)
        new_record_diff_label = difficulty
    rank_on_end()   # 2.3: 신기록이면 온라인 랭킹에 제출

    if score <= 100: rank_msg = "하수"
    elif score <= 200: rank_msg = "중수"
    elif score <= 300: rank_msg = "고수"
    elif score <= 400: rank_msg = "초고수"
    elif score <= 500: rank_msg = "동전게임 프로"
    else: rank_msg = "동전게임 개발자"

    if score >= 401: unlock_achievement("score_401")
    if score >= 501: unlock_achievement("score_501")
    if survived:
        if difficulty == "hell": unlock_achievement("clear_hell")
        if difficulty == "hellhell": unlock_achievement("clear_hellhell")
        if player.session_hits == 0: unlock_achievement("no_hit_clear")
        if anniv_now(): unlock_achievement("anniv_clear")
        if anniv_now() and player.session_hits == 0 and player.session_bubble_hits == 0: unlock_achievement("anniv_nohit")   # 2.4: 기념 기간에 안 맞고 클리어 (거품이 막은 것도 맞은 것으로 침)   # 2.4: 기념 기간에 한 판 클리어하면 꼰대 동전 해금
        if difficulty == "normal":
            if add_mission_counter("normal_clear_count") >= 10: unlock_mission("unlock_zigzag")
        if difficulty == "hard":
            unlock_mission("unlock_split")
        if difficulty == "easy":
            if add_mission_counter("easy_clear_count") >= 10: unlock_mission("unlock_minime")
        if difficulty == "hell":
            if not player.session_shield_used: unlock_mission("unlock_rewind")
            if not player.session_kimchi_used: unlock_mission("unlock_adversity")
    if difficulty == "hellhell" and score >= 300:
        unlock_mission("unlock_hellhellhell")
    # 엔드리스 해금: 순환참조 방지 - 아무 난이도든 누적 20판이면 카운트
    if add_mission_counter("endless_play_count") >= 20:
        unlock_mission("unlock_endless")
    if rank_msg == "동전게임 개발자":
        dev_streak += 1
    else:
        dev_streak = 0
    if dev_streak >= 3:
        unlock_achievement("dev_streak_3")
    save_settings(current_settings_dict())
    flush_achievements()
    flush_missions()
    gameover_entered_tick = pygame.time.get_ticks()

def start_game_with_diff(diff_name):
    global game_state, difficulty, score
    global coins, obstacles, items
    global start_ticks, time_limit_ms, last_hit_time
    global render_count, fps_current, fps_avg, _fps_frame_accum, _fps_timer_start
    global endless_mode, endless_start_tick, speedrun_mode, speedrun_start_tick

    difficulty = diff_name
    game_state = "PLAYING"
    rank_on_start(diff_name)   # 2.3: 랭킹 시작 토큰 (엔드리스/역경/스피드런)

    score = 0
    player.hp = 5
    player.x, player.y = WIDTH // 2 - (TWIN_GAP // 2 if is_twins() else 0), HEIGHT // 2
    coins, obstacles, items = [], [], []
    player.magnet_active = player.slow_active = player.kimchi_active = False
    player.freeze_active = False
    player.goldrush_active = player.minime_active = False
    player.rewind_charges = 0
    player.l_active = False; player.dev_cd_until = 0; player.kk_active = False
    player.bat_count = 0; player.bat_cd_until = 0; player.dodge_until = 0; player.cast_id = 0; player.cast_until = 0
    player.tot_trick = None; player.tot_end_tick = 0; player.tot_msg = ""; player.tot_msg_until = 0
    player.pos_history = []
    if cheat_on:  # 똥쩐꼐임: 시작부터 자석+김치 30초
        player.magnet_active = True
        player.magnet_end_tick = pygame.time.get_ticks() + CHEAT_MAGNET_MS
        player.kimchi_active = True
        player.kimchi_end_tick = pygame.time.get_ticks() + CHEAT_KIMCHI_MS
        player.goldrush_active = True
        player.goldrush_end_tick = pygame.time.get_ticks() + CHEAT_GOLDRUSH_MS
    player.shield_count = 0
    last_hit_time = 0
    player.reset_session_flags()
    
    player.sister_charges = SISTER_IMMUNITY if equipped_skin == "sister" else 0
    global uncle_speed_mult, uncle_roll_at
    uncle_speed_mult = 1.0; uncle_roll_at = 0
    if equipped_skin == "dad": player.hp = 6
    if equipped_skin == "grandpa": player.shield_count = 3
    if equipped_skin == "halloween": player.shield_count = 1   # 2.0.2 할로윈 동전: 시작 실드 1개
    player.bubble = False; player.bubble_at = 0; player.bubble_left = 0
    if equipped_skin == "submarine": bubble_init(player)   # 2.4 잠수함 동전
    
    endless_mode = False
    speedrun_mode = False
    if difficulty == "endless":
        endless_mode = True
        endless_start_tick = pygame.time.get_ticks()
    elif difficulty == "speedrun":
        speedrun_mode = True
        speedrun_start_tick = pygame.time.get_ticks()
    
    reset_combo()
    fx_clear()
    hud_prev.clear(); hud_prev.update(k for k, _ in hud_active(pygame.time.get_ticks()))   # 시작 시점에 이미 켜진 효과는 링 없이 표시

    start_ticks = pygame.time.get_ticks()
    cfg = diff_settings.get(difficulty, diff_settings["normal"])
    time_limit_ms = cfg["time"] * 1000
    render_count = 0
    fps_current = 0
    fps_avg = 0
    _fps_frame_accum = 0
    _fps_timer_start = start_ticks

    try:
        if bgm_on:
            pygame.mixer.music.set_volume(volume)
            pygame.mixer.music.play(-1)
        else:
            pygame.mixer.music.stop()
    except Exception:
        pass

# ===================== 2.1 VERSUS : 2인 대결 (한 키보드, 같은 화면) =====================
# 싱글 코드는 건드리지 않고, 대결 전용 함수들로 따로 구현.
# 대결 중에는 '지금 처리하는 플레이어'를 전역(player, equipped_skin, uncle_*)에 잠시 연결(vs_bind)해서
# 기존 eff_*, player_bodies, sister_save_combo, resolve_tot, dev_clear 등을 그대로 재사용한다.
VS_TIME_MS = 30000          # 제한 시간
VS_COUNTDOWN_MS = 3000      # 3-2-1
VS_NICK_MAX = 8             # 닉네임 최대 글자 수 (한글/영어/숫자)
VS_COIN_RATE_MULT = 1.0     # 코인 스폰량 배율 (보통 난이도와 같음)
VS_END_DELAY_MS = 900       # 둘 다 죽으면 터지는 연출을 보여 준 뒤 결과 화면으로
VS_COLORS = [(90, 170, 255), (255, 90, 90)]   # 1P 파랑 / 2P 빨강
VS_TAGS = ["1P", "2P"]
VS_MOVE_KEYS = [(pygame.K_a, pygame.K_d, pygame.K_w, pygame.K_s),               # (왼, 오른, 위, 아래)
                (pygame.K_LEFT, pygame.K_RIGHT, pygame.K_UP, pygame.K_DOWN)]
VS_KEYS_HP2SCORE = [(pygame.K_SPACE,), (pygame.K_RETURN, pygame.K_KP_ENTER)]   # 체력 1 -> 점수 5
VS_KEYS_SCORE2HP = [(pygame.K_LSHIFT,), (pygame.K_RSHIFT,)]                     # 점수 5 -> 체력 1
VS_DEV_KEY = [(pygame.K_r, "KSCAN_R"), (pygame.K_o, "KSCAN_O")]                 # 개발자 동전 능력 키
VS_DEV_KEY_NAME = ["R", "O"]
VS_BAT_KEY = [(pygame.K_t, "KSCAN_T"), (pygame.K_i, "KSCAN_I")]                   # 2.4 빠따 아이템 키
VS_GLOBAL_ITEMS = ("slow", "timefreeze", "goldrush")   # 두 사람 모두에게 적용되는 아이템

# 스킨 선택 화면 배치
VS_ROW_Y0 = [66, 216]                       # 1P / 2P 줄의 윗쪽 y
VS_SKIN_X0, VS_SKIN_STEP, VS_CELL = 196, 37, 34   # 2.4: 스킨 14종까지 한 줄에 들어가도록 간격 축소
VS_NICK_RECT = [pygame.Rect(18, VS_ROW_Y0[0] + 30, 150, 30), pygame.Rect(18, VS_ROW_Y0[1] + 30, 150, 30)]

vs_choice = [equipped_skin, "normal"]       # 각 플레이어가 고른 스킨
vs_nick = [str(_settings.get("nick", ""))[:8], ""]   # 닉네임 (비면 1P/2P) - 2.3: 첫 칸은 저장됨 (온라인 대결/랭킹 공용)
vs_names_override = None                    # 2.2 온라인: [방장 닉네임, 게스트 닉네임] (None이면 vs_nick 사용)
vs_ready = [False, False]
vs_edit = None                              # 닉네임 입력 중인 줄 (0 / 1 / None)
vs_ime = ""                                 # 한글 조합 중인 글자 (표시용)
vs_slots = []
vs_world = {}                               # 전체에 적용 중인 아이템: {"slow": (끝 tick, 먹은 사람), ...}
vs_start_tick = 0
vs_cd_start = 0
vs_flip = False                             # 같은 프레임 처리 순서를 번갈아 바꿔 공정하게
vs_end_at = 0
vs_result = {}
vs_saved = {}
_vs_pv_cache = {}


def vs_name(i):
    if vs_names_override: return (vs_names_override[i] or "").strip() or VS_TAGS[i]
    return vs_nick[i].strip() or VS_TAGS[i]

def vs_key_is(event, key, scan_name):
    """키 코드 또는 (한글 입력기가 켜져 있을 때를 위해) 물리 키 위치로 확인"""
    return event.key == key or getattr(event, "scancode", -1) == getattr(pygame, scan_name, -2)

def vs_bodies(s):
    ps = s["ps"]
    return [(ps.x, ps.y), (ps.x + TWIN_GAP, ps.y)] if s["skin"] == "twins" else [(ps.x, ps.y)]

def vs_bind(s):
    global player, equipped_skin, uncle_speed_mult, uncle_roll_at
    player = s["ps"]; equipped_skin = s["skin"]
    uncle_speed_mult = s["uncle_mult"]; uncle_roll_at = s["uncle_roll"]

def vs_unbind(s):
    s["uncle_mult"] = uncle_speed_mult; s["uncle_roll"] = uncle_roll_at


# ---------------- 화면 전환 ----------------
def set_state_play_type():
    global game_state
    game_state = "PLAY_TYPE"

def vs_stop_edit():
    global vs_edit, vs_ime
    vs_edit = None; vs_ime = ""

def vs_start_edit(i):
    global vs_edit, vs_ime
    vs_edit = i; vs_ime = ""
    try:
        pygame.key.start_text_input()
        pygame.key.set_text_input_rect(VS_NICK_RECT[i])
    except Exception:
        pass

def set_state_vs_setup():
    global game_state
    vs_stop_edit()
    vs_ready[0] = vs_ready[1] = False
    for i in range(2):
        if not is_skin_unlocked(vs_choice[i]):
            vs_choice[i] = "normal"
    game_state = "VS_SETUP"

def vs_char_ok(ch):
    o = ord(ch)
    return (ch.isascii() and ch.isalnum()) or 0xAC00 <= o <= 0xD7A3 or 0x3131 <= o <= 0x3163   # 영어/숫자/한글(음절·자모)

def vs_text_input(text):
    if vs_edit is None: return
    for ch in text:
        if len(vs_nick[vs_edit]) >= VS_NICK_MAX: break
        if vs_char_ok(ch): vs_nick[vs_edit] += ch

def vs_skin_rect(i, k):
    cx = VS_SKIN_X0 + k * VS_SKIN_STEP + VS_SKIN_STEP // 2
    return pygame.Rect(cx - VS_CELL // 2, VS_ROW_Y0[i] + 45 - VS_CELL // 2, VS_CELL, VS_CELL)

def vs_setup_event(event):
    global vs_ime
    for btn in vs_setup_buttons:
        btn.check_event(event)
    if event.type == pygame.TEXTINPUT:
        vs_text_input(event.text); vs_ime = ""
    elif event.type == pygame.TEXTEDITING:
        vs_ime = event.text if vs_edit is not None else ""
    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        hit = [i for i in range(2) if VS_NICK_RECT[i].collidepoint(event.pos)]
        if hit:
            if vs_edit != hit[0]: vs_start_edit(hit[0])
            return
        vs_stop_edit()
        for i in range(2):
            for k, sid in enumerate(SKIN_ORDER):
                if vs_skin_rect(i, k).collidepoint(event.pos) and is_skin_unlocked(sid):
                    vs_choice[i] = sid; vs_ready[i] = False
    elif event.type == pygame.KEYDOWN:
        if vs_edit is not None:   # 입력 중에는 Q/Enter가 글자(또는 입력 종료)로만 쓰임
            if event.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER):
                vs_stop_edit()
            elif event.key == pygame.K_BACKSPACE and not vs_ime:
                vs_nick[vs_edit] = vs_nick[vs_edit][:-1]
            return
        if vs_key_is(event, pygame.K_q, "KSCAN_Q"):
            vs_ready[0] = not vs_ready[0]
        elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            vs_ready[1] = not vs_ready[1]
        else:
            return
        if vs_ready[0] and vs_ready[1]:
            start_vs_countdown()


# ---------------- 대결 시작 / 종료 ----------------
def start_vs_countdown():
    """두 플레이어를 만들고 3-2-1 카운트다운 시작 (이 동안은 움직이지 않음)"""
    global game_state, vs_cd_start, versus_mode, vs_slots, vs_world, vs_flip, vs_end_at
    global coins, obstacles, items, difficulty, cheat_on
    vs_stop_edit()
    vs_saved.clear()
    vs_saved.update(player=player, skin=equipped_skin, cheat=cheat_on, unc_m=uncle_speed_mult, unc_r=uncle_roll_at, diff=difficulty)
    versus_mode = True
    difficulty = "normal"
    cheat_on = False   # 대결에는 치트(똥쩐꼐임) 없음
    coins, obstacles, items = [], [], []
    vs_world = {}; vs_flip = False; vs_end_at = 0
    fx_clear()
    vs_slots = []
    for i in range(2):
        sk = vs_choice[i]
        ps = PlayerState()
        ps.x = WIDTH * (0.25 if i == 0 else 0.75) - (TWIN_GAP / 2 if sk == "twins" else 0)
        ps.y = HEIGHT // 2
        ps.hp = 6 if sk == "dad" else 5
        if sk == "grandpa": ps.shield_count = 3
        if sk == "halloween": ps.shield_count = 1
        if sk == "submarine": bubble_init(ps)
        ps.sister_charges = SISTER_IMMUNITY if sk == "sister" else 0
        vs_slots.append({"i": i, "skin": sk, "ps": ps, "score": 0, "alive": True, "last_coin": 0, "last_hit": 0,
                         "uncle_mult": 1.0, "uncle_roll": 0, "blink_until": 0, "hud_total": {}})
    vs_cd_start = pygame.time.get_ticks()
    game_state = "VS_COUNTDOWN"

def update_vs_countdown(now):
    global game_state, vs_start_tick
    if now - vs_cd_start < VS_COUNTDOWN_MS: return
    vs_start_tick = now
    game_state = "VERSUS"
    try:
        if bgm_on:
            pygame.mixer.music.set_volume(volume)
            pygame.mixer.music.play(-1)
        else:
            pygame.mixer.music.stop()
    except Exception:
        pass

def end_versus():
    """승패 판정 + 전역 상태 복구. end_game()은 부르지 않음 (최고기록/업적/미션에 아무것도 기록하지 않기 위해)"""
    global game_state, versus_mode, player, equipped_skin, cheat_on, uncle_speed_mult, uncle_roll_at, difficulty, vs_result
    if game_state not in ("VERSUS", "VS_COUNTDOWN"): return
    sc = [s["score"] for s in vs_slots]
    winner = None if sc[0] == sc[1] else (0 if sc[0] > sc[1] else 1)
    vs_result = {"scores": sc, "winner": winner, "names": [vs_name(0), vs_name(1)], "skins": [s["skin"] for s in vs_slots]}
    player = vs_saved["player"]; equipped_skin = vs_saved["skin"]; cheat_on = vs_saved["cheat"]
    uncle_speed_mult = vs_saved["unc_m"]; uncle_roll_at = vs_saved["unc_r"]; difficulty = vs_saved["diff"]
    versus_mode = False
    try:
        pygame.mixer.music.stop()
    except Exception:
        pass
    fx_clear()
    game_state = "VS_RESULT"

def vs_kill(s, now):
    """체력 0: 스킨이 터지며 사라지고, 이 플레이어가 켜 둔 효과는 모두 정리"""
    s["alive"] = False
    ps = s["ps"]
    if anim_on:
        for bx, by in vs_bodies(s):
            fx_ring(bx, by, VS_COLORS[s["i"]], now, r1=80, life=650)
            for n in range(26):
                fx_trim(fx_particles, FX_MAX_PARTICLES)
                ang, sp = random.uniform(0, 2 * math.pi), random.uniform(80, 240)
                fx_particles.append({"x": bx, "y": by, "vx": math.cos(ang) * sp, "vy": math.sin(ang) * sp, "born": now,
                                     "life": random.randint(500, 900), "rgb": VS_COLORS[s["i"]] if n % 3 else (255, 255, 255)})
    ps.hp = 0
    ps.magnet_active = ps.slow_active = ps.kimchi_active = ps.freeze_active = ps.goldrush_active = ps.minime_active = False
    ps.bubble = False; ps.bubble_at = 0
    ps.l_active = False; ps.kk_active = False; ps.tot_trick = None; ps.shield_count = 0; ps.rewind_charges = 0
    for k in list(vs_world):
        if vs_world[k][1] == s["i"]: del vs_world[k]

def vs_fx_hit(s, now):
    s["blink_until"] = now + INV_SEC
    if not anim_on: return
    fx_ring(player.x, player.y, (255, 60, 60), now, r1=44, life=400)
    fx_burst(player.x, player.y, (255, 90, 90), 6, now)

def vs_choose_item_type():
    """choose_item_type()의 대결 버전 (골드러시 중 자석 제외 규칙을 '전체' 기준으로)"""
    pool = list(ITEM_TYPES)
    if "goldrush" in vs_world: pool.remove("magnet")
    pool.append("l")
    pool.append("bat")
    if halloween_now(): pool.append("tot")
    for nt in NEW_ITEM_TYPES:
        if nt == "goldrush": continue   # 2.3: 대결(로컬/온라인)에서는 골드러시 제외 (싱글에서는 그대로)
        if mission_unlocked.get(NEW_ITEM_MISSION[nt]): pool.append(nt)
    return random.choice(pool)


# ---------------- 대결 중 입력 ----------------
def vs_apply_action(s, action, now):
    """2.2: 입력 -> 행동 적용을 분리 (로컬 키보드 / 온라인 네트워크 입력 공용).
    action: "ss"(점수->체력), "sh"(체력->점수), "dev"(개발자 동전 능력)"""
    if not s["alive"]: return
    ps = s["ps"]
    if action == "ss":
        if s["score"] >= 5:
            s["score"] -= 5; ps.hp += 1
    elif action == "sh":
        if ps.hp > 1:   # 대결에서는 이 교환으로 스스로 0이 되지는 않음
            ps.hp -= 1; s["score"] += 5
    elif action == "dev":
        if skin_has_o(s["skin"]):
            vs_bind(s); o_ability(now); vs_unbind(s)
            vs_bat_strike(s, now)
    elif action == "bat":
        vs_bind(s); bat_item_use(now); vs_unbind(s)
        vs_bat_strike(s, now)

def vs_take_hit(o, now):
    """빠따에 맞음: 장애물 피격과 똑같이 처리 (무적시간 / 김치 / 실드 / 거품 / HP -1)"""
    vs_bind(o)
    try:
        if now < player.dodge_until: return
        if hit_ignore_chance(equipped_skin) > 0 and random.random() < hit_ignore_chance(equipped_skin): return
        if now - o["last_hit"] < INV_SEC: return
        o["last_hit"] = now
        if player.kimchi_active:
            pass
        elif player.shield_count > 0:
            player.shield_count -= 1
            fx_shield_block(now)
        elif bubble_block(now):
            fx_shield_block(now)
        else:
            player.hp -= 1
            vs_fx_hit(o, now)
            player.combo_hit_count += 1
            if player.combo_hit_count >= 2:
                if sister_save_combo(): player.combo_hit_count = 0
                else: reset_combo()
            if player.hp <= 0:
                vs_kill(o, now)
    finally:
        vs_unbind(o)

def vs_bat_strike(s, now):
    """s 가 빠따를 휘둘렀다면: 반경 안의 상대를 맞힘"""
    global bat_pending
    if not bat_pending: return
    bat_pending = False
    me = s["ps"]
    for o in vs_slots:
        if o is s or not o["alive"]: continue
        if any(math.hypot(bx - me.x, by - me.y) <= BAT_RADIUS + PLAYER_R for bx, by in vs_bodies(o)):
            vs_take_hit(o, now)

def vs_key_action(event, i):
    """KEYDOWN 이벤트가 i번 플레이어의 어떤 행동인지 (없으면 None)"""
    if event.key in VS_KEYS_SCORE2HP[i]: return "ss"
    if event.key in VS_KEYS_HP2SCORE[i]: return "sh"
    if vs_key_is(event, *VS_DEV_KEY[i]): return "dev"
    if vs_key_is(event, *VS_BAT_KEY[i]): return "bat"
    return None

def vs_game_event(event, now):
    if event.type != pygame.KEYDOWN: return
    if net_playing:   # 2.2 온라인(방장): 내 키만, 내 캐릭터(0번)만
        online_game_event(event, now)
        return
    for s in vs_slots:
        if not s["alive"]: continue
        a = vs_key_action(event, s["i"])
        if a: vs_apply_action(s, a, now)

def vs_local_inputs():
    """2.2: 이동 입력을 키보드에서 읽어 플레이어별 입력 상태로 만듦 (dx, dy는 -1/0/1)"""
    keys = pygame.key.get_pressed()
    out = []
    for i in range(2):
        lk, rk, uk, dk = VS_MOVE_KEYS[i]
        out.append({"dx": (1 if keys[rk] else 0) - (1 if keys[lk] else 0),
                    "dy": (1 if keys[dk] else 0) - (1 if keys[uk] else 0)})
    return out


# ---------------- 대결 중 갱신 ----------------
def vs_move(s, inp, now, dt_scale):
    """(vs_bind 된 상태에서) 이동 + 만료된 효과 정리. inp = {"dx","dy"} (2.2: 키보드가 아니라 입력 상태를 읽음)"""
    global uncle_speed_mult, uncle_roll_at
    dx, dy = inp["dx"], inp["dy"]
    if player.tot_trick == "invert":
        dx = -dx; dy = -dy
    if dx != 0 and dy != 0:
        dx *= 0.7071; dy *= 0.7071
    if equipped_skin == "uncle" and now >= uncle_roll_at:
        uncle_speed_mult = random.uniform(*UNCLE_SPEED_RANGE); uncle_roll_at = now + UNCLE_ROLL_MS
    eff_spd = PLAYER_SPD * 2 if ach_unlocked.get("dev_streak_3") else PLAYER_SPD
    eff_spd = eff_move_speed(eff_spd)
    player.x += dx * eff_spd * dt_scale
    player.y += dy * eff_spd * dt_scale
    right_extra = TWIN_GAP if is_twins() else 0
    player.x = min(max(player.x, PLAYER_R), WIDTH - PLAYER_R - right_extra)
    player.y = min(max(player.y, PLAYER_R), HEIGHT - PLAYER_R)
    player.pos_history.append((now, player.x, player.y))
    while player.pos_history and now - player.pos_history[0][0] > REWIND_LOOKBACK_MS + 500:
        player.pos_history.pop(0)
    if player.magnet_active and now > player.magnet_end_tick: player.magnet_active = False
    if player.kimchi_active and now > player.kimchi_end_tick: player.kimchi_active = False
    if player.minime_active and now > player.minime_end_tick: player.minime_active = False
    if player.l_active and now > player.l_end_tick: player.l_active = False
    if player.kk_active and now > player.kk_end_tick: player.kk_active = False
    bubble_tick(now)
    if player.tot_trick and now > player.tot_end_tick: player.tot_trick = None
    if player.combo > 0 and now - s["last_coin"] > eff_combo_window_ms():
        if sister_save_combo(): s["last_coin"] = now
        else: reset_combo()

def vs_pull_coins(slow_mult, dt_scale):
    """(vs_bind 된 상태에서) 자석 / 반려동전 자동 자석"""
    if not (player.magnet_active or equipped_skin == "puppy"): return
    mag_range = eff_magnet_range() * (PUPPY_MAGNET_RATIO if not player.magnet_active else 1)
    bodies = player_bodies()
    for coin in coins:
        if coin["kind"] == "bomb": continue
        dist, bx, by = min((math.hypot(bx_ - coin["x"], by_ - coin["y"]), bx_, by_) for bx_, by_ in bodies)
        if dist < mag_range:
            pull = 7 * slow_mult * dt_scale
            coin["x"] += ((bx - coin["x"]) / (dist + 0.1)) * pull
            coin["y"] += ((by - coin["y"]) / (dist + 0.1)) * pull

def vs_collect(s, now):
    """(vs_bind 된 상태에서) 코인 / 아이템 / 장애물 충돌. 먼저 닿은 사람이 가져감"""
    global coins, items
    i = s["i"]
    for coin in coins[:]:
        if player_dist(coin["x"], coin["y"]) < (eff_player_r() + coin["r"]):
            if coin["kind"] == "bomb":
                bpos, had_combo = (coin["x"], coin["y"]), player.combo
                coins.remove(coin)
                immune = sister_save_combo()
                if not immune: reset_combo()
                fx_bomb_pickup(bpos, had_combo, immune, now)
                continue
            if now - s["last_coin"] > eff_combo_window_ms() and not sister_save_combo():
                player.combo = 0
            player.combo += 1
            s["last_coin"] = now
            gain = 1 + player.combo // eff_combo_bonus_step()
            g = gain * GOLD_COIN_SCORE_MULT if coin["kind"] == "gold" else gain
            s["score"] += g
            fx_coin_pickup((coin["x"], coin["y"]), g, coin["kind"] == "gold", now)
            coins.remove(coin)

    for item in items[:]:
        if player_dist(item["x"], item["y"]) < (eff_player_r() + 12):
            itype = item["type"]
            if itype == "magnet":
                if "goldrush" not in vs_world:
                    player.magnet_active = True
                    player.magnet_end_tick = now + eff_item_duration_ms(MAGNET_DURATION_MS)
            elif itype in VS_GLOBAL_ITEMS:   # 슬로우 / 타임프리즈 / 골드러시: 두 사람 모두에게 적용
                dur = SLOW_DURATION_MS if itype == "slow" else NEW_ITEM_DURATION_MS
                vs_world[itype] = (now + eff_item_duration_ms(dur), i)
                if itype == "goldrush":
                    for o in vs_slots: o["ps"].magnet_active = False
            elif itype == "shield":
                player.shield_count += 1
            elif itype == "heal":
                player.hp += 1
            elif itype == "kimchi":
                player.kimchi_active = True
                player.kimchi_end_tick = now + eff_item_duration_ms(KIMCHI_DURATION_MS)
            elif itype == "minime":
                player.minime_active = True
                player.minime_end_tick = now + eff_item_duration_ms(NEW_ITEM_DURATION_MS)
            elif itype == "rewind":
                player.rewind_charges += 1
            elif itype == "l":
                player.l_active = True
                player.l_start_tick = now
                player.l_end_tick = now + L_DURATION_MS
            elif itype == "bat":
                player.bat_count = BAT_ITEM_USES
            elif itype == "tot":
                s["score"] += resolve_tot(item["x"], item["y"], now)
            fx_item_pickup(itype, (item["x"], item["y"]), now)
            items.remove(item)

    for ob in obstacles[:]:
        if player_dist(ob["x"], ob["y"]) < (eff_player_r() + ob["r"]):
            if now < player.dodge_until: continue   # 2.4 정윤재 샨셴부
            if hit_ignore_chance(equipped_skin) > 0:
                if "ignore" not in ob:
                    ob["ignore"] = random.random() < hit_ignore_chance(equipped_skin)
                if ob["ignore"]:
                    continue
            if player.rewind_charges > 0:
                target = None
                for tck, px, py in reversed(player.pos_history):
                    if now - tck >= REWIND_LOOKBACK_MS:
                        target = (px, py)
                        break
                if target:
                    player.x, player.y = target
                player.rewind_charges -= 1
                obstacles.remove(ob)
                continue
            obstacles.remove(ob)
            if now - s["last_hit"] >= INV_SEC:
                s["last_hit"] = now
                if player.kimchi_active:
                    pass
                elif player.shield_count > 0:
                    player.shield_count -= 1
                    fx_shield_block(now)
                elif bubble_block(now):
                    fx_shield_block(now)
                else:
                    player.hp -= 1
                    vs_fx_hit(s, now)
                    player.combo_hit_count += 1
                    if player.combo_hit_count >= 2:
                        if sister_save_combo(): player.combo_hit_count = 0
                        else: reset_combo()
                    if player.hp <= 0:
                        vs_kill(s, now)
                        return

def update_versus(now, dt_scale, inputs=None):
    global coins, obstacles, items, vs_flip, vs_end_at
    if now - vs_start_tick >= VS_TIME_MS:
        end_versus(); return
    cfg = diff_settings["normal"]
    for k in list(vs_world):
        if now > vs_world[k][0]: del vs_world[k]
    slow_mult = SLOW_FACTOR if "slow" in vs_world else 1.0
    gold = "goldrush" in vs_world
    vs_flip = not vs_flip
    order = (0, 1) if vs_flip else (1, 0)
    if inputs is None: inputs = vs_local_inputs()   # 2.2: 온라인에서는 방장이 (내 키보드 + 받은 게스트 입력)을 넘김

    for i in order:   # 이동 + 효과 만료
        s = vs_slots[i]
        if s["alive"]:
            vs_bind(s); vs_move(s, inputs[i], now, dt_scale); vs_unbind(s)

    for _ in range(GOLDRUSH_COIN_ROLLS if gold else 1):   # 스폰 (코인 / 장애물 / 아이템은 하나뿐인 공용 필드)
        if random.random() < dt_scale / 5 * VS_COIN_RATE_MULT:
            spawn_coin(cfg["coin_diff"], now)
    if random.random() < dt_scale / cfg["ob_chance"]:
        spawn_obstacle(cfg["max_ob_spd"], now)
    if random.random() < dt_scale / ITEM_SPAWN_CHANCE:
        items.append({"x": float(WIDTH + 100), "y": random.randint(50, HEIGHT - 50), "type": vs_choose_item_type()})

    for i in order:   # 자석
        s = vs_slots[i]
        if s["alive"]:
            vs_bind(s); vs_pull_coins(slow_mult, dt_scale); vs_unbind(s)

    for coin in coins:
        coin["x"] -= coin["speed"] * slow_mult * dt_scale
    coins = [c for c in coins if c["x"] > -100 and not (c["kind"] == "gold" and now >= c["expire"])]

    update_splits(now)
    if "timefreeze" not in vs_world:
        ob_mult = slow_mult
        zz_dph = 2 * math.pi * (dt_scale / REFERENCE_FPS) / ZIGZAG_PERIOD_SEC * ob_mult
        turn_max = math.radians(L_TURN_DEG) * (dt_scale / REFERENCE_FPS) * ob_mult
        l_bodies = []   # L 아이템을 먹은 (살아 있는) 플레이어를 향해서만 장애물이 따라붙음
        for s in vs_slots:
            if s["alive"] and s["ps"].l_active: l_bodies += vs_bodies(s)
        for ob in obstacles:
            if (l_bodies or "hd" in ob) and not (ob["kind"] == "split" and ob["gen"] > 0):
                h = ob.get("hd", -math.pi / 2)
                if l_bodies:
                    tx, ty = min(l_bodies, key=lambda b: (b[0] - ob["x"]) ** 2 + (b[1] - ob["y"]) ** 2)
                    want = math.atan2(ty - ob["y"], tx - ob["x"])
                else:
                    want = -math.pi / 2
                diff = (want - h + math.pi) % (2 * math.pi) - math.pi
                h = want if abs(diff) <= turn_max else h + math.copysign(turn_max, diff)
                if not l_bodies and h == want: ob.pop("hd", None)
                else: ob["hd"] = h
                v = ob["speed"] * ob_mult * dt_scale
                if ob["kind"] == "zigzag": ob["bx"] += math.cos(h) * v
                else: ob["x"] += math.cos(h) * v
                ob["y"] += math.sin(h) * v
            else:
                ob["y"] -= ob["speed"] * ob_mult * dt_scale
            if ob["kind"] == "zigzag":
                ob["ph"] += zz_dph
                ob["x"] = ob["bx"] + ZIGZAG_AMP * math.sin(ob["ph"])
    if "timefreeze" not in vs_world:   # 2.4 꼰대 동전: 능력 중인 (살아 있는) 플레이어 주변 장애물 밀어내기
        kk_b = []
        for s in vs_slots:
            if s["alive"] and s["ps"].kk_active: kk_b += vs_bodies(s)
        if kk_b: kk_push(kk_b, dt_scale, slow_mult)
    obstacles = [o for o in obstacles if o["y"] > -100]
    obstacles = [o for o in obstacles if not ("hd" in o and (o["x"] < -200 or o["x"] > WIDTH + 200 or o["y"] > HEIGHT + 300))]

    for item in items:
        item["x"] -= 5 * slow_mult * dt_scale
    items = [it for it in items if it["x"] > -100]

    for i in order:   # 획득 / 충돌 (처리 순서는 프레임마다 번갈아)
        s = vs_slots[i]
        if s["alive"]:
            vs_bind(s); vs_collect(s, now); vs_unbind(s)

    if not any(s["alive"] for s in vs_slots):
        if not vs_end_at: vs_end_at = now + VS_END_DELAY_MS
        elif now >= vs_end_at: end_versus()


# ---------------- 그리기 ----------------
def vs_preview(sid, unlocked, box=40):
    """스킨 미리보기 이미지 (잠금이면 실루엣). 너무 크면 box 안으로 축소"""
    info = SKIN_MAP[sid]
    pv = info.get("preview_key", info["image_key"])
    key = pv if unlocked else "sil_" + pv
    surf = img.get(key)
    if not surf: return None
    ck = (key, box)
    if ck not in _vs_pv_cache:
        w, h = surf.get_size()
        k = min(1.0, box / max(w, h))
        _vs_pv_cache[ck] = surf if k >= 1.0 else pygame.transform.smoothscale(surf, (max(1, int(w * k)), max(1, int(h * k))))
    return _vs_pv_cache[ck]

def draw_play_type():
    draw_text_center(screen, font_large, t("play_type_title"), WHITE, (WIDTH // 2, 90))
    for b in play_type_buttons:
        b.draw(screen)

def draw_vs_setup(now):
    draw_text_center(screen, font_large, t("vs_title"), WHITE, (WIDTH // 2, 34))
    for i in range(2):
        col, y0 = VS_COLORS[i], VS_ROW_Y0[i]
        screen.blit(font_mid.render(VS_TAGS[i], True, col), (18, y0))
        # 닉네임 칸
        rc = VS_NICK_RECT[i]
        pygame.draw.rect(screen, (0, 0, 70), rc, border_radius=4)
        pygame.draw.rect(screen, col if vs_edit == i else GRAY, rc, 2, border_radius=4)
        if vs_edit == i:
            ime = vs_ime if sys.platform != "emscripten" or all(0xAC00 <= ord(c) <= 0xD7A3 for c in vs_ime) else ""   # 웹 폰트에는 낱자(ㅎ)가 없어서 완성된 글자만 보여 줌
            shown = vs_nick[i] + ime + ("|" if (now // 450) % 2 == 0 else "")
            screen.blit(font_small.render(shown, True, WHITE), font_small.render(shown, True, WHITE).get_rect(midleft=(rc.x + 8, rc.centery)))
        elif vs_nick[i]:
            screen.blit(font_small.render(vs_nick[i], True, WHITE), font_small.render(vs_nick[i], True, WHITE).get_rect(midleft=(rc.x + 8, rc.centery)))
        else:
            hint = font_small.render(t("vs_nick_hint"), True, (130, 130, 130))
            screen.blit(hint, hint.get_rect(midleft=(rc.x + 8, rc.centery)))
        # READY 표시
        if vs_ready[i]:
            draw_text_center(screen, font_small, "READY!", (120, 255, 120), (rc.centerx, rc.bottom + 16))
        else:
            draw_text_center(screen, font_buff, "Q : READY" if i == 0 else "Enter : READY", GRAY, (rc.centerx, rc.bottom + 16))
        # 스킨 고르기
        for k, sid in enumerate(SKIN_ORDER):
            cell = vs_skin_rect(i, k)
            unlocked = is_skin_unlocked(sid)
            pygame.draw.rect(screen, (0, 0, 96) if unlocked else (0, 0, 60), cell, border_radius=5)
            pv_surf = vs_preview(sid, unlocked)
            if pv_surf: screen.blit(pv_surf, pv_surf.get_rect(center=cell.center))
            if vs_choice[i] == sid:
                pygame.draw.rect(screen, col, cell, 3, border_radius=5)
            else:
                pygame.draw.rect(screen, (16, 16, 48), cell, 1, border_radius=5)
        info = SKIN_MAP[vs_choice[i]]
        screen.blit(font_small.render(info["label"][lang], True, col), (VS_SKIN_X0, y0 + 76))
        ab = f"{t('ability')}: {info['ability'][lang]}"
        screen.blit(font_buff.render(ab, True, GRAY), (VS_SKIN_X0, y0 + 98))
    draw_text_center(screen, font_buff, t("vs_controls_1p"), VS_COLORS[0], (WIDTH // 2, 372))
    draw_text_center(screen, font_buff, t("vs_controls_2p"), VS_COLORS[1], (WIDTH // 2, 392))
    draw_text_center(screen, font_buff, t("vs_pick_hint"), GRAY, (WIDTH // 2, 418))
    for b in vs_setup_buttons:
        b.draw(screen)

def vs_draw_world(now):
    # 코인은 골드러시 때 수백 개가 되므로, 코인마다 함수를 부르지 않고 그릴 목록을 모아서 한 번에 그림 (느린 기기에서 프레임 유지)
    s_n, s_g, s_b = img.get("coin"), img.get("coin_gold"), img.get("coin_bomb")
    hn = (s_n.get_width() / 2, s_n.get_height() / 2) if s_n else (0, 0)
    hg = (s_g.get_width() / 2, s_g.get_height() / 2) if s_g else (0, 0)
    hb = (s_b.get_width() / 2, s_b.get_height() / 2) if s_b else (0, 0)
    seq = []
    for coin in coins:
        kd = coin["kind"]
        if kd == "gold":
            if coin["expire"] - now <= GOLD_COIN_BLINK_MS and (now // 100) % 2:
                continue
            surf, h, col = s_g, hg, (255, 215, 0)
        elif kd == "bomb":
            surf, h, col = s_b, hb, (60, 60, 60)
        else:
            surf, h, col = s_n, hn, ORANGE
        if surf:
            seq.append((surf, (int(coin["x"] - h[0]), int(coin["y"] - h[1]))))
        else:
            pygame.draw.circle(screen, col, (int(coin["x"]), int(coin["y"])), coin["r"])
    if seq:
        if hasattr(screen, "blits"): screen.blits(seq, False)
        else:
            for sf, pos in seq: screen.blit(sf, pos)
    for ob in obstacles:
        if ob["kind"] == "zigzag":
            ob_key, ob_col = ob_img("ob_zigzag"), (80, 230, 80)
        elif ob["kind"] == "split":
            ob_key, ob_col = ob_img(f"ob_split_{ob['gen']}"), (230, 70, 70)
        else:
            ob_key, ob_col = ob_img("obstacle"), YELLOW
        draw_sprite_or_fallback(ob_key, ob["x"], ob["y"],
                                lambda o=ob, col=ob_col: pygame.draw.rect(screen, col, pygame.Rect(o["x"] - o["r"], o["y"] - o["r"], o["r"] * 2, o["r"] * 2)))
    for item in items:
        key = f"item_{item['type']}"
        draw_sprite_or_fallback(key, item["x"], item["y"],
                                lambda it=item, col=FALLBACK_COLOR.get(key, WHITE): pygame.draw.circle(screen, col, (int(it["x"]), int(it["y"])), 12))

def vs_draw_players(now):
    for s in vs_slots:
        if not s["alive"]: continue
        ps, sk = s["ps"], s["skin"]
        p_key = SKIN_MAP.get(sk, SKIN_MAP["normal"])["image_key"]
        if ps.shield_count > 0:
            k2 = f"p_{sk}_shield"
            p_key = k2 if img.get(k2) else "p_shield"
        if ps.kimchi_active:
            k2 = f"p_{sk}_kimchi"
            p_key = k2 if img.get(k2) else "p_kimchi"
        p_color = RED if p_key == "p_normal" else (GRAY if "shield" in p_key else ORANGE)
        hide = anim_on and now < s["blink_until"] and (now // 80) % 2 == 1
        bodies = vs_bodies(s)
        if not hide:
            for bx, by in bodies:
                draw_sprite_or_fallback(p_key, bx, by, lambda bx=bx, by=by, c=p_color: pygame.draw.circle(screen, c, (int(bx), int(by)), PLAYER_R))
            if sk == "submarine": draw_bubble(ps.x, ps.y, ps.bubble, ps.bubble_at, now)
        # 캐릭터 위 1P / 2P 표시 (쌍둥이는 두 몸체의 가운데 위)
        lx = sum(b[0] for b in bodies) / len(bodies)
        ly = max(10, bodies[0][1] - 28)
        tag_txt = vs_name(s["i"]) if vs_names_override else VS_TAGS[s["i"]]
        if net_playing and s["i"] == net_my_slot: tag_txt += " " + t("online_me_tag")   # 2.2: 내 캐릭터 표시
        tag_s = font_small.render(tag_txt, True, BLACK)
        screen.blit(tag_s, tag_s.get_rect(center=(lx + 1, ly + 1)))
        tag_f = font_small.render(tag_txt, True, VS_COLORS[s["i"]])
        screen.blit(tag_f, tag_f.get_rect(center=(lx, ly)))

def vs_hud_list(s, now):
    ps, out = s["ps"], []
    if ps.magnet_active: out.append(("magnet", ps.magnet_end_tick - now))
    for k in VS_GLOBAL_ITEMS:
        if k in vs_world and vs_world[k][1] == s["i"]: out.append((k, vs_world[k][0] - now))
    if ps.kimchi_active: out.append(("kimchi", ps.kimchi_end_tick - now))
    if ps.minime_active: out.append(("minime", ps.minime_end_tick - now))
    if ps.l_active: out.append(("l", ps.l_end_tick - now))
    if ps.shield_count > 0: out.append(("shield", None))
    if ps.rewind_charges > 0: out.append(("rewind", None))
    if ps.bat_count > 0: out.append(("bat", None))
    return out

VS_HUD_SLOT, VS_HUD_STEP, VS_HUD_Y, VS_HUD_INNER = 30, 34, 98, 26

def vs_draw_hud(s, now):
    i, ps = s["i"], s["ps"]
    col, left = VS_COLORS[i], (i == 0)
    ax = 12 if left else WIDTH - 12
    def put(surf, y):
        screen.blit(surf, surf.get_rect(midleft=(ax, y)) if left else surf.get_rect(midright=(ax, y)))
    put(font_small.render(vs_name(i), True, col), 14)
    put(font_mid.render(f"SCORE {s['score']}", True, WHITE), 38)
    hp = max(0, ps.hp)
    txt = f"HP {hp}"
    if ps.combo >= 2:
        bonus = ps.combo // (5 if s["skin"] == "mom" else COMBO_BONUS_STEP)
        txt += f"   COMBO x{ps.combo}" + (f" (+{bonus})" if bonus > 0 else "")
        if s["skin"] == "sister": txt += f" [{t('hud_immune')} {ps.sister_charges}]"
    put(font_small.render(txt, True, RED if hp < 2 else YELLOW if ps.combo >= 2 else WHITE), 62)
    if skin_has_o(s["skin"]) and s["alive"]:
        left_ms = ps.dev_cd_until - now
        key = VS_DEV_KEY_NAME[i]
        msg = t("vs_dev_cd", k=key, sec=f"{left_ms / 1000:.1f}") if left_ms > 0 else t("vs_dev_ready", k=key)
        put(font_buff.render(msg, True, GRAY if left_ms > 0 else (120, 255, 120)), 128)
    half = VS_HUD_SLOT // 2
    for idx, (key, rem) in enumerate(vs_hud_list(s, now)):
        x = (ax + half + idx * VS_HUD_STEP) if left else (ax - half - idx * VS_HUD_STEP)
        box = pygame.Rect(x - half, VS_HUD_Y - half, VS_HUD_SLOT, VS_HUD_SLOT)
        pygame.draw.rect(screen, (0, 0, 96), box, border_radius=5)
        blink = rem is not None and rem < HUD_BLINK_MS and (now // 200) % 2 == 1
        if not blink:
            draw_sprite_or_fallback(f"item_{key}", x, VS_HUD_Y,
                                    lambda x=x, key=key: (pygame.draw.circle(screen, FALLBACK_COLOR.get(f"item_{key}", WHITE), (x, VS_HUD_Y), 11),
                                                          draw_text_center(screen, font_buff, HUD_LETTER[key], BLACK, (x, VS_HUD_Y))))
        if rem is None:
            n = ps.shield_count if key == "shield" else ps.bat_count if key == "bat" else ps.rewind_charges
            badge = font_buff.render(f"x{n}", True, WHITE)
            screen.blit(badge, badge.get_rect(bottomright=(x + half - 2, VS_HUD_Y + half - 1)))
        else:
            tot = s["hud_total"]
            if key not in tot or rem > tot[key][1] + 50: tot[key] = [max(rem, 1), rem]
            tot[key][1] = rem
            vh = max(0, min(VS_HUD_INNER, int(round((1 - max(0, rem) / tot[key][0]) * VS_HUD_INNER))))
            if vh > 0:
                screen.blit(hud_veil, (x - VS_HUD_INNER // 2, VS_HUD_Y - VS_HUD_INNER // 2), area=pygame.Rect(0, 0, VS_HUD_INNER, vh))
        pygame.draw.rect(screen, (16, 16, 48), box, 2, border_radius=5)
    for k in list(s["hud_total"]):
        if k not in dict(vs_hud_list(s, now)): del s["hud_total"][k]

def draw_cast(ps, now):
    """2.4 능력 말풍선 (샨셴부! 같은 외침)"""
    if ps.cast_id and now < ps.cast_until and ps.cast_id in CAST_TEXT:
        txt = CAST_TEXT[ps.cast_id][lang]
        f = font_cap if font_cap.size(txt)[0] <= 380 else font_small
        y = max(24, int(ps.y) - 34)
        draw_text_center(screen, f, txt, BLACK, (int(ps.x) + 1, y + 1))
        draw_text_center(screen, f, txt, (255, 230, 120), (int(ps.x), y))

def vs_draw_captions(s, now):
    ps, cx = s["ps"], int(WIDTH * (0.25 if s["i"] == 0 else 0.75))
    draw_cast(ps, now)
    if ps.kk_active:   # 2.4 꼰대 동전 자막
        kc = min(len(KK_CAPTIONS) - 1, int((now - ps.kk_start_tick) // KK_LINE_MS))
        f = font_cap if font_cap.size(KK_CAPTIONS[kc])[0] <= 380 else font_small
        draw_text_center(screen, f, KK_CAPTIONS[kc], BLACK, (cx + 2, HEIGHT - 40))
        draw_text_center(screen, f, KK_CAPTIONS[kc], (255, 200, 90), (cx, HEIGHT - 42))
    if ps.l_active and not ps.kk_active:   # L 자막: 먹은 사람 쪽 반 화면 (꼰대 동전 자막이 있으면 그쪽 우선)
        cap_i = min(len(L_CAPTIONS) - 1, int((now - ps.l_start_tick) // L_LINE_MS))
        cap_col = (120, 255, 120) if cap_i == len(L_CAPTIONS) - 1 else (YELLOW if cap_i % 2 == 0 else WHITE)
        f = font_cap if font_cap.size(L_CAPTIONS[cap_i])[0] <= 380 else font_small
        draw_text_center(screen, f, L_CAPTIONS[cap_i], BLACK, (cx + 2, HEIGHT - 40))
        draw_text_center(screen, f, L_CAPTIONS[cap_i], cap_col, (cx, HEIGHT - 42))
    if ps.tot_trick:
        tot_txt = f"{t('tot_trick_' + ps.tot_trick)}  ({max(0, ps.tot_end_tick - now) / 1000:.1f})"
        draw_text_center(screen, font_buff, tot_txt, BLACK, (cx + 1, HEIGHT - 75))
        draw_text_center(screen, font_buff, tot_txt, (230, 150, 255), (cx, HEIGHT - 76))
    elif now < ps.tot_msg_until:
        draw_text_center(screen, font_buff, ps.tot_msg, BLACK, (cx + 1, HEIGHT - 75))
        draw_text_center(screen, font_buff, ps.tot_msg, ORANGE, (cx, HEIGHT - 76))

def draw_versus(now, countdown=False):
    vs_draw_world(now)
    vs_draw_players(now)
    fx_draw(now)
    if countdown:
        remain = max(0.0, VS_TIME_MS / 1000)
    else:
        remain = max(0.0, (VS_TIME_MS - (now - vs_start_tick)) / 1000)
    shown = int(math.ceil(remain))
    t_color = RED if shown <= 5 else WHITE
    draw_text_center(screen, font_small, "TIME", t_color, (WIDTH // 2, 16))
    draw_text_center(screen, font_mid, str(shown), t_color, (WIDTH // 2, 40))
    for s in vs_slots:
        vs_draw_hud(s, now)
        vs_draw_captions(s, now)
    if net_playing: online_draw_stats(now)
    if countdown:
        n = max(1, int(math.ceil((VS_COUNTDOWN_MS - (now - vs_cd_start)) / 1000)))
        big = pygame.transform.rotozoom(font_large.render(str(n), True, YELLOW), 0, 3.0)
        screen.blit(big, big.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
        draw_text_center(screen, font_small, f"{vs_name(0)}  vs  {vs_name(1)}", WHITE, (WIDTH // 2, HEIGHT // 2 + 70))

def draw_vs_result(buttons=None):
    r = vs_result
    if r["winner"] is None:
        draw_text_center(screen, font_large, t("vs_draw"), YELLOW, (WIDTH // 2, 70))
    else:
        draw_text_center(screen, font_large, t("vs_win", name=r["names"][r["winner"]]), VS_COLORS[r["winner"]], (WIDTH // 2, 70))
    for i in range(2):
        cx = WIDTH // 4 + i * WIDTH // 2
        pv_surf = vs_preview(r["skins"][i], True, box=60)
        if pv_surf:
            big = pygame.transform.scale(pv_surf, (pv_surf.get_width() * 2, pv_surf.get_height() * 2))
            screen.blit(big, big.get_rect(center=(cx, 170)))
        draw_text_center(screen, font_mid, f"{VS_TAGS[i]}  {r['names'][i]}", VS_COLORS[i], (cx, 240))
        draw_text_center(screen, font_mid, f"SCORE {r['scores'][i]}", WHITE, (cx, 272))
        if r["winner"] == i:
            draw_text_center(screen, font_small, "WIN", YELLOW, (cx, 302))
    for b in (vs_result_buttons if buttons is None else buttons):
        b.draw(screen)


play_type_buttons = [
    Button(WIDTH // 2, 200, t("single_play"), set_state_mode_select, width=300, height=56, text_key="single_play"),
    Button(WIDTH // 2, 280, t("multi_play"), lambda: set_state_multi_menu(), width=300, height=56, text_key="multi_play"),
    Button(WIDTH // 2, 400, t("back"), set_state_main, text_key="back"),
]
vs_setup_buttons = [Button(WIDTH // 2, 462, t("back"), lambda: set_state_multi_menu(), text_key="back")]
vs_result_buttons = [
    Button(WIDTH // 2 - 120, 400, t("retry"), set_state_vs_setup, text_key="retry"),
    Button(WIDTH // 2 + 120, 400, t("to_main"), set_state_main, text_key="to_main"),
]

# ================= 2.2 ONLINE: 네트워크 + 온라인 화면 (웹 전용) =================
# 모든 코드는 게임 루프 바깥의 함수입니다 (웹 변환기 규칙). 루프 안에는 호출과 분기만 둡니다.
NET_SERVER = "wss://coingame-online.jhhj67.workers.dev/ws"   # 서버 주소 (배포한 주소)
NET_VERSION = "2.3"
NET_PING_MS = 1000          # 핑 보내는 간격
NET_TIMEOUT_MS = 5000       # 이 시간 동안 서버 응답이 없으면 끊김으로 봄
NET_NOTICE_MS = 4000        # 안내 문구 표시 시간
NET_ERR_KEYS = {"closed": "err_closed", "full": "err_full", "nocode": "err_nocode", "version": "err_version",
                "busy": "err_busy", "left": "err_left", "banned": "err_banned", "offline": "err_offline", "gameclosed": "err_gameclosed",
                "kicked": "err_kicked", "origin": "err_closed", "noconnect": "err_noconnect",
                "specfull": "err_specfull", "specend": "err_specend"}
NET_HTTP = "https://coingame-online.jhhj67.workers.dev"   # 관리자 API 주소 (서버 주소와 같음)

class PCNet:
    """PC(파이썬으로 직접 실행)용 접속 도구. 웹 버전의 JS 함수들(cgConnect 등)과 같은 이름·같은 동작으로 만들어서
    게임의 온라인 코드를 그대로 씀. 따로 설치할 것 없이 파이썬 표준 라이브러리만 사용 (웹소켓 클라이언트를 직접 구현)"""
    WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

    def __init__(self):
        import importlib
        self.m = {n: importlib.import_module(n) for n in ("socket", "ssl", "threading", "hashlib", "struct", "time", "collections",
                                                          "urllib.parse", "urllib.request", "urllib.error")}
        self.q = self.m["collections"].deque()
        self.id = 0
        self.sock = None
        self.res = {}
        self.wlock = self.m["threading"].Lock()
        self.cv = self.m["threading"].Condition()   # 보내기 대기열 (화면이 네트워크를 기다리지 않게 별도 스레드가 보냄)
        self.out = self.m["collections"].deque()
        self.outn = 0

    def eval(self, code): pass

    def _spawn(self, fn, *args):
        th = self.m["threading"].Thread(target=fn, args=args, daemon=True)
        th.start()

    # ----- 웹소켓 -----
    def cgConnect(self, url):
        self._drop()
        self.id += 1
        self._spawn(self._run, url, self.id)

    def _drop(self):
        sk, self.sock = self.sock, None
        if sk is not None:
            try: sk.close()
            except Exception: pass

    def _emit(self, cid, msg):
        if cid == self.id: self.q.append(msg)

    def _run(self, url, cid):
        m = self.m
        sk = None
        try:
            u = m["urllib.parse"].urlparse(url)
            host = u.hostname
            tls = u.scheme == "wss"
            port = u.port or (443 if tls else 80)
            sk = m["socket"].create_connection((host, port), timeout=10)
            try: sk.setsockopt(m["socket"].IPPROTO_TCP, m["socket"].TCP_NODELAY, 1)   # 작은 메시지를 모아 보내느라 늦어지는 것 방지
            except Exception: pass
            if tls: sk = m["ssl"].create_default_context().wrap_socket(sk, server_hostname=host)
            key = base64.b64encode(os.urandom(16)).decode()
            path = (u.path or "/") + (("?" + u.query) if u.query else "")
            req = ("GET %s HTTP/1.1\r\nHost: %s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                   "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\nUser-Agent: CoinGame/2.2\r\n\r\n") % (path, u.netloc, key)
            sk.sendall(req.encode())
            buf = b""
            while b"\r\n\r\n" not in buf:
                chunk = sk.recv(4096)
                if not chunk or len(buf) > 16384: raise OSError("handshake")
                buf += chunk
            head, buf = buf.split(b"\r\n\r\n", 1)
            lines = head.decode("latin-1").split("\r\n")
            if " 101" not in lines[0]: raise OSError("handshake " + lines[0])
            want = base64.b64encode(m["hashlib"].sha1((key + self.WS_GUID).encode()).digest()).decode()
            hd = {}
            for ln in lines[1:]:
                if ":" in ln:
                    k, v = ln.split(":", 1); hd[k.strip().lower()] = v.strip()
            if hd.get("sec-websocket-accept") != want: raise OSError("accept")
        except Exception:
            if sk is not None:
                try: sk.close()
                except Exception: pass
            self._emit(cid, "!error")
            self._emit(cid, "!close 1006")
            return
        if cid != self.id:
            try: sk.close()
            except Exception: pass
            return
        sk.settimeout(None)
        self.sock = sk
        with self.cv:
            self.out.clear(); self.outn = 0
        self._spawn(self._writer, sk, cid)
        self._emit(cid, "!open")
        code = 1006
        try:
            code = self._read_loop(sk, buf, cid)
        except Exception:
            code = 1006
        if cid == self.id:
            self.sock = None
        try: sk.close()
        except Exception: pass
        self._emit(cid, "!close %d" % code)

    def _read_loop(self, sk, buf, cid):
        st = self.m["struct"]
        def need(n):
            nonlocal buf
            while len(buf) < n:
                chunk = sk.recv(65536)
                if not chunk: raise OSError("eof")
                buf += chunk
            out, buf = buf[:n], buf[n:]
            return out
        frag = b""
        while True:
            b0, b1 = need(2)
            op, fin = b0 & 0x0F, b0 & 0x80
            ln = b1 & 0x7F
            if ln == 126: ln = st.unpack(">H", need(2))[0]
            elif ln == 127: ln = st.unpack(">Q", need(8))[0]
            if ln > 4 * 1024 * 1024: raise OSError("too big")
            mk = need(4) if b1 & 0x80 else None
            data = need(ln) if ln else b""
            if mk: data = self._mask(data, mk)
            if op == 1 or op == 0:
                frag = (frag if op == 0 else b"") + data
                if fin:
                    self._emit(cid, frag.decode("utf-8", "replace")); frag = b""
            elif op == 8:
                code = st.unpack(">H", data[:2])[0] if len(data) >= 2 else 1005
                try: self._send_frame(8, data[:2])
                except Exception: pass
                return code
            elif op == 9:
                self._send_frame(10, data)

    @staticmethod
    def _mask(data, key):
        n = len(data)
        if n == 0: return data
        k = (key * (n // 4 + 1))[:n]
        return (int.from_bytes(data, "big") ^ int.from_bytes(k, "big")).to_bytes(n, "big")

    def _frame(self, op, payload):
        st = self.m["struct"]
        n = len(payload)
        head = bytes([0x80 | op])
        if n < 126: head += bytes([0x80 | n])
        elif n < 65536: head += bytes([0x80 | 126]) + st.pack(">H", n)
        else: head += bytes([0x80 | 127]) + st.pack(">Q", n)
        key = os.urandom(4)
        return head + key + self._mask(payload, key)

    def _send_frame(self, op, payload):
        sk = self.sock
        if sk is None: raise OSError("closed")
        data = self._frame(op, payload)
        with self.wlock:
            sk.sendall(data)

    def _writer(self, sk, cid):
        """대기열에 쌓인 메시지를 차례로 보냄 (네트워크가 느려도 게임 화면은 멈추지 않음)"""
        while cid == self.id and self.sock is sk:
            with self.cv:
                while not self.out and cid == self.id and self.sock is sk:
                    self.cv.wait(0.5)
                if not self.out: continue
                data = self.out.popleft(); self.outn -= len(data)
            try:
                with self.wlock:
                    sk.sendall(data)
            except Exception:
                try: sk.close()   # 읽는 쪽이 끊김을 알아챔
                except Exception: pass
                return

    def cgSend(self, msg):
        if self.sock is None: return 0
        try:
            data = self._frame(1, msg.encode("utf-8"))
            with self.cv:
                self.out.append(data); self.outn += len(data)
                self.cv.notify()
            return 1
        except Exception:
            return 0

    def cgBuf(self): return self.outn   # 아직 못 보낸 바이트 수 (웹의 bufferedAmount 와 같은 뜻)

    def cgPoll(self):
        try: return self.q.popleft()
        except IndexError: return ""

    def cgClose(self):
        self.id += 1
        self.q.clear()
        with self.cv:
            self.out.clear(); self.outn = 0; self.cv.notify_all()
        sk = self.sock
        if sk is not None and self.wlock.acquire(False):   # 전송이 막혀 있으면(쓰는 쪽이 잡고 있으면) 닫는 인사는 건너뜀: 게임이 멈추지 않게
            try:
                sk.settimeout(0.2)
                sk.sendall(self._frame(8, b"\x03\xe8"))
            except Exception: pass
            finally: self.wlock.release()
        self._drop()

    # ----- 관리자용 HTTP -----
    def cgFetch(self, rid, method, path, token, body):
        self._spawn(self._fetch, rid, method, path, token, body)

    def _fetch(self, rid, method, path, token, body):
        m = self.m
        try:
            hdr = {"User-Agent": "CoinGame/2.2"}
            if token: hdr["Authorization"] = "Bearer " + token
            data = None
            if body:
                hdr["Content-Type"] = "application/json"; data = body.encode("utf-8")
            req = m["urllib.request"].Request(NET_HTTP + path, data=data, method=method, headers=hdr)
            try:
                with m["urllib.request"].urlopen(req, timeout=10) as r:
                    self.res[rid] = "%d|%s" % (r.status, r.read().decode("utf-8", "replace"))
            except m["urllib.error"].HTTPError as e:
                self.res[rid] = "%d|%s" % (e.code, e.read().decode("utf-8", "replace"))
        except Exception:
            self.res[rid] = "0|"

    def cgFetchPoll(self, rid): return self.res.pop(rid, "")

    def cgNow(self): return int(self.m["time"].time() * 1000)

    def cgPid(self):
        try:
            path = save_path("coingame_pid.txt")
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f: v = f.read().strip()
                if v: return v
            v = "pc" + os.urandom(8).hex()
            with open(path, "w", encoding="utf-8") as f: f.write(v)
            return v
        except Exception:
            return "pc" + os.urandom(4).hex()


NET_OK = False              # 접속 도구를 만들 수 있으면 True (웹 / PC 모두)
_net_js = None
if sys.platform == "emscripten":
    try:
        import platform as _net_platform
        _net_js = _net_platform.window
        NET_OK = _net_js is not None
    except Exception:
        NET_OK = False
else:
    try:
        _net_js = PCNet()
        NET_OK = True
    except Exception:
        NET_OK = False

NET_JS_CODE = """
window.cgq = [];
window.cgs = null;
window.cgid = 0;
window.cgConnect = function(url) {
  try {
    if (window.cgs) { try { window.cgs.close(); } catch (e) {} }
    var id = ++window.cgid;
    var s = new WebSocket(url);
    window.cgs = s;
    s.onopen = function() { if (id === window.cgid) window.cgq.push("!open"); };
    s.onmessage = function(e) { if (id === window.cgid) window.cgq.push(String(e.data)); };
    s.onclose = function(e) { if (id === window.cgid) window.cgq.push("!close " + e.code); };
    s.onerror = function() { if (id === window.cgid) window.cgq.push("!error"); };
  } catch (err) { window.cgq.push("!error"); }
};
window.cgSend = function(m) {
  if (window.cgs && window.cgs.readyState === 1) { window.cgs.send(m); return 1; }
  return 0;
};
window.cgBuf = function() { return (window.cgs && window.cgs.readyState === 1) ? window.cgs.bufferedAmount : 0; };
window.cgPoll = function() { return window.cgq.length ? window.cgq.shift() : ""; };
window.cgClose = function() { window.cgid++; window.cgq = []; if (window.cgs) { try { window.cgs.close(); } catch (e) {} } window.cgs = null; };
window.cgRes = {};
window.cgFetch = function(id, method, path, token, body) {
  var opts = { method: method, headers: {} };
  if (token) opts.headers["Authorization"] = "Bearer " + token;
  if (body) { opts.headers["Content-Type"] = "application/json"; opts.body = body; }
  fetch("__HTTP__" + path, opts).then(function(r) { return r.text().then(function(tx) { window.cgRes[id] = r.status + "|" + tx; }); })
    .catch(function() { window.cgRes[id] = "0|"; });
};
window.cgFetchPoll = function(id) { var v = window.cgRes[id]; if (v === undefined) return ""; delete window.cgRes[id]; return v; };
window.cgNow = function() { return Date.now(); };
window.cgPid = function() {
  try {
    var p = window.localStorage.getItem("coingame_pid");
    if (!p) { p = Math.random().toString(36).slice(2) + Date.now().toString(36); window.localStorage.setItem("coingame_pid", p); }
    return p;
  } catch (e) { return "anon" + Math.random().toString(36).slice(2, 8); }
};
"""

net_booted = False
net_state = "idle"          # idle / connecting / open
net_mode = ""               # random / create / join
net_pending = ""            # 로비에서 받은 방 코드 (매칭됨)
net_role = "host"           # host / guest
net_code = ""
net_opp = None              # {"nick","skin","ready"} 또는 None
net_ready_me = False
net_notice = ""
net_notice_until = 0
net_pid_cache = ""
net_last_ping = 0
net_last_pong = 0
net_ever_open = False       # 이번 연결에서 서버와 한 번이라도 연결됐는지 (처음부터 안 되면 네트워크 차단 안내)
net_ping_ms = 0
net_ping_sent = {}
net_ping_id = 0
net_queued = False          # 로비 대기 중
net_join_buf = ""
net_go_at = 0               # 서버가 go 를 보낸 시각 (5단계에서 카운트다운에 사용)


def net_boot():
    global net_booted, net_pid_cache
    if net_booted or not NET_OK: return
    _net_js.eval(NET_JS_CODE.replace("__HTTP__", NET_HTTP))
    try:
        net_pid_cache = str(_net_js.cgPid())
    except Exception:
        net_pid_cache = "anon"
    net_booted = True

def net_show_notice(key_or_text, now=None):
    global net_notice, net_notice_until
    net_notice = t(key_or_text) if key_or_text in STRINGS else key_or_text
    net_notice_until = (pygame.time.get_ticks() if now is None else now) + NET_NOTICE_MS

def net_connect(query):
    global net_state, net_last_pong, net_last_ping, net_ever_open
    net_boot()
    net_state = "connecting"; net_ever_open = False
    net_last_pong = net_last_ping = pygame.time.get_ticks()
    _net_js.cgConnect(NET_SERVER + "?" + query)

def net_buffered():
    try:
        return int(_net_js.cgBuf())
    except Exception:
        return 0

def net_send(obj):
    if not NET_OK or not net_booted: return False
    try:
        return bool(_net_js.cgSend(json.dumps(obj, separators=(",", ":"), ensure_ascii=False)))
    except Exception:
        return False

def net_close():
    global net_state, net_opp, net_ready_me, net_queued, net_pending
    if NET_OK and net_booted:
        try: _net_js.cgClose()
        except Exception: pass
    net_state = "idle"; net_opp = None; net_ready_me = False; net_queued = False; net_pending = ""
    spec_clear()

def net_fail(reason):
    """연결 실패/끊김: 정리하고 온라인 메뉴로 돌아가 안내 문구를 보여 줌"""
    global game_state
    if reason == "closed" and not net_ever_open: reason = "noconnect"
    online_abort_play()
    net_close()
    vs_stop_edit()
    net_show_notice(NET_ERR_KEYS.get(reason, "err_closed"))
    game_state = "ONLINE_MENU"
    if reason == "gameclosed": GS["last_try"] = -10**9   # 2.4: 게임이 닫혔다고 하면 바로 상태를 다시 확인

def net_hello():
    if not is_skin_unlocked(vs_choice[0]): vs_choice[0] = "normal"
    net_send({"t": "hello", "v": NET_VERSION, "pid": net_pid_cache, "nick": vs_nick[0], "skin": vs_choice[0]})

def net_send_setup():
    global net_ready_me
    net_ready_me = False
    net_send({"t": "setup", "nick": vs_nick[0], "skin": vs_choice[0]})

def net_handle(m, now):
    global game_state, net_role, net_code, net_opp, net_state, net_queued, net_pending, net_ready_me
    global net_last_pong, net_ping_ms, net_go_at, net_ever_open
    if m.startswith("!"):
        if m == "!open":
            net_state = "open"; net_last_pong = now; net_ever_open = True
            net_hello()
        elif net_state != "idle":   # !close / !error (오래된 연결의 것은 JS에서 이미 걸러짐)
            net_fail("closed")
        return
    try:
        j = json.loads(m)
    except Exception:
        return
    if not isinstance(j, dict): return
    tp = j.get("t")
    net_last_pong = now
    if tp == "pong":
        t0 = net_ping_sent.pop(j.get("c"), None)
        if t0 is not None: net_ping_ms = now - t0
    elif tp == "deny":
        net_fail(j.get("why", "closed"))
    elif tp == "hi":      # 로비 접속 완료 -> 대기열에 들어감
        if net_mode == "random":
            net_queued = True
            net_send({"t": "queue"})
    elif tp == "match":   # 랜덤매칭 성사 -> 방으로 이동
        net_pending = str(j.get("code", ""))
        net_queued = False
        net_connect("room=" + net_pending + "&m=1")
        net_pending = ""
    elif tp == "room":
        net_code = str(j.get("code", "")); net_role = j.get("role", "host")
        net_opp = j.get("opp") if isinstance(j.get("opp"), dict) else None
        net_ready_me = False
        vs_stop_edit()
        game_state = "ONLINE_ROOM"
    elif tp == "opp":
        net_opp = {"nick": str(j.get("nick", "")), "skin": str(j.get("skin", "normal")), "ready": bool(j.get("ready"))}
        if net_opp["skin"] not in SKIN_MAP: net_opp["skin"] = "normal"
    elif tp == "role":
        net_role = j.get("role", net_role)
    elif tp == "left":
        net_opp = None; net_ready_me = False
        if net_playing: online_forfeit()
        elif game_state in ("ONLINE_ROOM", "ONLINE_RESULT"): net_show_notice("err_left", now)
    elif tp == "go":
        net_go_at = now
        online_start_play()
    elif tp == "in":
        if net_playing and net_role == "host": online_host_in(j, now)
    elif tp == "st":
        if net_playing and net_role == "guest": online_guest_snap(j, now)
        elif net_spec: spec_snap(j, now)
    elif tp == "end":
        if net_playing and net_role == "guest": online_guest_end(j)
        elif net_spec: spec_end(j)
    elif tp == "spec": spec_enter(j)
    elif tp == "si": spec_info(j)
    elif tp == "sgo": spec_go(j)
    elif tp == "specend": net_fail("specend")

def net_update(now):
    """매 프레임: 받은 메시지 처리 + 핑 + 끊김 검사 (온라인 화면에서만 호출)"""
    global net_last_ping, net_ping_id
    if not NET_OK or not net_booted or net_state == "idle": return
    for _ in range(40):
        try:
            m = _net_js.cgPoll()
        except Exception:
            m = ""
        if not m: break
        net_handle(str(m), now)
        if net_state == "idle": return
    if net_playing:
        if net_role == "host" and game_state in ("VS_COUNTDOWN", "VERSUS"): online_send_snapshot(now)
        elif net_role == "guest" and game_state == "ONLINE_PLAY":
            online_guest_predict(now)
            online_guest_send_input(now)
    if net_state == "open" and now - net_last_ping >= NET_PING_MS:
        net_last_ping = now
        net_ping_id += 1
        net_ping_sent[net_ping_id] = now
        if len(net_ping_sent) > 20: net_ping_sent.pop(min(net_ping_sent), None)
        net_send({"t": "ping", "c": net_ping_id})
    if now - net_last_pong > NET_TIMEOUT_MS:
        net_fail("closed")


# ---------------- 화면 전환 ----------------
def set_state_multi_menu():
    global game_state
    game_state = "MULTI_MENU"

def set_state_online_menu():
    global game_state
    if not NET_OK:
        net_show_notice("online_pc_only")
        return
    game_state = "ONLINE_MENU"

def online_prepare():
    if not is_skin_unlocked(vs_choice[0]): vs_choice[0] = "normal"

def online_start_random():
    global net_mode, game_state
    online_prepare()
    net_close(); net_mode = "random"
    net_connect("lobby=1")
    game_state = "ONLINE_WAIT"

def online_start_create():
    global net_mode, game_state
    online_prepare()
    net_close(); net_mode = "create"
    net_connect("create=1")
    game_state = "ONLINE_WAIT"

def set_state_online_join():
    global game_state, net_join_buf
    net_join_buf = ""
    try: pygame.key.start_text_input()
    except Exception: pass
    game_state = "ONLINE_JOIN"

net_spec = False            # 2.4 관전: 내가 관전자인지
net_spec_info = []          # 선수 목록 [{"nick","skin","ready","role"}] (방장 먼저)
net_spec_run = False        # 스냅샷을 받아서 화면에 그리는 중인지
net_spec_last_snap = 0
net_join_spec = False       # 코드 입력 화면이 관전용인지
SPEC_STALE_MS = 3000        # 이 시간 동안 스냅샷이 없으면 다시 대기 화면으로

def online_do_join():
    global net_mode, game_state
    if len(net_join_buf) != 4:
        net_show_notice("online_enter_code")
        return
    online_prepare()
    net_close(); net_mode = "join"
    net_connect("room=" + net_join_buf + ("&spec=1" if net_join_spec else ""))
    game_state = "ONLINE_WAIT"

def set_state_join_play():
    global net_join_spec
    net_join_spec = False
    set_state_online_join()

def set_state_join_spec():
    global net_join_spec
    net_join_spec = True
    set_state_online_join()

def online_leave():
    """대기/방에서 나가기 -> 온라인 메뉴"""
    global game_state
    net_send({"t": "leave"})
    online_abort_play()
    net_close()
    vs_stop_edit()
    game_state = "ONLINE_MENU"

def online_toggle_ready():
    global net_ready_me
    if vs_edit is not None or net_opp is None: return
    net_ready_me = not net_ready_me
    net_send({"t": "ready", "on": net_ready_me})

def online_stop_edit():
    """닉네임 입력을 끝내고 서버에 알림"""
    if vs_edit is not None:
        vs_stop_edit()
        net_send_setup()


# ---------------- 이벤트 ----------------
def online_join_event(event):
    global net_join_buf
    for btn in online_join_buttons:
        btn.check_event(event)
    if event.type == pygame.TEXTINPUT:
        for ch in event.text.upper():
            if len(net_join_buf) < 4 and ch.isascii() and ch.isalnum(): net_join_buf += ch
    elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_BACKSPACE:
            net_join_buf = net_join_buf[:-1]
        elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            online_do_join()

def online_room_event(event):
    global vs_ime
    for btn in (online_unready_btn if net_ready_me else online_ready_btn,) + tuple(online_room_buttons):
        btn.check_event(event)
    if event.type == pygame.TEXTINPUT:
        vs_text_input(event.text); vs_ime = ""
    elif event.type == pygame.TEXTEDITING:
        vs_ime = event.text if vs_edit is not None else ""
    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        if VS_NICK_RECT[0].collidepoint(event.pos):
            if vs_edit != 0: vs_start_edit(0)
            return
        online_stop_edit()
        for k, sid in enumerate(SKIN_ORDER):
            if vs_skin_rect(0, k).collidepoint(event.pos) and is_skin_unlocked(sid) and vs_choice[0] != sid:
                vs_choice[0] = sid
                net_send_setup()
    elif event.type == pygame.KEYDOWN:
        if vs_edit is not None:
            if event.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER):
                online_stop_edit()
            elif event.key == pygame.K_BACKSPACE and not vs_ime:
                vs_nick[0] = vs_nick[0][:-1]
            return
        if vs_key_is(event, pygame.K_q, "KSCAN_Q") or event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            online_toggle_ready()


# ---------------- 그리기 ----------------
def draw_notice(now, y=440):
    if net_notice and now < net_notice_until:
        draw_text_center(screen, font_small, net_notice, (255, 140, 140), (WIDTH // 2, y))

def draw_multi_menu():
    draw_text_center(screen, font_large, t("multi_play"), WHITE, (WIDTH // 2, 90))
    for b in multi_menu_buttons:
        b.draw(screen)
    if not NET_OK:
        draw_text_center(screen, font_buff, t("online_pc_only"), GRAY, (WIDTH // 2, 330))
    draw_notice(pygame.time.get_ticks())

def draw_online_menu(now):
    draw_text_center(screen, font_large, t("online_title"), WHITE, (WIDTH // 2, 80))
    for b in online_menu_buttons:
        b.draw(screen)
    draw_notice(now)

def draw_online_join(now):
    draw_text_center(screen, font_large, t("spec_join_title" if net_join_spec else "online_join"), WHITE, (WIDTH // 2, 80))
    draw_text_center(screen, font_small, t("spec_join_hint" if net_join_spec else "online_enter_code"), GRAY, (WIDTH // 2, 150))
    box = pygame.Rect(WIDTH // 2 - 110, 195, 220, 70)
    pygame.draw.rect(screen, (0, 0, 70), box, border_radius=6)
    pygame.draw.rect(screen, WHITE, box, 2, border_radius=6)
    shown = net_join_buf + ("_" if (now // 450) % 2 == 0 and len(net_join_buf) < 4 else "")
    draw_text_center(screen, font_large, shown, YELLOW, box.center)
    draw_text_center(screen, font_buff, t("online_code_hint"), GRAY, (WIDTH // 2, 290))
    for b in online_join_buttons:
        b.draw(screen)
    draw_notice(now)

def draw_online_wait(now):
    dots = "." * (1 + (now // 400) % 3)
    if net_state == "connecting": msg = t("online_connecting")
    elif net_mode == "random": msg = t("online_finding")
    else: msg = t("online_connecting")
    draw_text_center(screen, font_large, msg + dots, WHITE, (WIDTH // 2, 200))
    for b in online_wait_buttons:
        b.draw(screen)

def draw_online_room(now):
    draw_text_center(screen, font_large, t("online_code_label") + "  " + net_code, YELLOW, (WIDTH // 2, 34))
    # --- 내 줄 (위): 닉네임/스킨 고르기 ---
    col, y0 = VS_COLORS[0], VS_ROW_Y0[0]
    screen.blit(font_mid.render(t("online_you"), True, col), (18, y0))
    rc = VS_NICK_RECT[0]
    pygame.draw.rect(screen, (0, 0, 70), rc, border_radius=4)
    pygame.draw.rect(screen, col if vs_edit == 0 else GRAY, rc, 2, border_radius=4)
    if vs_edit == 0:
        ime = vs_ime if sys.platform != "emscripten" or all(0xAC00 <= ord(c) <= 0xD7A3 for c in vs_ime) else ""
        shown = vs_nick[0] + ime + ("|" if (now // 450) % 2 == 0 else "")
        screen.blit(font_small.render(shown, True, WHITE), font_small.render(shown, True, WHITE).get_rect(midleft=(rc.x + 8, rc.centery)))
    elif vs_nick[0]:
        screen.blit(font_small.render(vs_nick[0], True, WHITE), font_small.render(vs_nick[0], True, WHITE).get_rect(midleft=(rc.x + 8, rc.centery)))
    else:
        hint = font_small.render(t("vs_nick_hint"), True, (130, 130, 130))
        screen.blit(hint, hint.get_rect(midleft=(rc.x + 8, rc.centery)))
    if net_ready_me:
        draw_text_center(screen, font_small, "READY!", (120, 255, 120), (rc.centerx, rc.bottom + 16))
    for k, sid in enumerate(SKIN_ORDER):
        cell = vs_skin_rect(0, k)
        unlocked = is_skin_unlocked(sid)
        pygame.draw.rect(screen, (0, 0, 96) if unlocked else (0, 0, 60), cell, border_radius=5)
        pv_surf = vs_preview(sid, unlocked)
        if pv_surf: screen.blit(pv_surf, pv_surf.get_rect(center=cell.center))
        if vs_choice[0] == sid:
            pygame.draw.rect(screen, col, cell, 3, border_radius=5)
        else:
            pygame.draw.rect(screen, (16, 16, 48), cell, 1, border_radius=5)
    info = SKIN_MAP[vs_choice[0]]
    screen.blit(font_small.render(info["label"][lang], True, col), (VS_SKIN_X0, y0 + 76))
    screen.blit(font_buff.render(f"{t('ability')}: {info['ability'][lang]}", True, GRAY), (VS_SKIN_X0, y0 + 98))
    # --- 상대 줄 (아래): 받은 정보를 보여 줌 ---
    col, y0 = VS_COLORS[1], VS_ROW_Y0[1]
    screen.blit(font_mid.render(t("online_opp"), True, col), (18, y0))
    rc = VS_NICK_RECT[1]
    pygame.draw.rect(screen, (0, 0, 70), rc, border_radius=4)
    pygame.draw.rect(screen, GRAY, rc, 2, border_radius=4)
    if net_opp is None:
        draw_text_center(screen, font_mid, t("online_opp_wait") + "." * (1 + (now // 400) % 3), GRAY, (WIDTH // 2 + 40, y0 + 60))
        draw_text_center(screen, font_buff, t("online_wait_friend"), GRAY, (WIDTH // 2 + 40, y0 + 92))
    else:
        nm = net_opp["nick"] or t("online_opp")
        screen.blit(font_small.render(nm, True, WHITE), font_small.render(nm, True, WHITE).get_rect(midleft=(rc.x + 8, rc.centery)))
        if net_opp["ready"]:
            draw_text_center(screen, font_small, "READY!", (120, 255, 120), (rc.centerx, rc.bottom + 16))
        pv_surf = vs_preview(net_opp["skin"], True, box=60)
        if pv_surf:
            big = pygame.transform.scale(pv_surf, (pv_surf.get_width() * 2, pv_surf.get_height() * 2))
            screen.blit(big, big.get_rect(center=(VS_SKIN_X0 + 50, y0 + 50)))
        oi = SKIN_MAP[net_opp["skin"]]
        screen.blit(font_small.render(oi["label"][lang], True, col), (VS_SKIN_X0 + 130, y0 + 40))
        screen.blit(font_buff.render(f"{t('ability')}: {oi['ability'][lang]}", True, GRAY), (VS_SKIN_X0 + 130, y0 + 66))
    draw_text_center(screen, font_buff, t("online_controls"), GRAY, (WIDTH // 2, 372))
    for b in (online_unready_btn if net_ready_me else online_ready_btn,) + tuple(online_room_buttons):
        b.draw(screen)
    if NET_OK and net_state == "open":
        screen.blit(font_buff.render(f"ping {net_ping_ms}ms", True, GRAY), (WIDTH - 90, 8))
    draw_notice(now, 396)

multi_menu_buttons = [
    Button(WIDTH // 2, 200, t("local_vs"), lambda: set_state_vs_setup_guarded(), width=320, height=56, text_key="local_vs"),
    Button(WIDTH // 2, 280, t("online_vs"), set_state_online_menu, width=320, height=56, text_key="online_vs"),
    Button(WIDTH // 2, 400, t("back"), set_state_play_type, text_key="back"),
]
def spec_clear():
    global net_spec, net_spec_info, net_spec_run, net_snaps, net_snap_phase, vs_slots, vs_names_override
    if not net_spec and not net_spec_run: return
    net_spec = False; net_spec_info = []; net_spec_run = False
    net_snaps = []; net_snap_phase = ""; vs_slots = []; vs_names_override = None

def spec_parse_list(lst):
    out = []
    if isinstance(lst, list):
        for p in lst[:2]:
            if not isinstance(p, dict): continue
            sk = str(p.get("skin", "normal"))
            out.append({"nick": str(p.get("nick", ""))[:12], "skin": sk if sk in SKIN_MAP else "normal",
                        "ready": bool(p.get("ready")), "role": str(p.get("role", ""))})
    return out

def spec_apply_names():
    global vs_names_override
    nm = [p["nick"] for p in net_spec_info[:2]] + ["", ""]
    vs_names_override = nm[:2]

def spec_reset():
    """새 대결을 보기 시작할 때 동기화용 기억을 비움"""
    global net_snaps, net_snap_phase, vs_slots, net_my_slot, net_rtt, net_spec_run
    net_snaps = []; net_snap_phase = ""; vs_slots = []
    net_my_slot = -1; net_rtt = 0.0; net_spec_run = False
    online_reset_sync()
    spec_apply_names()

def spec_enter(j):
    global net_spec, net_spec_info, net_code, game_state
    net_spec = True; net_code = str(j.get("code", "")); net_spec_info = spec_parse_list(j.get("p"))
    vs_stop_edit()
    spec_reset()
    game_state = "ONLINE_SPEC"

def spec_info(j):
    global net_spec_info
    if not net_spec: return
    net_spec_info = spec_parse_list(j.get("p"))
    spec_apply_names()

def spec_go(j):
    global game_state
    if not net_spec: return
    spec_info(j)
    spec_reset()
    fx_clear()
    game_state = "ONLINE_SPEC"

def spec_snap(j, now):
    global net_spec_run, net_spec_last_snap, game_state
    if game_state == "ONLINE_SPEC_RESULT": return   # 결과를 보는 동안 늦게 온 스냅샷은 무시
    online_guest_snap(j, now)
    if net_snaps:
        net_spec_run = True; net_spec_last_snap = now
        game_state = "ONLINE_SPEC"

def spec_end(j):
    global vs_result, game_state, net_spec_run, net_snaps, net_snap_phase
    try:
        sc = [int(j["scores"][0]), int(j["scores"][1])]
        w = j.get("winner"); w = w if w in (0, 1) else None
        names = [str(j["names"][0])[:12], str(j["names"][1])[:12]]
        sk = [x if x in SKIN_MAP else "normal" for x in j["skins"][:2]]
        if len(sk) != 2: raise ValueError
    except Exception:
        return
    vs_result = {"scores": sc, "winner": w, "names": names, "skins": sk}
    online_music(False)
    net_spec_run = False; net_snaps = []; net_snap_phase = ""
    fx_clear()
    game_state = "ONLINE_SPEC_RESULT"

def spec_continue():
    global game_state
    spec_reset()
    game_state = "ONLINE_SPEC"

def spec_update(now):
    """(관전 화면에서 매 프레임) 스냅샷이 끊기면 대기 화면으로"""
    global net_spec_run
    if net_spec_run and now - net_spec_last_snap > SPEC_STALE_MS:
        net_spec_run = False

def draw_spec(now):
    spec_update(now)
    if net_spec_run:
        draw_online_guest(now)
        txt = t("spec_tag", code=net_code)
        s1 = font_buff.render(txt, True, BLACK); s2 = font_buff.render(txt, True, (170, 225, 255))
        screen.blit(s1, s1.get_rect(midtop=(WIDTH // 2 + 1, 5)))
        screen.blit(s2, s2.get_rect(midtop=(WIDTH // 2, 4)))
        online_draw_stats(now)
    else:
        draw_text_center(screen, font_large, t("spec_wait_title"), WHITE, (WIDTH // 2, 80))
        draw_text_center(screen, font_mid, t("online_code_label") + "  " + net_code, YELLOW, (WIDTH // 2, 140))
        for i, p in enumerate(net_spec_info[:2]):
            cx = WIDTH // 4 + i * WIDTH // 2
            pv_surf = vs_preview(p["skin"], True, box=60)
            if pv_surf:
                big = pygame.transform.scale(pv_surf, (pv_surf.get_width() * 2, pv_surf.get_height() * 2))
                screen.blit(big, big.get_rect(center=(cx, 230)))
            draw_text_center(screen, font_mid, p["nick"] or VS_TAGS[i], VS_COLORS[i], (cx, 300))
        draw_text_center(screen, font_small, t("spec_wait_msg"), GRAY, (WIDTH // 2, 350))
    draw_notice(now)

def spec_event(event):
    for b in spec_buttons: b.check_event(event)
    if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE: online_leave()

online_menu_buttons = [
    Button(WIDTH // 2, 150, t("online_random"), online_start_random, width=300, height=52, text_key="online_random"),
    Button(WIDTH // 2, 214, t("online_create"), online_start_create, width=300, height=52, text_key="online_create"),
    Button(WIDTH // 2, 278, t("online_join"), set_state_join_play, width=300, height=52, text_key="online_join"),
    Button(WIDTH // 2, 342, t("spec_btn"), set_state_join_spec, width=300, height=52, text_key="spec_btn"),
    Button(WIDTH // 2, 420, t("back"), set_state_multi_menu, text_key="back"),
]
spec_buttons = [Button(WIDTH - 52, HEIGHT - 20, t("online_leave"), online_leave, width=92, height=28, text_key="online_leave")]
spec_result_buttons = [
    Button(WIDTH // 2 - 120, 400, t("spec_continue"), spec_continue, text_key="spec_continue"),
    Button(WIDTH // 2 + 120, 400, t("online_leave"), online_leave, text_key="online_leave"),
]
online_join_buttons = [
    Button(WIDTH // 2, 340, t("online_join_btn"), online_do_join, width=200, height=48, text_key="online_join_btn"),
    Button(WIDTH // 2, 420, t("back"), set_state_online_menu, text_key="back"),
]
online_wait_buttons = [Button(WIDTH // 2, 340, t("online_cancel"), online_leave, text_key="online_cancel")]
online_ready_btn = Button(WIDTH // 2 - 110, 430, t("online_ready"), online_toggle_ready, width=190, height=40, text_key="online_ready")
online_unready_btn = Button(WIDTH // 2 - 110, 430, t("online_unready"), online_toggle_ready, width=190, height=40, text_key="online_unready")
online_room_buttons = [Button(WIDTH // 2 + 110, 430, t("online_leave"), online_leave, width=190, height=40, text_key="online_leave")]


# ================= 2.2 ONLINE: 대결 진행 (방장이 계산 / 게스트는 화면) =================
NET_SNAP_MS = 33            # 방장이 스냅샷을 보내는 간격: 33 = 초당 약 30번 (2.4: 핑이 높은 웹에서 끊김이 심해 프레임마다 -> 30번으로)
NET_SNAP_DELAY_MS = 60      # (현재 쓰이지 않음)
NET_SNAP_KEEP = 6
NET_IN_KEEPALIVE_MS = 1000  # 입력이 안 바뀌어도 이 간격으로 한 번은 보냄
NET_LERP_MAX_DIST = 150     # 이보다 많이 움직였으면 보간하지 않고 바로 이동 (되감기 등)
NET_SNAP_MS_BIG = 100       # 코인이 많을 때(골드러시) 스냅샷 간격
NET_SNAP_BIG_N = 60         # 이 개수보다 코인이 많으면 간격을 늘림
NET_BUF_MAX = 24000         # 소켓에 이만큼 쌓여 있으면 이번 스냅샷은 건너뜀 (낡은 상태를 쌓아 보내지 않음)
NET_LEAD_MAX = 350          # 게스트 화면이 앞서 보여 주는 최대 시간 (ms)
NET_OPP_LEAD_MAX = 150      # 상대(방장) 캐릭터를 앞서 보여 주는 최대 시간
NET_PRED_GAIN = 0.25        # 내 캐릭터 예측 위치를 방장 위치로 맞추는 비율 (스냅샷마다)
NET_PRED_BIG = 60           # 오차가 이보다 크면 한 번에 맞춤

net_playing = False         # 온라인 대결 진행 중 (방장/게스트 공통)
net_my_slot = 0             # 방장 = 0 (파랑), 게스트 = 1 (빨강)
net_guest_in = {"dx": 0, "dy": 0}   # 방장이 마지막으로 받은 게스트 이동 입력
net_last_snap = 0
net_snaps = []              # 게스트: [(도착 tick, 스냅샷), ...]
net_snap_phase = ""
net_last_in = None
net_last_in_at = 0
net_music_on = False
net_nid = 0
net_info_full = [-99999]
net_sent = {"c": set(), "o": set(), "i": set()}   # 방장: 정적 정보(종류/크기)를 이미 보낸 물체 번호
net_guest_ts = None         # 방장: 게스트가 마지막으로 보낸 입력의 게스트 시각
net_guest_rt = 0            # 방장: 그 입력을 받은 방장 시각
net_cinfo = {}; net_oinfo = {}; net_iinfo = {}   # 게스트: 물체 번호 -> 정적 정보
net_rtt = 0.0               # 게스트: 방장까지 왕복 지연 추정 (ms)
net_pred = {"ok": False, "x": 0.0, "y": 0.0, "t": 0, "hist": []}   # 게스트: 내 캐릭터 예측


def online_local_input():
    """온라인 조작: 이동 WASD 또는 방향키"""
    keys = pygame.key.get_pressed()
    dx = (1 if (keys[pygame.K_d] or keys[pygame.K_RIGHT]) else 0) - (1 if (keys[pygame.K_a] or keys[pygame.K_LEFT]) else 0)
    dy = (1 if (keys[pygame.K_s] or keys[pygame.K_DOWN]) else 0) - (1 if (keys[pygame.K_w] or keys[pygame.K_UP]) else 0)
    tdx, tdy = touch_move()   # 2.4 터치 조이스틱
    if tdx or tdy: dx, dy = tdx, tdy
    return {"dx": dx, "dy": dy}

def online_key_action(event):
    """체력→점수 Space / 점수→체력 Shift / 개발자 능력 R 또는 O"""
    if event.key in (pygame.K_LSHIFT, pygame.K_RSHIFT): return "ss"
    if event.key == pygame.K_SPACE: return "sh"
    if vs_key_is(event, pygame.K_r, "KSCAN_R") or vs_key_is(event, pygame.K_o, "KSCAN_O"): return "dev"
    if vs_key_is(event, pygame.K_i, "KSCAN_I") or vs_key_is(event, pygame.K_t, "KSCAN_T"): return "bat"
    return None

def online_music(on):
    global net_music_on
    if net_spec: on = False   # 관전자는 음악을 켜지 않음
    try:
        if on:
            if bgm_on:
                pygame.mixer.music.set_volume(volume)
                pygame.mixer.music.play(-1)
            net_music_on = True
        else:
            pygame.mixer.music.stop()
            net_music_on = False
    except Exception:
        pass

def online_game_event(event, now):
    """방장 화면의 키 입력 (vs_game_event 에서 호출)"""
    if game_state != "VERSUS" or net_role != "host": return
    a = online_key_action(event)
    if a: vs_apply_action(vs_slots[0], a, now)

def online_reset_sync():
    """판이 시작될 때 동기화용 기억을 비움"""
    global net_guest_ts, net_guest_rt
    for v in net_sent.values(): v.clear()
    net_info_full[0] = -99999
    net_guest_ts = None; net_guest_rt = 0
    net_cinfo.clear(); net_oinfo.clear(); net_iinfo.clear()
    net_pred["ok"] = False; net_pred["hist"] = []

def online_start_play():
    """서버가 go 를 보내면: 방장은 진짜 게임을 시작, 게스트는 화면 모드로"""
    global net_playing, net_my_slot, vs_names_override, net_snaps, net_guest_in, net_last_snap
    global net_snap_phase, net_last_in, net_last_in_at, vs_slots, game_state, net_ready_me
    net_ready_me = False
    net_playing = True
    net_snaps = []; net_snap_phase = ""; net_guest_in = {"dx": 0, "dy": 0}; net_last_snap = 0
    net_last_in = None; net_last_in_at = 0
    online_reset_sync()
    opp = net_opp or {"nick": "", "skin": "normal"}
    vs_stop_edit()
    if net_role == "host":
        net_my_slot = 0
        vs_choice[1] = opp["skin"]
        vs_names_override = [vs_nick[0], opp["nick"]]
        start_vs_countdown()
    else:
        net_my_slot = 1
        vs_names_override = [opp["nick"], vs_nick[0]]
        vs_slots = []
        game_state = "ONLINE_PLAY"

def online_abort_play():
    """연결 문제 등으로 대결을 중단: 방장이면 전역 상태를 되돌림"""
    global net_playing, vs_names_override, vs_slots
    if not net_playing: return
    if game_state in ("VS_COUNTDOWN", "VERSUS"):
        end_versus()
    online_music(False)
    net_playing = False
    vs_names_override = None
    vs_slots = []

def online_forfeit():
    """상대가 나감: 남은 사람이 승리"""
    global vs_result, game_state, net_playing, vs_names_override
    if not net_playing: return
    me = net_my_slot
    if vs_slots and game_state in ("VS_COUNTDOWN", "VERSUS"):
        end_versus()
        vs_result["winner"] = me
    else:
        sc = [s["score"] for s in vs_slots] if len(vs_slots) == 2 else [0, 0]
        sk = [s["skin"] for s in vs_slots] if len(vs_slots) == 2 else ["normal", "normal"]
        vs_result = {"scores": sc, "winner": me, "names": [vs_name(0), vs_name(1)], "skins": sk}
    online_music(False)
    net_playing = False
    vs_names_override = None
    fx_clear()
    game_state = "ONLINE_RESULT"
    net_show_notice("err_left")


# ---------------- 방장: 스냅샷 만들기/보내기 ----------------
def net_oid(o):
    global net_nid
    v = o.get("nid")
    if v is None:
        net_nid += 1
        v = o["nid"] = net_nid
    return v

def online_snapshot(now):
    ph = "cd" if game_state == "VS_COUNTDOWN" else "play"
    tm = max(0, VS_COUNTDOWN_MS - (now - vs_cd_start)) if ph == "cd" else max(0, VS_TIME_MS - (now - vs_start_tick))
    def rem(end, on=True):
        return max(0, int(end - now)) if on else 0
    sl = []
    for s in vs_slots:
        ps = s["ps"]
        sl.append({"k": s["skin"], "a": 1 if s["alive"] else 0, "s": s["score"], "h": ps.hp, "c": ps.combo, "sh": ps.shield_count,
                   "rw": ps.rewind_charges, "sc": ps.sister_charges, "x": round(ps.x), "y": round(ps.y),
                   "mg": rem(ps.magnet_end_tick, ps.magnet_active), "km": rem(ps.kimchi_end_tick, ps.kimchi_active),
                   "mm": rem(ps.minime_end_tick, ps.minime_active), "l": rem(ps.l_end_tick, ps.l_active),
                   "ls": int(now - ps.l_start_tick) if ps.l_active else 0,
                   "tt": ps.tot_trick or "", "te": rem(ps.tot_end_tick, bool(ps.tot_trick)),
                   "tx": ps.tot_msg if now < ps.tot_msg_until else "", "tu": rem(ps.tot_msg_until, now < ps.tot_msg_until),
                   "dc": rem(ps.dev_cd_until), "bb": 1 if ps.bubble else 0, "br": rem(ps.bubble_at, ps.bubble_at > 0), "bc": ps.bat_count, "cm": ps.cast_id if now < ps.cast_until else 0, "cu": rem(ps.cast_until, now < ps.cast_until), "kk": rem(ps.kk_end_tick, ps.kk_active), "ks": int(now - ps.kk_start_tick) if ps.kk_active else 0, "bl": rem(s["blink_until"])})
    # 물체는 [번호, x, y] 를 이어 붙인 정수 목록으로 보내고, 종류/크기 같은 정적 정보는 처음 한 번만 보냄 (골드러시 때 코인이 수백 개)
    sc_, so_, si_ = net_sent["c"], net_sent["o"], net_sent["i"]
    if now - net_info_full[0] >= 1000:    # 1초마다 정적 정보를 전부 다시 보냄 (처음 것을 놓쳐도 물체가 계속 안 보이는 일이 없게)
        net_info_full[0] = now; sc_, so_, si_ = set(), set(), set()
    c, cn, o, on, it, inn = [], [], [], [], [], []
    lim = WIDTH + 40
    for x_ in coins:
        if x_["x"] > lim: continue    # 화면 오른쪽 밖은 아직 안 보내도 됨
        nid = x_.get("nid")
        if nid is None: nid = net_oid(x_)
        c += (nid, round(x_["x"]), round(x_["y"]))
        if nid not in sc_: cn.append([nid, x_["kind"], x_["r"], rem(x_["expire"]) if x_["kind"] == "gold" else 0])
    for x_ in obstacles:
        nid = x_.get("nid")
        if nid is None: nid = net_oid(x_)
        o += (nid, round(x_["x"]), round(x_["y"]))
        if nid not in so_: on.append([nid, x_["kind"], x_["r"], x_.get("gen", 0)])
    for x_ in items:
        nid = x_.get("nid")
        if nid is None: nid = net_oid(x_)
        it += (nid, round(x_["x"]), round(x_["y"]))
        if nid not in si_: inn.append([nid, x_["type"]])
    msg = {"t": "st", "p": ph, "tm": int(tm), "ht": int(now), "sl": sl, "c": c, "cn": cn, "o": o, "on": on, "i": it, "in": inn,
           "w": {k: [rem(v[0]), v[1]] for k, v in vs_world.items()}}
    if net_guest_ts is not None: msg["g"] = [net_guest_ts, int(now - net_guest_rt)]
    return msg

def online_send_snapshot(now):
    global net_last_snap
    gap = NET_SNAP_MS_BIG if len(coins) > NET_SNAP_BIG_N else (0 if net_rate >= 60 else int(1000 / net_rate) - 1)   # 2.4 설정: 초당 전송 횟수
    if now - net_last_snap < gap: return
    if net_buffered() > NET_BUF_MAX: return   # 보내는 길이 막혀 있으면 이번엔 건너뛰고 다음 프레임에 다시 시도
    net_last_snap = now
    msg = online_snapshot(now)
    if net_send(msg):
        for key, flat, new in (("c", msg["c"], msg["cn"]), ("o", msg["o"], msg["on"]), ("i", msg["i"], msg["in"])):
            sset = net_sent[key]
            for r in new: sset.add(r[0])
            sset.intersection_update(flat[0::3])

def online_host_step(now, dt_scale):
    """방장: 내 키보드 + 받은 게스트 입력으로 게임 한 프레임 진행"""
    update_versus(now, dt_scale, [online_local_input(), net_guest_in])
    if game_state == "VS_RESULT":
        online_host_finish()

def online_host_finish():
    global game_state, net_playing, vs_names_override
    r = vs_result
    net_send({"t": "end", "scores": r["scores"], "winner": r["winner"], "names": r["names"], "skins": r["skins"]})
    net_playing = False
    vs_names_override = None
    game_state = "ONLINE_RESULT"

def online_host_in(j, now):
    """방장이 게스트의 입력을 받음"""
    global net_guest_in, net_guest_ts, net_guest_rt
    try:
        dx = max(-1, min(1, int(j.get("dx", 0)))); dy = max(-1, min(1, int(j.get("dy", 0))))
    except Exception:
        return
    net_guest_in = {"dx": dx, "dy": dy}
    ts = j.get("ts")
    if isinstance(ts, int) and not isinstance(ts, bool):
        net_guest_ts = ts; net_guest_rt = now
    a = j.get("a")
    if a in ("sh", "ss", "dev", "bat") and game_state == "VERSUS" and len(vs_slots) == 2:
        vs_apply_action(vs_slots[1], a, now)


# ---------------- 게스트: 받기 / 보간 / 그리기 ----------------
def online_guest_snap(j, now):
    global net_snaps, net_rtt
    if not (isinstance(j.get("sl"), list) and len(j["sl"]) == 2): return
    try:
        for key, cache, newk, mk in (("c", net_cinfo, "cn", "_c"), ("o", net_oinfo, "on", "_o"), ("i", net_iinfo, "in", "_i")):
            for r in j.get(newk, ()):
                if key == "c": cache[r[0]] = (r[1], r[2], now + r[3])
                elif key == "o": cache[r[0]] = (r[1], r[2], r[3])
                else: cache[r[0]] = (r[1],)
            flat = j.get(key, ())
            m = {}
            for k in range(0, len(flat) - 2, 3): m[flat[k]] = (flat[k + 1], flat[k + 2])
            j[mk] = m
            for k in [k for k in cache if k not in m]: del cache[k]
        j["ht"] = int(j.get("ht", 0))
        old = net_snaps[-1][1] if net_snaps else None
        dht = max(33, j["ht"] - old["ht"]) if old else 0
        for key, cache, mk, ok_ in (("c", net_cinfo, "_c", "_co"), ("o", net_oinfo, "_o", "_oo"), ("i", net_iinfo, "_i", "_io")):
            om = old[mk] if old else None
            objs = []
            for nid, (x, y) in j[mk].items():
                f = cache.get(nid)
                if f is None: continue
                vx = vy = 0.0
                if om is not None:
                    pp = om.get(nid)
                    if pp is not None and abs(x - pp[0]) + abs(y - pp[1]) <= NET_LERP_MAX_DIST:
                        vx = (x - pp[0]) / dht; vy = (y - pp[1]) / dht
                if key == "c": o = {"kind": f[0], "r": f[1], "expire": f[2]}
                elif key == "o": o = {"kind": f[0], "r": f[1], "gen": f[2]}
                else: o = {"type": f[0]}
                o["speed"] = 0; o["x"] = o["bx"] = x; o["y"] = o["by"] = y; o["vx"] = vx; o["vy"] = vy
                objs.append(o)
            j[ok_] = objs
    except Exception:
        return
    g = j.get("g")
    if isinstance(g, list) and len(g) == 2 and isinstance(g[0], int) and isinstance(g[1], int):
        rtt = (now - g[0]) - g[1]    # 내 입력 -> 방장 -> 스냅샷 -> 나 까지 걸린 시간 (방장 대기 시간 제외)
        if 0 <= rtt < 3000:
            net_rtt = float(rtt) if net_rtt <= 0 else net_rtt * 0.8 + rtt * 0.2
    online_guest_reconcile(j, now)
    net_snaps.append((now, j))
    del net_snaps[:-NET_SNAP_KEEP]

def online_pred_speed(skin):
    return PLAYER_SPD * (1.10 if skin == "baby" else 0.90 if skin == "grandpa" else 1.0)

def online_guest_predict(now):
    """게스트: 내 캐릭터는 방장 응답을 기다리지 않고 바로 움직임 (방장 위치와는 스냅샷마다 맞춤)"""
    pr = net_pred
    if not net_snaps or net_snap_phase != "play":
        pr["ok"] = False; return
    d = net_snaps[-1][1]["sl"][net_my_slot]
    if not d["a"]:
        pr["ok"] = False; return
    if not pr["ok"]:
        pr["ok"] = True; pr["x"] = float(d["x"]); pr["y"] = float(d["y"]); pr["t"] = now; pr["hist"] = []
        return
    dts = max(0.0, min(4.0, (now - pr["t"]) / (1000 / REFERENCE_FPS)))
    pr["t"] = now
    inp = online_local_input()
    dx, dy = inp["dx"], inp["dy"]
    if d["tt"] == "invert": dx = -dx; dy = -dy
    if dx != 0 and dy != 0: dx *= 0.7071; dy *= 0.7071
    spd = online_pred_speed(d["k"])
    pr["x"] += dx * spd * dts; pr["y"] += dy * spd * dts
    extra = TWIN_GAP if d["k"] == "twins" else 0
    pr["x"] = min(max(pr["x"], PLAYER_R), WIDTH - PLAYER_R - extra)
    pr["y"] = min(max(pr["y"], PLAYER_R), HEIGHT - PLAYER_R)
    h = pr["hist"]
    h.append((now, pr["x"], pr["y"]))
    while h and now - h[0][0] > 1500: h.pop(0)

def online_guest_reconcile(j, now):
    """방장이 알려 준 내 위치(그때의 내 입력까지 반영된 위치)와 내가 그때 있던 예측 위치를 비교해 어긋남을 줄임"""
    pr = net_pred
    g = j.get("g")
    if not pr["ok"] or not isinstance(g, list) or len(g) != 2: return
    h = pr["hist"]
    tref = g[0] + g[1]
    if len(h) < 2 or tref < h[0][0] or tref > h[-1][0]: return
    k = 0
    while k < len(h) - 1 and h[k + 1][0] < tref: k += 1
    t0, x0, y0 = h[k]; t1, x1, y1 = h[min(k + 1, len(h) - 1)]
    f = 0.0 if t1 <= t0 else max(0.0, min(1.0, (tref - t0) / (t1 - t0)))
    hx, hy = x0 + (x1 - x0) * f, y0 + (y1 - y0) * f
    P = j["sl"][net_my_slot]
    ex, ey = P["x"] - hx, P["y"] - hy
    gain = 1.0 if abs(ex) + abs(ey) > NET_PRED_BIG else NET_PRED_GAIN
    ex *= gain; ey *= gain
    pr["x"] += ex; pr["y"] += ey
    for k in range(len(h)): h[k] = (h[k][0], h[k][1] + ex, h[k][2] + ey)

def online_guest_end(j):
    global vs_result, game_state, net_playing, vs_names_override
    try:
        sc = [int(j["scores"][0]), int(j["scores"][1])]
        w = j.get("winner"); w = w if w in (0, 1) else None
        names = [str(j["names"][0])[:12], str(j["names"][1])[:12]]
        sk = [x if x in SKIN_MAP else "normal" for x in j["skins"][:2]]
        if len(sk) != 2: raise ValueError
    except Exception:
        return
    vs_result = {"scores": sc, "winner": w, "names": names, "skins": sk}
    online_music(False)
    net_playing = False
    vs_names_override = None
    fx_clear()
    game_state = "ONLINE_RESULT"

def _lerp(a, b, k): return a + (b - a) * k

def _ext(cur, old, dht, lead):
    """직전 스냅샷과 비교한 속도로 lead(ms) 만큼 앞서 예상한 위치"""
    if old is None or dht <= 0: return cur
    dx, dy = cur[0] - old[0], cur[1] - old[1]
    if abs(dx) + abs(dy) > NET_LERP_MAX_DIST: return cur
    k = lead / dht
    return (cur[0] + dx * k, cur[1] + dy * k)

def online_guest_render_state(now):
    """받은 스냅샷을 바탕으로 draw_versus 가 쓰는 전역 변수들을 채움.
    방장 화면은 내 입력이 도착한 뒤의 상태로 판정하므로, 물체들을 (스냅샷이 늙은 시간 + 왕복 지연)만큼 앞서 보여 준다"""
    global vs_slots, coins, obstacles, items, vs_world, vs_start_tick, vs_cd_start, net_snap_phase
    if not net_snaps: return False
    tl, last = net_snaps[-1]    # 타이머/수치는 가장 최근 것 기준
    prev = net_snaps[-2][1] if len(net_snaps) >= 2 else None
    dht = max(33, last["ht"] - prev["ht"]) if prev else 0
    lead = max(0.0, min(NET_LEAD_MAX, (now - tl) + net_rtt))
    opp_lead = min(NET_OPP_LEAD_MAX, lead)
    if not vs_slots:
        vs_slots = [{"i": i, "skin": "normal", "ps": PlayerState(), "score": 0, "alive": True, "last_coin": 0, "last_hit": 0,
                     "uncle_mult": 1.0, "uncle_roll": 0, "blink_until": 0, "hud_total": {}} for i in range(2)]
    for i in range(2):
        s, ps = vs_slots[i], vs_slots[i]["ps"]
        d = last["sl"][i]
        s["skin"] = d["k"] if d["k"] in SKIN_MAP else "normal"
        s["alive"] = bool(d["a"]); s["score"] = d["s"]
        s["blink_until"] = tl + d["bl"]
        ps.hp = d["h"]; ps.combo = d["c"]; ps.shield_count = d["sh"]; ps.rewind_charges = d["rw"]; ps.sister_charges = d["sc"]
        if i == net_my_slot and net_pred["ok"]:
            ps.x, ps.y = net_pred["x"], net_pred["y"]
        else:
            q = _ext((d["x"], d["y"]), (prev["sl"][i]["x"], prev["sl"][i]["y"]) if prev else None, dht, opp_lead if i != net_my_slot else lead)
            ps.x, ps.y = q
        ps.magnet_active = d["mg"] > 0; ps.magnet_end_tick = tl + d["mg"]
        ps.kimchi_active = d["km"] > 0; ps.kimchi_end_tick = tl + d["km"]
        ps.minime_active = d["mm"] > 0; ps.minime_end_tick = tl + d["mm"]
        ps.l_active = d["l"] > 0; ps.l_end_tick = tl + d["l"]; ps.l_start_tick = tl - d["ls"]
        ps.tot_trick = d["tt"] or None; ps.tot_end_tick = tl + d["te"]
        ps.tot_msg = d["tx"]; ps.tot_msg_until = tl + d["tu"]
        ps.dev_cd_until = tl + d["dc"]
        ps.bubble = bool(d.get("bb", 0)); ps.bubble_at = (tl + d.get("br", 0)) if d.get("br", 0) > 0 else 0
        ps.bat_count = d.get("bc", 0); ps.cast_id = d.get("cm", 0); ps.cast_until = tl + d.get("cu", 0)
        kk_ = d.get("kk", 0); ps.kk_active = kk_ > 0; ps.kk_end_tick = tl + kk_; ps.kk_start_tick = tl - d.get("ks", 0)
    for key in ("_co", "_oo", "_io"):   # 물체는 스냅샷 때 만든 목록을 그대로 쓰고, 프레임마다 위치만 속도*시간으로 갱신
        for o in last[key]:
            o["x"] = o["bx"] + o["vx"] * lead
            o["y"] = o["by"] + o["vy"] * lead
    coins = last["_co"]; obstacles = last["_oo"]; items = last["_io"]
    vs_world = {k2: (tl + v[0], v[1]) for k2, v in last["w"].items()}
    ph = last["p"]
    if ph == "cd":
        vs_cd_start = tl - (VS_COUNTDOWN_MS - last["tm"])
    else:
        vs_start_tick = tl - (VS_TIME_MS - last["tm"])
    if ph != net_snap_phase:
        if ph == "play": online_music(True)
        net_snap_phase = ph
    return True

def online_guest_send_input(now, action=None):
    global net_last_in, net_last_in_at
    cur = online_local_input()
    if action or cur != net_last_in or now - net_last_in_at >= NET_IN_KEEPALIVE_MS:
        msg = {"t": "in", "dx": cur["dx"], "dy": cur["dy"], "ts": int(now)}
        if action: msg["a"] = action
        net_send(msg)
        net_last_in = cur; net_last_in_at = now

def online_play_event(event):
    """게스트 화면의 키 입력"""
    if event.type == pygame.KEYDOWN and net_snap_phase == "play":
        a = online_key_action(event)
        if a: online_guest_send_input(pygame.time.get_ticks(), a)

net_fps = 0
_net_fps_n = 0
_net_fps_t = 0
def online_draw_stats(now):
    """온라인 대결 화면 오른쪽 위에 내 화면 프레임 수와 핑을 작게 표시"""
    global net_fps, _net_fps_n, _net_fps_t
    _net_fps_n += 1
    if now - _net_fps_t >= 1000:
        net_fps = _net_fps_n; _net_fps_n = 0; _net_fps_t = now
    screen.blit(font_buff.render(f"{net_fps}fps  {net_ping_ms}ms", True, GRAY), (WIDTH - 118, 6))

def draw_online_guest(now):
    if online_guest_render_state(now):
        draw_versus(now, countdown=(net_snap_phase == "cd"))
    else:
        draw_text_center(screen, font_large, t("online_connecting"), WHITE, (WIDTH // 2, HEIGHT // 2))

def online_again():
    """결과 화면 -> 같은 방에서 다시 하기"""
    global game_state, net_ready_me
    net_ready_me = False
    if net_opp is not None: net_opp["ready"] = False
    game_state = "ONLINE_ROOM"


online_result_buttons = [
    Button(WIDTH // 2 - 120, 400, t("retry"), online_again, text_key="retry"),
    Button(WIDTH // 2 + 120, 400, t("online_leave"), online_leave, text_key="online_leave"),
]


# ================= 2.3 HALL OF FAME 2: 온라인 랭킹 (웹 + PC) =================
# 난이도/모드(보드)마다 Top 10 + 내 순위. 신기록이면 자동 제출. 점수 검증은 서버가 함.
# 엔드리스/역경/스피드런은 판을 시작할 때 서버에서 시작 토큰을 받아야 제출할 수 있음 (서버가 걸린 시간을 직접 잼)
RANK_VER = "2.3"
RANK_REFRESH_MS = 10000     # 랭킹 화면이 열려 있는 동안 갱신 간격
RANK_IDLE_MS = 300000       # 아무 입력이 없으면 5분 뒤 갱신 중지
RANK_TIMED = ("endless", "adversity", "speedrun")
RANK_TOP_Y0, RANK_ROW_H = 138, 22
RANK_TAB_RECTS = {"mine": pygame.Rect(20, 14, 120, 28), "online": pygame.Rect(150, 14, 130, 28), "hall": pygame.Rect(290, 14, 150, 28)}
HALL_SHOW = 3               # 명예의 전당에서 한 번에 보여 주는 시즌 수 (최신 시즌부터)
HALL_REFRESH_MS = 60000     # 명예의 전당은 거의 안 바뀌므로 1분 동안은 다시 받지 않음
RANK_ARROW_L = pygame.Rect(210, 92, 40, 28)
RANK_ARROW_R = pygame.Rect(550, 92, 40, 28)
RANK_NICK_RECT = pygame.Rect(320, 450, 200, 26)

rank_tab = "mine"           # mine / online (최고기록 화면)
rank_view = 0               # 온라인 탭에서 보고 있는 보드 (REVEALED_DIFFICULTIES 번호)
rank_data = {}              # 보드 -> {"top": [...], "me": {...}|None, "at": 시각, "err": bool}
rank_reqs = {}              # 요청 id -> (목적, 보드)
rank_req_n = 0
rank_tok = {}               # 보드 -> 시작 토큰
rank_tainted = False        # 이번 판에 치트를 켠 적이 있음
rank_gameover_msg = ""
rank_known = {}             # 보드 -> 서버에 있는 내 기록(점수) 또는 None(기록 없음). 없으면 아직 모름
rank_last_submit = -10**9
rank_sub_val = {}           # 보드 -> 마지막으로 올린 점수
rank_last_fetch = -10**9
rank_open_at = 0
rank_hall_data = {}         # 보드 -> {"seasons": [{"s","ts","top":[{"r","nick","score"}]}], "at": 시각, "err": bool}


def rank_taint():
    global rank_tainted
    rank_tainted = True

def rank_http(method, path, body, purpose, board):
    global rank_req_n
    if not NET_OK: return False
    net_boot()
    if not net_booted: return False
    rank_req_n += 1
    rid = "k%d" % rank_req_n
    rank_reqs[rid] = (purpose, board)
    try:
        _net_js.cgFetch(rid, method, path, "", json.dumps(body) if body is not None else "")
    except Exception:
        rank_reqs.pop(rid, None)
        return False
    return True

def rank_pid():
    return net_pid_cache if net_pid_cache else "anon"

def rank_nick_value():
    """서버에 보낼 닉네임: 정해 둔 닉네임, 없으면 자동 이름 (Coin + 기기 ID 끝 4글자)"""
    n = "".join(ch for ch in vs_nick[0].strip() if vs_char_ok(ch))[:8]
    return n or ("Coin" + "".join(ch for ch in rank_pid()[-4:] if ch.isalnum()))[:8]

def rank_fetch(board):
    global rank_last_fetch
    rank_last_fetch = pygame.time.get_ticks()
    if not NET_OK:
        rank_data[board] = {"top": [], "me": None, "at": rank_last_fetch, "err": True}
        return
    if any(p == "top" and b == board for p, b in rank_reqs.values()): return
    ok = rank_http("GET", "/rank?board=%s&pid=%s" % (board, rank_pid()), None, "top", board)
    if not ok:
        rank_data[board] = {"top": [], "me": None, "at": rank_last_fetch, "err": True}

def rank_hall_fetch(board, force=False):
    now = pygame.time.get_ticks()
    old = rank_hall_data.get(board)
    if old and not old["err"] and not force and now - old["at"] < HALL_REFRESH_MS: return
    if not NET_OK:
        rank_hall_data[board] = {"seasons": [], "at": now, "err": True}
        return
    if any(p == "hall" and b == board for p, b in rank_reqs.values()): return
    if not rank_http("GET", "/rank/hall?board=%s" % board, None, "hall", board):
        rank_hall_data[board] = {"seasons": [], "at": now, "err": True}

def rank_on_start(diff):
    """판을 시작할 때: 치트 표시 초기화 + (엔드리스/역경/스피드런) 서버에서 시작 토큰 받기"""
    global rank_tainted, rank_gameover_msg
    rank_tainted = bool(cheat_on)
    rank_gameover_msg = ""
    rank_tok.pop(diff, None)
    if diff in RANK_TIMED and not rank_tainted:
        rank_http("POST", "/rank/start", {"board": diff, "pid": rank_pid()}, "start", diff)

def rank_beats_online(board, val):
    """2.3.1: 서버에 있는 내 기록(모르면 일단 올려 봄)보다 좋으면 True"""
    if board not in rank_known: return True
    cur = rank_known[board]
    if cur is None: return True
    return val < cur if board == "speedrun" else val > cur

def rank_on_end():
    """end_game 에서 불림: 치트/대결이 아니고 온라인 내 기록을 넘으면 제출 (2.3.1: 기기 최고기록이 아니라 온라인 기록 기준)"""
    global rank_gameover_msg, rank_last_submit
    rank_gameover_msg = ""
    if not NET_OK or cheat_on or rank_tainted: return
    if versus_mode or net_playing: return
    board = difficulty
    if board not in DIFFICULTIES: return
    val = speedrun_final_sec if board == "speedrun" else score
    if val <= 0: return
    if not rank_beats_online(board, int(val)): return
    nowt = pygame.time.get_ticks()
    if nowt - rank_last_submit < 10500: return    # 서버는 같은 기기에서 10초 안에 또 올리는 것을 막음
    body = {"board": board, "score": int(val), "ms": int(max(0, nowt - start_ticks)),
            "input": "k" if sys.platform == "emscripten" else "p", "ver": RANK_VER,
            "pid": rank_pid(), "nick": rank_nick_value(), "tok": rank_tok.get(board, "")}
    if rank_http("POST", "/rank/submit", body, "submit", board):
        rank_last_submit = nowt
        rank_sub_val[board] = int(val)
        rank_gameover_msg = t("rank_sending")

def rank_update(now):
    """응답 처리 + 온라인 탭이 열려 있으면 10초마다 갱신"""
    global rank_gameover_msg
    if NET_OK and net_booted:
        for rid in list(rank_reqs):
            try:
                r = str(_net_js.cgFetchPoll(rid))
            except Exception:
                r = ""
            if not r: continue
            purpose, board = rank_reqs.pop(rid)
            try:
                status, _, body = r.partition("|")
                status = int(status)
                j = json.loads(body) if body else {}
            except Exception:
                status, j = 0, {}
            if not isinstance(j, dict): j = {}
            if purpose == "status":
                if status == 200 and j.get("ok"): gs_apply(j, now)
                else: GS["pending"] = 0    # 못 닿으면 그냥 실행 (닫힘으로 취급하지 않음)
            elif purpose == "top":
                if status == 200 and j.get("ok"):
                    rank_data[board] = {"top": list(j.get("top", []))[:10], "me": j.get("me"), "at": now, "err": False}
                    me_ = j.get("me")
                    if isinstance(me_, dict) and isinstance(me_.get("score"), int) and not isinstance(me_.get("score"), bool): rank_known[board] = me_["score"]
                    elif me_ is None: rank_known[board] = None
                else:
                    old = rank_data.get(board)
                    rank_data[board] = {"top": old["top"] if old else [], "me": old["me"] if old else None, "at": old["at"] if old else now, "err": True}
            elif purpose == "hall":
                if status == 200 and j.get("ok") and isinstance(j.get("seasons"), list):
                    ss = []
                    for x in j["seasons"][:HALL_SHOW]:
                        if not isinstance(x, dict) or not isinstance(x.get("top"), list): continue
                        top = [{"r": int(e.get("r", i + 1)), "nick": str(e.get("nick", ""))[:12], "score": int(e.get("score", 0))}
                               for i, e in enumerate(x["top"][:3]) if isinstance(e, dict) and isinstance(e.get("score", 0), int)]
                        ss.append({"s": int(x.get("s", 0)), "ts": int(x.get("ts", 0)), "top": top})
                    rank_hall_data[board] = {"seasons": ss, "at": now, "err": False}
                else:
                    old = rank_hall_data.get(board)
                    rank_hall_data[board] = {"seasons": old["seasons"] if old else [], "at": old["at"] if old else now, "err": True}
            elif purpose == "start":
                if status == 200 and j.get("ok") and j.get("tok"): rank_tok[board] = str(j["tok"])
            elif purpose == "submit":
                if status == 200 and j.get("ok"):
                    st = j.get("status")
                    if st == "pending": rank_gameover_msg = t("rank_pending")
                    elif j.get("kept"): rank_gameover_msg = t("rank_kept")
                    elif j.get("rank"): rank_gameover_msg = t("rank_got", n=int(j["rank"]))
                    else: rank_gameover_msg = ""
                    rank_data.pop(board, None)   # 내 기록이 바뀌었으니 다음에 열 때 새로 받음
                    if st == "ok" and not j.get("kept") and board in rank_sub_val: rank_known[board] = rank_sub_val[board]
                    else: rank_known.pop(board, None)
                    rank_fetch(board)            # 서버에 있는 내 기록을 다시 받아 둠
                else:
                    rank_gameover_msg = t("rank_fail")
    if game_state == "HIGHSCORE" and rank_tab == "online":
        board = REVEALED_DIFFICULTIES[rank_view]
        active = True
        try: active = bool(pygame.display.get_active())
        except Exception: pass
        if active and now - rank_open_at < RANK_IDLE_MS and now - rank_last_fetch >= RANK_REFRESH_MS:
            rank_fetch(board)

def rank_set_tab(tab):
    global rank_tab, rank_open_at
    rank_stop_edit()
    rank_tab = tab
    rank_open_at = pygame.time.get_ticks()
    if tab == "online": rank_fetch(REVEALED_DIFFICULTIES[rank_view])
    elif tab == "hall": rank_hall_fetch(REVEALED_DIFFICULTIES[rank_view])

def rank_set_board(delta):
    global rank_view, rank_open_at
    rank_view = (rank_view + delta) % len(REVEALED_DIFFICULTIES)
    rank_open_at = pygame.time.get_ticks()
    if rank_tab == "hall": rank_hall_fetch(REVEALED_DIFFICULTIES[rank_view])
    else: rank_fetch(REVEALED_DIFFICULTIES[rank_view])

def rank_start_edit():
    global vs_edit, vs_ime
    vs_edit = 0; vs_ime = ""
    try:
        pygame.key.start_text_input()
        pygame.key.set_text_input_rect(RANK_NICK_RECT)
    except Exception:
        pass

def rank_stop_edit():
    global vs_edit, vs_ime
    if vs_edit == 0:
        vs_edit = None; vs_ime = ""
        try: save_settings(current_settings_dict())
        except Exception: pass

def rank_back():
    rank_stop_edit()
    set_state_main()

def rank_hs_event(event):
    """최고기록 화면의 탭 / 보드 화살표 / 닉네임 입력"""
    global vs_ime, rank_open_at
    if event.type == pygame.TEXTINPUT:
        if vs_edit == 0 and rank_tab == "online":
            vs_text_input(event.text); vs_ime = ""
    elif event.type == pygame.TEXTEDITING:
        vs_ime = event.text if (vs_edit == 0 and rank_tab == "online") else ""
    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        rank_open_at = pygame.time.get_ticks()
        for k, rc in RANK_TAB_RECTS.items():
            if rc.collidepoint(event.pos):
                if k != rank_tab: rank_set_tab(k)
                return
        if rank_tab == "hall":
            if RANK_ARROW_L.collidepoint(event.pos): rank_set_board(-1)
            elif RANK_ARROW_R.collidepoint(event.pos): rank_set_board(1)
        elif rank_tab == "online":
            if RANK_NICK_RECT.collidepoint(event.pos):
                if vs_edit != 0: rank_start_edit()
                return
            rank_stop_edit()
            if RANK_ARROW_L.collidepoint(event.pos): rank_set_board(-1)
            elif RANK_ARROW_R.collidepoint(event.pos): rank_set_board(1)
    elif event.type == pygame.KEYDOWN and rank_tab == "hall":
        if event.key == pygame.K_LEFT: rank_set_board(-1)
        elif event.key == pygame.K_RIGHT: rank_set_board(1)
    elif event.type == pygame.KEYDOWN and rank_tab == "online":
        if vs_edit == 0:
            if event.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_KP_ENTER): rank_stop_edit()
            elif event.key == pygame.K_BACKSPACE and not vs_ime: vs_nick[0] = vs_nick[0][:-1]
        elif event.key == pygame.K_LEFT: rank_set_board(-1)
        elif event.key == pygame.K_RIGHT: rank_set_board(1)

def rank_draw_tabs():
    for k, rc in RANK_TAB_RECTS.items():
        on = (k == rank_tab)
        pygame.draw.rect(screen, (60, 60, 120) if on else (30, 30, 50), rc, border_radius=5)
        pygame.draw.rect(screen, YELLOW if on else GRAY, rc, 2, border_radius=5)
        draw_text_center(screen, font_small, t("rank_tab_" + k), WHITE if on else GRAY, rc.center)

def rank_fmt(board, score):
    return str(score) + (t("sec_unit") if board == "speedrun" else t("no_score"))

def rank_date_text(ts):
    import time as _tm
    try: return _tm.strftime("%Y.%m.%d", _tm.localtime(ts / 1000))
    except Exception: return ""

def rank_draw_hall(now):
    board = REVEALED_DIFFICULTIES[rank_view]
    for rc, txt in ((RANK_ARROW_L, "<"), (RANK_ARROW_R, ">")):
        pygame.draw.rect(screen, (50, 50, 90), rc, border_radius=5)
        pygame.draw.rect(screen, GRAY, rc, 2, border_radius=5)
        draw_text_center(screen, font_small, txt, WHITE, rc.center)
    draw_text_center(screen, font_mid, diff_label(board), YELLOW, (WIDTH // 2, 106))
    d = rank_hall_data.get(board)
    if not NET_OK:
        draw_text_center(screen, font_small, t("online_pc_only"), (255, 140, 140), (WIDTH // 2, 250))
    elif d is None:
        draw_text_center(screen, font_small, t("rank_loading"), GRAY, (WIDTH // 2, 250))
    else:
        if not d["seasons"] and not d["err"]:
            draw_text_center(screen, font_small, t("rank_hall_empty"), GRAY, (WIDTH // 2, 250))
        y = 138
        for x in d["seasons"][:HALL_SHOW]:
            draw_text_center(screen, font_small, t("rank_hall_season", n=x["s"], date=rank_date_text(x["ts"])), (255, 200, 90), (WIDTH // 2, y))
            y += 22
            if not x["top"]:
                draw_text_center(screen, font_buff, t("rank_hall_none"), GRAY, (WIDTH // 2, y)); y += 22
            for i, e in enumerate(x["top"]):
                col = (255, 215, 0) if i == 0 else (220, 220, 230) if i == 1 else (205, 150, 90)
                screen.blit(font_small.render("%d." % (i + 1), True, col), (250, y - 9))
                screen.blit(font_small.render(e["nick"], True, col), (285, y - 9))
                sc_txt = rank_fmt(board, e["score"])
                screen.blit(font_small.render(sc_txt, True, col), (550 - font_small.size(sc_txt)[0], y - 9))
                y += 20
            y += 8
        if d["err"]:
            draw_text_center(screen, font_small, t("rank_err"), (255, 140, 140), (WIDTH // 2, 430))

def rank_draw_online(now):
    board = REVEALED_DIFFICULTIES[rank_view]
    for rc, txt in ((RANK_ARROW_L, "<"), (RANK_ARROW_R, ">")):
        pygame.draw.rect(screen, (50, 50, 90), rc, border_radius=5)
        pygame.draw.rect(screen, GRAY, rc, 2, border_radius=5)
        draw_text_center(screen, font_small, txt, WHITE, rc.center)
    draw_text_center(screen, font_mid, diff_label(board), YELLOW, (WIDTH // 2, 106))
    d = rank_data.get(board)
    if not NET_OK:
        draw_text_center(screen, font_small, t("online_pc_only"), (255, 140, 140), (WIDTH // 2, 250))
    elif d is None:
        draw_text_center(screen, font_small, t("rank_loading"), GRAY, (WIDTH // 2, 250))
    else:
        if not d["top"] and not d["err"]:
            draw_text_center(screen, font_small, t("rank_empty"), GRAY, (WIDTH // 2, 250))
        for i, e in enumerate(d["top"]):
            y = RANK_TOP_Y0 + i * RANK_ROW_H
            col = YELLOW if e.get("me") else WHITE
            name = str(e.get("nick", ""))
            screen.blit(font_small.render("%2d." % int(e.get("r", i + 1)), True, col), (230, y - 9))
            screen.blit(font_small.render(name, True, col), (275, y - 9))
            sc_txt = rank_fmt(board, e.get("score", 0))
            screen.blit(font_small.render(sc_txt, True, col), (570 - font_small.size(sc_txt)[0], y - 9))
        me = d.get("me")
        if me and int(me.get("r", 0)) > 0:
            y = RANK_TOP_Y0 + 10 * RANK_ROW_H + 4
            extra = "" if int(me["r"]) <= 10 else "   %s  %s" % (me.get("nick", ""), rank_fmt(board, me.get("score", 0)))
            draw_text_center(screen, font_small, t("rank_me_line", n=int(me["r"])) + extra, YELLOW, (WIDTH // 2, y))
        if d["err"]:
            draw_text_center(screen, font_small, t("rank_err"), (255, 140, 140), (WIDTH // 2, 388))
        else:
            draw_text_center(screen, font_small, t("rank_updated", n=max(0, (now - d["at"]) // 1000)), GRAY, (WIDTH // 2, 388))
    # 닉네임 칸 (온라인 대결과 같은 닉네임)
    screen.blit(font_small.render(t("rank_nick"), True, WHITE), (230, RANK_NICK_RECT.y + 4))
    rc = RANK_NICK_RECT
    pygame.draw.rect(screen, (0, 0, 70), rc, border_radius=4)
    pygame.draw.rect(screen, YELLOW if vs_edit == 0 else GRAY, rc, 2, border_radius=4)
    if vs_edit == 0:
        ime = vs_ime if sys.platform != "emscripten" or all(0xAC00 <= ord(c) <= 0xD7A3 for c in vs_ime) else ""
        shown = vs_nick[0] + ime + ("|" if (now // 450) % 2 == 0 else "")
        screen.blit(font_small.render(shown, True, WHITE), font_small.render(shown, True, WHITE).get_rect(midleft=(rc.x + 8, rc.centery)))
    elif vs_nick[0]:
        screen.blit(font_small.render(vs_nick[0], True, WHITE), font_small.render(vs_nick[0], True, WHITE).get_rect(midleft=(rc.x + 8, rc.centery)))
    else:
        screen.blit(font_small.render(t("rank_nick_hint"), True, (130, 130, 130)), font_small.render(t("rank_nick_hint"), True, (130, 130, 130)).get_rect(midleft=(rc.x + 8, rc.centery)))


# ================= 2.2 ONLINE: 관리자 (웹 전용) =================
# 메인 화면에서 비밀번호를 그냥 입력하고 Enter -> 서버가 맞는지 확인 -> 관리자 화면.
# 게임 코드에는 비밀번호도 해시도 없습니다. 입력한 글자는 화면에 표시하지 않고, 로그인 요청 뒤에 바로 지웁니다.
ADMIN_BUF_MAX = 32          # 마지막 입력 글자 수
ADMIN_MIN_LEN = 8           # 이보다 짧으면 서버에 보내지 않음
ADMIN_TRY_GAP_MS = 3000     # 로그인 시도 간격
ADMIN_REFRESH_MS = 5000     # 관리자 화면 자동 새로고침
ADMIN_ROWS = 7              # 한 쪽에 보이는 줄 수
ADMIN_BAN_MINUTES = [10, 60, 1440, 0]
ADMIN_BAN_KEYS = ["admin_dur_10", "admin_dur_60", "admin_dur_1440", "admin_dur_0"]

admin_buf = ""
admin_last_try = -10**9
admin_token = ""
admin_token_until = 0
admin_pending = {}          # 요청 id -> (목적, 데이터)
admin_req_n = 0
admin_stats = {}
admin_players = []
admin_recent = []
admin_bans = []
admin_tab = "players"       # players / recent / bans
admin_page = 0
admin_ban_idx = 1
admin_msg = ""
admin_last_refresh = 0


def admin_scan_char(event):
    """물리 키 위치로 a-z / 0-9 를 읽음 (한/영 상태와 상관없이 같은 글자)"""
    sc = getattr(event, "scancode", 0)
    if 4 <= sc <= 29: return chr(ord("a") + sc - 4)
    if 30 <= sc <= 38: return chr(ord("1") + sc - 30)
    if sc == 39: return "0"
    k = event.key
    if 97 <= k <= 122 or 48 <= k <= 57: return chr(k)
    return ""

def admin_key_event(event):
    """메인 화면 키 입력 감지. Enter 에서 서버에 확인"""
    global admin_buf
    if not NET_OK or event.type != pygame.KEYDOWN: return
    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
        if len(admin_buf) >= ADMIN_MIN_LEN:
            admin_login()
        admin_buf = ""
        return
    ch = admin_scan_char(event)
    if ch:
        admin_buf = (admin_buf + ch)[-ADMIN_BUF_MAX:]

def admin_http(method, path, body=None, purpose="", data=None):
    """서버에 HTTP 요청 (결과는 admin_poll 에서 받음)"""
    global admin_req_n
    if not NET_OK: return
    net_boot()
    admin_req_n += 1
    rid = "r%d" % admin_req_n
    admin_pending[rid] = (purpose, data)
    _net_js.cgFetch(rid, method, path, admin_token, json.dumps(body) if body is not None else "")

def admin_login():
    global admin_buf, admin_last_try
    now = pygame.time.get_ticks()
    if now - admin_last_try < ADMIN_TRY_GAP_MS: return
    admin_last_try = now
    buf = admin_buf
    admin_buf = ""
    admin_http("POST", "/admin/login", {"buf": buf}, "login")

def admin_call(path, body=None, purpose="", method="POST"):
    admin_http(method, path, body if body is not None else ({} if method == "POST" else None), purpose)

def admin_refresh():
    global admin_last_refresh
    admin_last_refresh = pygame.time.get_ticks()
    admin_http("GET", "/admin/stats", None, "stats")
    admin_http("GET", "/admin/players", None, "players")
    admin_http("GET", "/admin/bans", None, "bans")

def admin_logout(msg_key=None):
    global admin_token, game_state
    admin_token = ""
    admin_pending.clear()
    if msg_key: net_show_notice(msg_key)
    game_state = "MAIN"

def admin_poll(now):
    """응답이 온 요청 처리 + 자동 새로고침"""
    global admin_token, admin_token_until, admin_stats, admin_players, admin_recent, admin_bans, admin_msg, admin_page
    if not NET_OK or not net_booted: return
    for rid in list(admin_pending):
        try:
            r = str(_net_js.cgFetchPoll(rid))
        except Exception:
            r = ""
        if not r: continue
        purpose, data = admin_pending.pop(rid)
        try:
            status, _, body = r.partition("|")
            status = int(status)
            j = json.loads(body) if body else {}
        except Exception:
            status, j = 0, {}
        if purpose == "login":
            if status == 200 and isinstance(j, dict) and j.get("ok") and j.get("token"):
                admin_token = str(j["token"])
                admin_token_until = now + int(j.get("ttl", 1800)) * 1000
                set_state_admin()
            continue   # 틀리면 아무 반응 없음
        if status == 401:
            admin_logout("admin_expired")
            return
        if status != 200 or not isinstance(j, dict) or not j.get("ok"):
            admin_msg = t("admin_error")
            continue
        if purpose == "stats": admin_stats = j
        elif purpose == "players":
            admin_players = j.get("players", []); admin_recent = j.get("recent", [])
        elif purpose == "bans": admin_bans = j.get("bans", [])
        elif purpose == "action":
            admin_msg = t("admin_done")
            admin_refresh()
    if game_state == "ADMIN":
        if admin_token and now > admin_token_until:
            admin_logout("admin_expired"); return
        if now - admin_last_refresh >= ADMIN_REFRESH_MS: admin_refresh()

def set_state_admin():
    global game_state, admin_tab, admin_page, admin_msg
    admin_tab = "players"; admin_page = 0; admin_msg = ""
    game_state = "ADMIN"
    admin_refresh()

def admin_set_tab(name):
    global admin_tab, admin_page
    admin_tab = name; admin_page = 0

def admin_flip_page(d):
    global admin_page
    n = len(admin_list())
    admin_page = max(0, min(admin_page + d, max(0, (n - 1) // ADMIN_ROWS)))

def admin_cycle_dur():
    global admin_ban_idx
    admin_ban_idx = (admin_ban_idx + 1) % len(ADMIN_BAN_MINUTES)

def admin_toggle_open():
    is_open = admin_stats.get("open", True)
    admin_call("/admin/open", {"open": not is_open}, "action")

def admin_end_all():
    admin_call("/admin/open", {"open": False, "endNow": True}, "action")

def admin_kick(id6): admin_call("/admin/kick", {"id6": id6}, "action")
def admin_ban(id6): admin_call("/admin/ban", {"id6": id6, "minutes": ADMIN_BAN_MINUTES[admin_ban_idx], "note": ""}, "action")
def admin_unban(id6): admin_call("/admin/unban", {"id6": id6}, "action")

def admin_list():
    return {"players": admin_players, "recent": admin_recent, "bans": admin_bans}[admin_tab]

def admin_row_buttons():
    """현재 쪽의 (줄 y, 항목, 버튼 목록). 매 프레임 만들어서 그리기/클릭에 같이 씀"""
    out = []
    lst = admin_list()
    for k, it in enumerate(lst[admin_page * ADMIN_ROWS:(admin_page + 1) * ADMIN_ROWS]):
        y = 206 + k * 33
        id6 = it.get("id6", "")
        btns = []
        if admin_tab == "players":
            btns = [Button(660, y, t("admin_kick"), lambda i=id6: admin_kick(i), width=80, height=28),
                    Button(748, y, t("admin_ban"), lambda i=id6: admin_ban(i), width=64, height=28)]
        elif admin_tab == "recent":
            btns = [Button(748, y, t("admin_ban"), lambda i=id6: admin_ban(i), width=64, height=28)]
        else:
            btns = [Button(748, y, t("admin_unban"), lambda i=id6: admin_unban(i), width=80, height=28)]
        out.append((y, it, btns))
    return out

def admin_static_buttons():
    is_open = admin_stats.get("open", True)
    return [
        Button(95, 80, t("admin_game_close") if admin_stats.get("game_open", True) else t("admin_game_open"), admin_toggle_game, width=160, height=30),
        Button(110, 118, t("admin_online_close") if is_open else t("admin_online_open"), admin_toggle_open, width=190, height=34),
        Button(310, 118, t("admin_end_all"), admin_end_all, width=190, height=34),
        Button(520, 118, t("admin_dur", d=t(ADMIN_BAN_KEYS[admin_ban_idx])), admin_cycle_dur, width=200, height=34),
        Button(690, 118, t("admin_refresh"), admin_refresh, width=130, height=34),
        Button(100, 162, t("admin_tab_players"), lambda: admin_set_tab("players"), width=140, height=32),
        Button(250, 162, t("admin_tab_recent"), lambda: admin_set_tab("recent"), width=150, height=32),
        Button(400, 162, t("admin_tab_bans"), lambda: admin_set_tab("bans"), width=130, height=32),
        Button(690, 162, "<", lambda: admin_flip_page(-1), width=50, height=32),
        Button(750, 162, ">", lambda: admin_flip_page(1), width=50, height=32),
        Button(WIDTH // 2, 470, t("admin_exit"), lambda: admin_logout(), width=200, height=36),
    ]

def admin_event(event):
    for b in admin_static_buttons():
        b.check_event(event)
    for _, _, btns in admin_row_buttons():
        for b in btns:
            b.check_event(event)

def draw_admin(now):
    draw_text_center(screen, font_large, t("admin_title"), WHITE, (WIDTH // 2, 34))
    s = admin_stats
    if s:
        line = t("admin_stats", a=s.get("online", 0), b=s.get("waiting", 0), c=s.get("rooms", 0), d=s.get("matches_today", 0), e=s.get("usage_pct", 0))
        draw_text_center(screen, font_small, line, WHITE, (WIDTH // 2, 68))
        st = t("admin_open_on") if s.get("open", True) else t("admin_open_off")
        draw_text_center(screen, font_buff, st, (120, 255, 120) if s.get("open", True) else (255, 140, 140), (WIDTH // 2, 88))
        go = s.get("game_open", True)
        draw_text_center(screen, font_buff, t("admin_game_on") if go else t("admin_game_off"), (120, 255, 120) if go else (255, 140, 140), (715, 88))
    for b in admin_static_buttons():
        b.draw(screen)
    names = {"players": "admin_tab_players", "recent": "admin_tab_recent", "bans": "admin_tab_bans"}
    draw_text_center(screen, font_buff, "[" + t(names[admin_tab]) + "]  " + str(admin_page + 1) + "/" + str(max(1, (len(admin_list()) + ADMIN_ROWS - 1) // ADMIN_ROWS)), GRAY, (580, 162))
    rows = admin_row_buttons()
    if not rows:
        draw_text_center(screen, font_small, t("admin_none"), GRAY, (WIDTH // 2, 230))
    for y, it, btns in rows:
        nm = it.get("nick") or t("admin_noname")
        if admin_tab == "players": extra = t("admin_state_" + str(it.get("state", "room")))
        elif admin_tab == "recent": extra = time_ago(it.get("last", 0))
        else: extra = t("admin_dur_0") if not it.get("until") else ""
        txt = f"{nm}   #{it.get('id6', '')}   {extra}"
        screen.blit(font_small.render(txt, True, WHITE), font_small.render(txt, True, WHITE).get_rect(midleft=(24, y)))
        for b in btns: b.draw(screen)
    if admin_msg:
        draw_text_center(screen, font_buff, admin_msg, (255, 220, 120), (WIDTH // 2, 440))

def time_ago(ms_epoch):
    """서버의 시각(밀리초)을 '몇 분 전' 으로 (게임 시계와 달라서 현재 시각은 JS 에서 받아 옴)"""
    try:
        now_ms = float(_net_js.cgNow())
    except Exception:
        return ""
    mins = max(0, int((now_ms - ms_epoch) / 60000))
    return t("admin_ago_min", n=mins) if mins < 60 else t("admin_ago_hour", n=mins // 60)


# 2.0: 버튼 소형화 + 4개씩 2줄 (MENU_X_STEP = 가로 간격, MENU_ROW_Y = 줄 높이)
MENU_X_STEP = 130
MENU_ROW_Y = (362, 428)
MENU_X = [WIDTH // 2 + MENU_X_STEP * (k - 1.5) for k in range(4)]
main_buttons = [
    Button(WIDTH // 2, 200, t("start"), set_state_play_type, width=220, height=56, text_key="start"),
    Button(MENU_X[0], MENU_ROW_Y[0], t("settings"), set_state_settings, icon=img.get("icon_settings"), text_key="settings"),
    Button(MENU_X[1], MENU_ROW_Y[0], t("highscore"), set_state_highscore, icon=img.get("icon_highscore"), text_key="highscore"),
    Button(MENU_X[2], MENU_ROW_Y[0], t("missions_achv"), set_state_achievements, icon=img.get("icon_missions"), text_key="missions_achv"),
    Button(MENU_X[3], MENU_ROW_Y[0], t("family"), set_state_skins, icon=img.get("icon_family"), text_key="family"),
    Button(MENU_X[0], MENU_ROW_Y[1], t("new_feature"), set_state_info, icon=img.get("icon_new"), text_key="new_feature"),
    Button(MENU_X[1], MENU_ROW_Y[1], t("howto"), set_state_howto, icon=img.get("icon_howto"), text_key="howto"),
    Button(MENU_X[2], MENU_ROW_Y[1], t("history"), set_state_history, icon=img.get("icon_history"), text_key="history"),
    Button(MENU_X[3], MENU_ROW_Y[1], t("credits"), set_state_credits, icon=img.get("icon_credits"), text_key="credits"),
]

achievements_buttons = [
    Button(WIDTH // 2 - 70, 15, t("achievements"), set_state_achievements, text_key="achievements"),
    Button(WIDTH // 2 + 70, 15, t("missions"), set_state_missions, text_key="missions"),
    Button(WIDTH // 2, HEIGHT - 30, t("back"), set_state_main, text_key="back"),
]
mission_buttons = [
    Button(WIDTH // 2 - 70, 15, t("achievements"), set_state_achievements, text_key="achievements"),
    Button(WIDTH // 2 + 70, 15, t("missions"), set_state_missions, text_key="missions"),
    Button(WIDTH // 2, HEIGHT - 30, t("back"), set_state_main, text_key="back"),
]
SKIN_ROW_Y0, SKIN_ROW_STEP = 80, 56   # 한 쪽에 SKIN_PER_PAGE 종씩 (넘치면 이전/다음 버튼)
SKIN_PER_PAGE = 6
SKIN_PAGES = max(1, -(-len(SKIN_ORDER) // SKIN_PER_PAGE))
skin_page = 0
SKIN_NAV_Y = 425
def turn_skin_page(delta):
    global skin_page
    skin_page = min(SKIN_PAGES - 1, max(0, skin_page + delta))

skins_equip_buttons = [Button(WIDTH - 80, SKIN_ROW_Y0 + (i % SKIN_PER_PAGE) * SKIN_ROW_STEP + 8, t("equip"), lambda s=sid: equip_skin(s),
                              width=110, height=30, text_key="equip")
                       for i, sid in enumerate(SKIN_ORDER)]
skins_prev_button = Button(WIDTH // 2 - 160, SKIN_NAV_Y, t("prev"), lambda: turn_skin_page(-1), width=110, text_key="prev")
skins_next_button = Button(WIDTH // 2 + 160, SKIN_NAV_Y, t("next"), lambda: turn_skin_page(+1), width=110, text_key="next")
skins_back_button = Button(WIDTH // 2, HEIGHT - 22, t("back"), set_state_main, height=34, text_key="back")
def code_open():
    global code_edit, code_buf
    code_edit = True; code_buf = ""
    try: pygame.key.start_text_input()
    except Exception: pass

def code_close():
    global code_edit, code_buf
    code_edit = False; code_buf = ""
    try: pygame.key.stop_text_input()
    except Exception: pass

def code_submit():
    global code_msg, code_msg_until
    sid = try_unlock_code(code_buf)
    now = pygame.time.get_ticks()
    if sid is None:
        code_msg = t("code_bad")
    elif ach_unlocked.get("code_" + sid):
        code_msg = t("code_have")
    else:
        ach_unlocked["code_" + sid] = True
        flush_achievements()
        code_msg = t("code_ok", name=SKIN_MAP[sid]["label"][lang])
    code_msg_until = now + 2500
    code_close()

def code_event(event):
    """코드 입력 중 키/글자 처리 (처리했으면 True)"""
    global code_buf
    if event.type == pygame.TEXTINPUT:
        for ch in event.text:
            if len(code_buf) < 24 and ch.isascii() and (ch.isalnum() or ch in "-_"): code_buf += ch
        return True
    if event.type == pygame.KEYDOWN:
        if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER): code_submit()
        elif event.key == pygame.K_ESCAPE: code_close()
        elif event.key == pygame.K_BACKSPACE: code_buf = code_buf[:-1]
        return True
    return event.type == pygame.TEXTEDITING

skins_code_button = Button(WIDTH - 90, HEIGHT - 22, t("code_btn"), code_open, width=150, height=34, text_key="code_btn")
skins_buttons = skins_equip_buttons + [skins_prev_button, skins_next_button, skins_back_button, skins_code_button]   # 전체 목록(번역 갱신 등에 사용)

def visible_skin_buttons():
    """현재 쪽에 보이는 버튼: 이 쪽의 장착 버튼 + (갈 쪽이 있을 때만) 이전/다음 + 뒤로"""
    lo = skin_page * SKIN_PER_PAGE
    out = skins_equip_buttons[lo:lo + SKIN_PER_PAGE]
    if SKIN_PAGES > 1 and skin_page > 0: out.append(skins_prev_button)
    if SKIN_PAGES > 1 and skin_page < SKIN_PAGES - 1: out.append(skins_next_button)
    out.append(skins_back_button)
    out.append(skins_code_button)
    return out

diff_buttons = [
    Button(WIDTH // 2, 150, t("easy"), lambda: start_game_with_diff("easy"), text_key="easy"),
    Button(WIDTH // 2, 200, t("normal"), lambda: start_game_with_diff("normal"), text_key="normal"),
    Button(WIDTH // 2, 250, t("hard"), lambda: start_game_with_diff("hard"), text_key="hard"),
    Button(WIDTH // 2, 300, t("hell"), lambda: start_game_with_diff("hell"), text_key="hell"),
    Button(WIDTH // 2, 350, t("hellhell"), lambda: start_game_with_diff("hellhell"), text_key="hellhell"),
    Button(WIDTH // 2, 400, t("hellhellhell"), lambda: guarded_start("hellhellhell", "unlock_hellhellhell", diff_coming_soon), text_key="hellhellhell"),
]
diff_buttons_back = [Button(WIDTH // 2, 460, t("back"), set_state_mode_select, text_key="back")]

mode_select_buttons = [
    Button(WIDTH // 2, 150, t("basic_mode"), set_state_diff, text_key="basic_mode"),
    Button(WIDTH // 2, 210, t("endless"), lambda: guarded_start("endless", "unlock_endless", mode_coming_soon), text_key="endless"),
    Button(WIDTH // 2, 270, t("adversity"), lambda: guarded_start("adversity", "unlock_adversity", mode_coming_soon), text_key="adversity"),
    Button(WIDTH // 2, 330, t("speedrun"), lambda: guarded_start("speedrun", "unlock_speedrun", mode_coming_soon), text_key="speedrun"),
    Button(WIDTH // 2, 460, t("back"), set_state_play_type, text_key="back"),
]

info_buttons = [Button(WIDTH // 2, 420, t("back"), set_state_main, text_key="back")]
howto_buttons = [
    Button(WIDTH // 2 - 160, 458, t("prev"), lambda: turn_page("HOWTO", -1), width=110, text_key="prev"),
    Button(WIDTH // 2 + 160, 458, t("next"), lambda: turn_page("HOWTO", +1), width=110, text_key="next"),
    Button(WIDTH // 2, 458, t("back"), set_state_main, width=130, text_key="back"),
]
history_buttons = [
    Button(WIDTH // 2 - 160, 458, t("prev"), lambda: turn_page("HISTORY", -1), width=110, text_key="prev"),
    Button(WIDTH // 2 + 160, 458, t("next"), lambda: turn_page("HISTORY", +1), width=110, text_key="next"),
    Button(WIDTH // 2, 458, t("back"), set_state_main, width=130, text_key="back"),
]
credits_buttons = [Button(WIDTH // 2, 440, t("back"), set_state_main, text_key="back")]
gameover_buttons = [
    Button(WIDTH // 2, 330, t("retry"), set_state_diff, text_key="retry"),
    Button(WIDTH // 2, 390, t("to_main"), set_state_main, text_key="to_main"),
]
highscore_buttons = [Button(WIDTH // 2, 420, t("back"), rank_back, text_key="back")]

SET_LABEL_X, SET_CTRL_X = 100, 590   # 설정탭: 왼쪽 라벨 / 오른쪽 컨트롤, 한 항목이 한 줄
SET_ROW_Y = [96, 144, 192, 240, 288, 336, 384, 432]
settings_buttons = [
    Button(SET_CTRL_X - 60, SET_ROW_Y[0], "-", lambda: change_volume(-0.1), width=50),
    Button(SET_CTRL_X + 60, SET_ROW_Y[0], "+", lambda: change_volume(0.1), width=50),
    Button(SET_CTRL_X, SET_ROW_Y[1], "", toggle_bgm, width=90, onoff=lambda: bgm_on),
] + [
    Button(SET_CTRL_X - 155 + i * 62, SET_ROW_Y[2], str(v), lambda v=v: set_fps_limit(v), width=54)
    for i, v in enumerate(FPS_OPTIONS)
] + [
    Button(SET_CTRL_X, SET_ROW_Y[3], "EN/KO", toggle_lang, width=90),
    Button(SET_CTRL_X, SET_ROW_Y[4], "", toggle_twisted, width=90, onoff=lambda: twisted_on),
    Button(SET_CTRL_X, SET_ROW_Y[5], "", toggle_anim, width=90, onoff=lambda: anim_on),
    Button(SET_CTRL_X, SET_ROW_Y[6], "", toggle_halloween, width=90, onoff=lambda: halloween_on),
] + [
    Button(SET_CTRL_X - 93 + i * 62, SET_ROW_Y[7], str(v), lambda v=v: set_net_rate(v), width=54, height=30)
    for i, v in enumerate(NET_RATE_OPTIONS)
] + [
    Button(WIDTH // 2, 476, t("back"), set_state_main, text_key="back", height=36),
]


# ================= 2.4 MOBILE: 터치 조이스틱 + 버튼 =================
# 왼쪽 화면을 누르면 그 자리에 조이스틱이 생기고(플로팅), 오른쪽에 버튼이 있음.
# 조이스틱은 방향만 읽어서 키보드와 똑같이 8방향(-1/0/1)으로 바꿈 -> 이동 속도/점수 공정성이 키보드와 같음.
# 손가락 이벤트(FINGER*)가 오면 멀티터치로, 안 오면 마우스 이벤트(한 손가락)로 동작.
TOUCH_JOY_R = 60            # 조이스틱 반지름 (게임 화면 기준 px)
TOUCH_DEAD = 14             # 이 안쪽은 움직임 없음
TOUCH_BTN_R = 38
TOUCH_BTNS = {"sh": (WIDTH - 62, HEIGHT - 70), "ss": (WIDTH - 62, HEIGHT - 160), "dev": (WIDTH - 150, HEIGHT - 70), "bat": (WIDTH - 150, HEIGHT - 160)}
TOUCH_HINT = (110, HEIGHT - 95)
touch_on = False            # 터치 기기로 판단되면 True (키보드를 누르면 False)
touch_finger_seen = False   # FINGER 이벤트가 온 적이 있음 (멀티터치 가능)
touch_ids = {}              # 손가락 번호 -> "joy" 또는 "btn"
touch_joy = {"on": False, "id": None, "ox": 0.0, "oy": 0.0, "x": 0.0, "y": 0.0}
touch_btn_down = {}         # 버튼 이름 -> 눌려 있는 동안 True (그리기용)

def touch_play_state():
    """터치 조작이 쓰이는 화면인지: 싱글 플레이, 온라인 대결(방장/게스트)"""
    return game_state == "PLAYING" or (game_state == "VERSUS" and net_playing) or game_state == "ONLINE_PLAY"

def touch_my_skin():
    try:
        if game_state == "PLAYING": return equipped_skin
        if game_state == "VERSUS" and net_playing and vs_slots: return vs_slots[0]["skin"]
        if game_state == "ONLINE_PLAY" and vs_slots: return vs_slots[net_my_slot]["skin"]
    except Exception:
        pass
    return ""

def touch_pos(event):
    if hasattr(event, "pos"): return event.pos
    return (event.x * WIDTH, event.y * HEIGHT)

def touch_has_bat():
    try:
        if game_state == "PLAYING": return player.bat_count > 0
        if game_state == "VERSUS" and net_playing and vs_slots: return vs_slots[0]["ps"].bat_count > 0
        if game_state == "ONLINE_PLAY" and vs_slots: return vs_slots[net_my_slot]["ps"].bat_count > 0
    except Exception:
        pass
    return False

def touch_btn_at(pos):
    for k, (cx, cy) in TOUCH_BTNS.items():
        if k == "dev" and not skin_has_o(touch_my_skin()): continue
        if k == "bat" and not touch_has_bat(): continue
        if (pos[0] - cx) ** 2 + (pos[1] - cy) ** 2 <= (TOUCH_BTN_R + 6) ** 2: return k
    return None

def touch_action(a):
    """버튼을 눌렀을 때: 키보드 Space / Shift / 개발자 능력과 같은 행동"""
    global score
    now = pygame.time.get_ticks()
    if game_state == "PLAYING":
        if a == "ss":
            if score >= 5:
                score -= 5; player.hp += 1
        elif a == "sh":
            if player.hp > 0:
                player.hp -= 1; score += 5
        elif a == "dev" and skin_has_o(equipped_skin):
            o_ability(now)
        elif a == "bat":
            bat_item_use(now)
    elif game_state == "VERSUS" and net_playing and net_role == "host":
        vs_apply_action(vs_slots[0], a, now)
    elif game_state == "ONLINE_PLAY" and net_snap_phase == "play":
        online_guest_send_input(now, a)

def touch_event(event):
    """메인 루프에서 모든 이벤트에 대해 불림"""
    global touch_on, touch_finger_seen
    t_ = event.type
    if t_ == pygame.KEYDOWN:
        touch_on = False
        return
    FD, FM, FU = getattr(pygame, "FINGERDOWN", -1), getattr(pygame, "FINGERMOTION", -2), getattr(pygame, "FINGERUP", -3)
    is_finger = t_ in (FD, FM, FU)
    is_mouse = t_ in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION)
    if not (is_finger or is_mouse): return
    if is_finger:
        touch_finger_seen = True; touch_on = True
    elif getattr(event, "touch", False):
        touch_on = True
    if not touch_on: return
    if is_mouse and touch_finger_seen: return    # 손가락 이벤트가 오면 마우스 흉내 이벤트는 무시 (이중 처리 방지)
    if is_mouse and t_ != pygame.MOUSEMOTION and getattr(event, "button", 1) != 1: return
    if not touch_play_state():
        touch_release_all()
        return
    fid = getattr(event, "finger_id", None) if is_finger else "m"
    down = t_ in (FD, pygame.MOUSEBUTTONDOWN)
    up = t_ in (FU, pygame.MOUSEBUTTONUP)
    pos = touch_pos(event)
    if down:
        b = touch_btn_at(pos)
        if b:
            touch_ids[fid] = "btn"; touch_btn_down[b] = fid
            touch_action(b)
        elif pos[0] < WIDTH * 0.55 and not touch_joy["on"]:
            touch_ids[fid] = "joy"
            touch_joy.update({"on": True, "id": fid, "ox": float(pos[0]), "oy": float(pos[1]), "x": float(pos[0]), "y": float(pos[1])})
    elif up:
        kind = touch_ids.pop(fid, None)
        if kind == "joy" and touch_joy["id"] == fid:
            touch_joy["on"] = False; touch_joy["id"] = None
        elif kind == "btn":
            for k in [k for k, v in touch_btn_down.items() if v == fid]: del touch_btn_down[k]
    else:   # 움직임
        if touch_joy["on"] and touch_joy["id"] == fid and touch_ids.get(fid) == "joy":
            if is_mouse and not (getattr(event, "buttons", (1,))[0] if hasattr(event, "buttons") else 1):
                return
            touch_joy["x"], touch_joy["y"] = float(pos[0]), float(pos[1])

def touch_release_all():
    touch_ids.clear(); touch_btn_down.clear()
    touch_joy["on"] = False; touch_joy["id"] = None

def touch_move():
    """조이스틱 -> (dx, dy) 각각 -1/0/1 (키보드와 같은 8방향). 안 쓰면 (0, 0)"""
    if not (touch_on and touch_joy["on"] and touch_play_state()): return (0, 0)
    vx = touch_joy["x"] - touch_joy["ox"]; vy = touch_joy["y"] - touch_joy["oy"]
    d = (vx * vx + vy * vy) ** 0.5
    if d < TOUCH_DEAD: return (0, 0)
    k = 0.3827 * d     # sin 22.5도: 이보다 작은 축 성분은 0으로 보고 8방향으로 맞춤
    dx = 0 if abs(vx) < k else (1 if vx > 0 else -1)
    dy = 0 if abs(vy) < k else (1 if vy > 0 else -1)
    return (dx, dy)

def touch_draw():
    if not (touch_on and touch_play_state()): return
    ov = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    if touch_joy["on"]:
        ox, oy = int(touch_joy["ox"]), int(touch_joy["oy"])
        vx = touch_joy["x"] - touch_joy["ox"]; vy = touch_joy["y"] - touch_joy["oy"]
        d = (vx * vx + vy * vy) ** 0.5
        if d > TOUCH_JOY_R: vx, vy = vx * TOUCH_JOY_R / d, vy * TOUCH_JOY_R / d
        pygame.draw.circle(ov, (255, 255, 255, 50), (ox, oy), TOUCH_JOY_R)
        pygame.draw.circle(ov, (255, 255, 255, 120), (ox, oy), TOUCH_JOY_R, 2)
        pygame.draw.circle(ov, (255, 255, 255, 170), (int(ox + vx), int(oy + vy)), 24)
    else:
        pygame.draw.circle(ov, (255, 255, 255, 40), TOUCH_HINT, TOUCH_JOY_R, 2)
        pygame.draw.circle(ov, (255, 255, 255, 60), TOUCH_HINT, 18)
    screen.blit(ov, (0, 0))
    for k, (cx, cy) in TOUCH_BTNS.items():
        if k == "dev" and not skin_has_o(touch_my_skin()): continue
        if k == "bat" and not touch_has_bat(): continue
        pressed = k in touch_btn_down
        b = pygame.Surface((TOUCH_BTN_R * 2 + 4, TOUCH_BTN_R * 2 + 4), pygame.SRCALPHA)
        pygame.draw.circle(b, (255, 255, 255, 110 if pressed else 55), (TOUCH_BTN_R + 2, TOUCH_BTN_R + 2), TOUCH_BTN_R)
        pygame.draw.circle(b, (255, 255, 255, 170), (TOUCH_BTN_R + 2, TOUCH_BTN_R + 2), TOUCH_BTN_R, 2)
        screen.blit(b, (cx - TOUCH_BTN_R - 2, cy - TOUCH_BTN_R - 2))
        draw_text_center(screen, font_buff, t("touch_" + k), WHITE, (cx, cy))

def set_state_vs_setup_guarded():
    """로컬 대결(한 키보드)은 터치 기기에서는 열지 않음"""
    if touch_on:
        net_show_notice("touch_need_kb")
        return
    set_state_vs_setup()

# ================= 2.4 게임 전체 닫기 (관리자가 서버에서 닫으면 CLOSED 화면) =================
# 게임은 시작할 때 한 번, 그 뒤 서버가 알려 준 간격(기본 60초)마다 GET /status 로 물어봄.
# 서버에 못 닿으면(연결 불가/시간 초과/오류) 그냥 실행함. 닫힘 판정은 성공한 응답에서만 함.
GS_ACTIVE = ("PLAYING", "VERSUS", "VS_COUNTDOWN", "ONLINE_PLAY")
GS_GRACE_MS = 4000          # 판이 끝난 뒤 결과를 잠깐 보여 주고 닫음
GS_PENDING_MAX_MS = 15000   # 응답이 이만큼 안 오면 요청이 사라진 걸로 보고 다시 물어봄
GS_RECHECK_GAP_MS = 15000   # [다시 확인] 버튼 간격
GS = {"open": True, "msg": "", "reopen": 0, "now": False, "next": 60, "last_try": -10**9, "pending": 0,
      "active_end": -10**9, "recheck_at": -10**9, "recheck_note": ""}

def gs_request(now):
    GS["last_try"] = now
    if not NET_OK: return
    if rank_http("GET", "/status", None, "status", ""):
        GS["pending"] = now

def gs_apply(j, now):
    """성공한 /status 응답을 반영"""
    GS["pending"] = 0
    try:
        GS["open"] = bool(j.get("open", True))
        GS["msg"] = str(j.get("msg", ""))[:40]
        GS["reopen"] = int(j.get("reopen_at", 0) or 0)
        GS["now"] = bool(j.get("now", False))
        GS["next"] = max(30, min(600, int(j.get("next", 60))))
    except Exception:
        GS["open"] = True
    if GS["open"]:
        GS["recheck_note"] = ""
    elif game_state == "CLOSED":
        GS["recheck_note"] = t("closed_still")

def gs_reopen_text():
    """열리는 시각 (기기의 시간대 기준 시:분)"""
    ms = GS["reopen"]
    if ms <= 0: return ""
    try:
        import time as _tm24
        return t("closed_reopen", t=_tm24.strftime("%H:%M", _tm24.localtime(ms / 1000.0)))
    except Exception:
        return ""

def game_close_now():
    """지금 바로 CLOSED 로: 진행 중인 판은 기록하지 않음 (이미 저장된 기록/업적/미션은 그대로)"""
    global game_state
    try:
        if game_state in ("VS_COUNTDOWN", "VERSUS") and not net_playing: end_versus()
    except Exception:
        pass
    try:
        if net_playing or game_state.startswith("ONLINE"):
            net_send({"t": "leave"}); online_abort_play(); net_close(); vs_stop_edit()
    except Exception:
        pass
    try: pygame.mixer.music.stop()
    except Exception: pass
    try: touch_release_all()
    except Exception: pass
    GS["recheck_note"] = ""
    game_state = "CLOSED"

def game_status_update(now):
    """메인 루프에서 매 프레임 부름: 주기적으로 상태를 묻고, 닫힘이면 알맞은 때에 CLOSED 로 보냄"""
    global game_state
    if GS["pending"] and now - GS["pending"] > GS_PENDING_MAX_MS: GS["pending"] = 0
    if not GS["pending"] and now - GS["last_try"] >= GS["next"] * 1000:
        gs_request(now)
    if GS["open"]:
        if game_state == "CLOSED": game_state = "MAIN"
        return
    if game_state in ("CLOSED", "ADMIN"):   # 관리자 화면은 닫힘의 영향을 받지 않음
        GS["active_end"] = -10**9   # 관리자 화면을 나오면 기다리지 않고 바로 닫힘
        return
    if game_state in GS_ACTIVE:
        GS["active_end"] = now
        if GS["now"]: game_close_now()
        return
    if now - GS["active_end"] >= GS_GRACE_MS: game_close_now()

def closed_recheck():
    now = pygame.time.get_ticks()
    if now - GS["recheck_at"] < GS_RECHECK_GAP_MS:
        GS["recheck_note"] = t("closed_wait"); return
    GS["recheck_at"] = now
    GS["recheck_note"] = t("closed_checking")
    gs_request(now)

closed_buttons = [Button(WIDTH // 2, 330, t("closed_recheck"), closed_recheck, width=220, height=44, text_key="closed_recheck")]

def closed_event(event):
    for b in closed_buttons: b.check_event(event)

def draw_closed(now):
    draw_text_center(screen, font_large, t("closed_title"), WHITE, (WIDTH // 2, 150))
    if GS["msg"]:
        draw_text_center(screen, font_mid, GS["msg"], YELLOW, (WIDTH // 2, 215))
    rt = gs_reopen_text()
    if rt:
        draw_text_center(screen, font_small, rt, GRAY, (WIDTH // 2, 262))
    for b in closed_buttons: b.draw(screen)
    if GS["recheck_note"]:
        draw_text_center(screen, font_small, GS["recheck_note"], (255, 220, 120), (WIDTH // 2, 392))

def admin_toggle_game():
    if admin_stats.get("game_open", True):
        admin_call("/admin/game", {"open": False, "msg": t("admin_game_default_msg"), "minutes": 0, "endNow": False}, "action")
    else:
        admin_call("/admin/game", {"open": True}, "action")


UPDATE_INFO_LINES = [
    ("[ver 2.4 ANNIVERSARY]", True),
    ("new_feature_24", False),
    ("", False),
    ("[ver 2.3.1 HALL OF FAME 2 BUGFIX]", True),
    ("new_feature_23", False),
    ("", False),
    ("[ver 2.2 ONLINE]", True),
    ("new_feature_22", False),

]

running = True
async def main():
    global _, _fps_frame_accum, _fps_timer_start, achievement_toast_msg, achievement_toast_until, aid, bb_col, bb_txt, blink_hide, bodies, bonus, box, bpos, btn, btns, bx, by, c2, cap_col, cap_i, cfg, chance, coin, coin_spawn_rolls, coins, col, color, cond_dict, current_tick, d, desc, desc2, dev_left, diff, dist, dodged, done, draw_category_column, draw_mission_column, dt_ms, dt_scale, dx, dy, eff_spd, elapsed_time, event, events, fps_avg, fps_current, fx_combo_pop_until, fx_flash_start, fx_milestone_done, g, gain, h, had_combo, hp_color, hs, i, immune, info, is_header, item, items, itype, kc, key, keys, l_bodies, label, last_coin_time, last_hit_time, lbl, left_cats, line, line_key, lt, m, mag_range, mark, mid, mission_n, name_dict, ny, ob, ob_col, ob_key, ob_mult, obstacles, p_color, p_key, popping, prefix, pull, pv, pv_surf, px, py, rect_obj, render_count, req_name, res_text, right_cats, right_extra, row_txt, row_y, running, score, sid, skin_key, skin_label, slow_mult, spd, st, sub, sub_line, sv, t_color, target, tck, tdx, tdy, text_lines, time_left, tot_txt, total, turn_max, tx, txt, ty, uncle_roll_at, uncle_speed_mult, unlocked, unlocked_n, v, v_txt, want, y, y_offset, zz_dph
    while running:
        await asyncio.sleep(0)   # 웹: 매 프레임 브라우저에 제어권을 돌려줌
        dt_ms = clock.tick(FPS)
        dt_scale = dt_ms / (1000 / REFERENCE_FPS)  # FPS 설정과 무관하게 체감 속도를 고정하기 위한 기준점 보정
        current_tick = pygame.time.get_ticks()
        check_dev_mode_toggle()

        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                running = False
            touch_event(event)   # 2.4 터치 조이스틱/버튼

            if game_state == "MAIN":
                check_cheat_input(event)
                admin_key_event(event)   # 2.2 관리자: 메인 화면에서 비밀번호 입력 감지
                for btn in main_buttons:
                    btn.check_event(event)
            elif game_state == "DIFF_SELECT":
                for btn in diff_buttons:
                    btn.check_event(event)
                for btn in diff_buttons_back:
                    btn.check_event(event)
            elif game_state == "MODE_SELECT":
                for btn in mode_select_buttons:
                    btn.check_event(event)
            elif game_state == "UPDATE_INFO":
                for btn in info_buttons:
                    btn.check_event(event)
            elif game_state == "HOWTO":
                for btn in howto_buttons:
                    btn.check_event(event)
            elif game_state == "HISTORY":
                for btn in history_buttons:
                    btn.check_event(event)
            elif game_state == "CREDITS":
                for btn in credits_buttons:
                    btn.check_event(event)
            elif game_state == "HIGHSCORE":
                for btn in highscore_buttons:
                    btn.check_event(event)
                rank_hs_event(event)
            elif game_state == "SETTINGS":
                for btn in settings_buttons:
                    btn.check_event(event)
            elif game_state == "ACHIEVEMENTS":
                for btn in achievements_buttons:
                    btn.check_event(event)
            elif game_state == "MISSIONS":
                for btn in mission_buttons:
                    btn.check_event(event)
            elif game_state == "SKINS":
                if code_edit:
                    code_event(event)
                else:
                    for btn in visible_skin_buttons():
                        btn.check_event(event)
            elif game_state == "GAMEOVER":
                for btn in gameover_buttons:
                    btn.check_event(event)
            elif game_state == "PLAY_TYPE":
                for btn in play_type_buttons:
                    btn.check_event(event)
            elif game_state == "MULTI_MENU":
                for btn in multi_menu_buttons:
                    btn.check_event(event)
            elif game_state == "ONLINE_MENU":
                for btn in online_menu_buttons:
                    btn.check_event(event)
            elif game_state == "ONLINE_JOIN":
                online_join_event(event)
            elif game_state == "ONLINE_WAIT":
                for btn in online_wait_buttons:
                    btn.check_event(event)
            elif game_state == "ONLINE_ROOM":
                online_room_event(event)
            elif game_state == "ADMIN":
                admin_event(event)
            elif game_state == "CLOSED":
                admin_key_event(event)   # 닫혀 있어도 관리자 비밀번호 입력은 동작
                closed_event(event)
            elif game_state == "ONLINE_PLAY":
                online_play_event(event)
            elif game_state == "ONLINE_RESULT":
                for btn in online_result_buttons:
                    btn.check_event(event)
            elif game_state == "ONLINE_SPEC":
                spec_event(event)
            elif game_state == "ONLINE_SPEC_RESULT":
                for btn in spec_result_buttons:
                    btn.check_event(event)
            elif game_state == "VS_SETUP":
                vs_setup_event(event)
            elif game_state == "VERSUS":
                vs_game_event(event, current_tick)
            elif game_state == "VS_RESULT":
                for btn in vs_result_buttons:
                    btn.check_event(event)
            elif game_state == "PLAYING":
                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_LSHIFT, pygame.K_RSHIFT):
                        if score >= 5:
                            score -= 5
                            player.hp += 1
                    elif event.key == pygame.K_SPACE:
                        if player.hp > 0:
                            player.hp -= 1
                            score += 5
                    elif skin_has_o(equipped_skin) and (event.key == pygame.K_o or getattr(event, "scancode", -1) == getattr(pygame, "KSCAN_O", -2)):
                        o_ability(current_tick)   # 2.0.1 개발자 동전 / 2.4 꼰대 동전
                    elif event.key == pygame.K_i or getattr(event, "scancode", -1) == getattr(pygame, "KSCAN_I", -2):
                        bat_item_use(current_tick)   # 2.4 빠따 아이템

        if game_state == "PLAYING":
            cfg = diff_settings.get(difficulty, diff_settings["normal"])
            slow_mult = SLOW_FACTOR if player.slow_active else 1.0

            render_count += 1
            _fps_frame_accum += 1
            if current_tick - _fps_timer_start >= 1000:
                fps_current = _fps_frame_accum
                fps_avg = fps_current if fps_avg == 0 else int(fps_avg * 0.7 + fps_current * 0.3)
                _fps_frame_accum = 0
                _fps_timer_start = current_tick

            elapsed_time = current_tick - start_ticks
            if score >= 1119: unlock_achievement("score_1119")   # 2.0.1: 닿는 순간 바로 해금

            # 무한모드/스피드런 시간 계산
            if endless_mode or speedrun_mode:
                time_left = int(elapsed_time / 1000)
            else:
                time_left = max(0, int((cfg["time"] * 1000 - elapsed_time) / 1000))
        
            # 무한모드/스피드런 난이도 업데이트
            if endless_mode:
                spd, chance = update_endless_difficulty(elapsed_time)
                cfg = dict(cfg)
                cfg["max_ob_spd"] = spd
                cfg["ob_chance"] = chance
        
            # 스피드런: 100점 도달하면 끝
            if speedrun_mode and score >= SPEEDRUN_GOAL:
                end_game(survived=True)
            elif speedrun_mode and elapsed_time >= cfg["time"] * 1000:
                end_game(survived=False, timeout=True)

            # 스피드런 미션 해금: 순환참조 방지 - 아무 난이도든 30초 내 1000점 달성시 실시간 체크
            if elapsed_time <= 30000 and score >= 1000:
                if unlock_mission("unlock_speedrun"):
                    flush_missions()
        
            # 일반 난이도: 시간 종료
            if not endless_mode and not speedrun_mode and elapsed_time >= cfg["time"] * 1000:
                end_game(survived=True)

            if game_state == "PLAYING":  # 게임오버 전환 직후 같은 프레임에서 이동/스폰/충돌이 더 진행되던 문제 수정
                keys = pygame.key.get_pressed()
                dx = (1 if keys[pygame.K_RIGHT] else 0) - (1 if keys[pygame.K_LEFT] else 0)
                dy = (1 if keys[pygame.K_DOWN] else 0) - (1 if keys[pygame.K_UP] else 0)
                tdx, tdy = touch_move()   # 2.4 터치 조이스틱 (키보드와 같은 8방향)
                if tdx or tdy: dx, dy = tdx, tdy
                if difficulty == "adversity":  # 역경 모드: 조작키 반전
                    dx = -dx
                    dy = -dy
                if player.tot_trick == "invert":  # 2.0.2 트릭: 조작 반전 (역경 모드와 겹치면 서로 상쇄)
                    dx = -dx
                    dy = -dy
                if dx != 0 and dy != 0:
                    dx *= 0.7071
                    dy *= 0.7071
                if equipped_skin == "uncle" and current_tick >= uncle_roll_at:  # 삼촌: 이동속도 주기적 재추첨
                    uncle_speed_mult = random.uniform(*UNCLE_SPEED_RANGE); uncle_roll_at = current_tick + UNCLE_ROLL_MS
                eff_spd = PLAYER_SPD * 2 if ach_unlocked.get("dev_streak_3") else PLAYER_SPD
                eff_spd = eff_move_speed(eff_spd)
                player.x += dx * eff_spd * dt_scale
                player.y += dy * eff_spd * dt_scale
                right_extra = TWIN_GAP if is_twins() else 0  # 쌍둥이: 한 덩어리로 취급, 가장 오른쪽 몸체 기준으로 벽 판정
                player.x = min(max(player.x, PLAYER_R), WIDTH - PLAYER_R - right_extra)
                player.y = min(max(player.y, PLAYER_R), HEIGHT - PLAYER_R)

                # 되감기용 위치 기록 (최근 REWIND_LOOKBACK_MS + 여유분만 유지)
                player.pos_history.append((current_tick, player.x, player.y))
                while player.pos_history and current_tick - player.pos_history[0][0] > REWIND_LOOKBACK_MS + 500:
                    player.pos_history.pop(0)

                if player.magnet_active and current_tick > player.magnet_end_tick:
                    player.magnet_active = False
                if player.slow_active and current_tick > player.slow_end_tick:
                    player.slow_active = False
                if player.kimchi_active and current_tick > player.kimchi_end_tick:
                    player.kimchi_active = False
                if player.freeze_active and current_tick > player.freeze_end_tick:
                    player.freeze_active = False
                if player.goldrush_active and current_tick > player.goldrush_end_tick:
                    player.goldrush_active = False
                if player.minime_active and current_tick > player.minime_end_tick:
                    player.minime_active = False
                if player.l_active and current_tick > player.l_end_tick:
                    player.l_active = False
                if player.kk_active and current_tick > player.kk_end_tick:
                    player.kk_active = False
                bubble_tick(current_tick)
                if player.tot_trick and current_tick > player.tot_end_tick:
                    player.tot_trick = None
                if player.combo > 0 and current_tick - last_coin_time > eff_combo_window_ms():
                    if sister_save_combo(): last_coin_time = current_tick  # 누나: 면역으로 콤보 유지시간 새로 시작
                    else: reset_combo()

                if cheat_on:  # 똥쩐꼐임: 매 프레임 코인
                    spawn_coin(cfg["coin_diff"], current_tick)
                else:
                    coin_spawn_rolls = GOLDRUSH_COIN_ROLLS if player.goldrush_active else 1  # 골드러시: 코인 스폰 시도 증가
                    for _ in range(coin_spawn_rolls):
                        if random.random() < dt_scale / 5:  # FPS 설정과 무관하게 초당 스폰 확률 고정
                            spawn_coin(cfg["coin_diff"], current_tick)

                if cfg["ob_spawn"] and random.random() < dt_scale / cfg["ob_chance"]:  # FPS 설정과 무관하게 초당 스폰 확률 고정
                    spawn_obstacle(cfg["max_ob_spd"], current_tick)

                if random.random() < dt_scale / ITEM_SPAWN_CHANCE:  # FPS 설정과 무관하게 초당 스폰 확률 고정
                    items.append({"x": float(WIDTH + 100), "y": random.randint(50, HEIGHT - 50),
                                  "type": choose_item_type()})

                if player.magnet_active or equipped_skin == "puppy":  # 반려동전: 자석 아이템 없이도 약한 자석 상시 작동
                    mag_range = eff_magnet_range() * (PUPPY_MAGNET_RATIO if not player.magnet_active else 1)
                    bodies = player_bodies()  # 쌍둥이: 몸체별 사거리, 가까운 쪽으로 끌려감
                    for coin in coins:
                        if coin["kind"] == "bomb": continue  # 폭탄 코인은 자석에 끌려오지 않음
                        dist, bx, by = min((math.hypot(bx_ - coin["x"], by_ - coin["y"]), bx_, by_) for bx_, by_ in bodies)
                        if dist < mag_range:
                            pull = 7 * slow_mult * dt_scale
                            coin["x"] += ((bx - coin["x"]) / (dist + 0.1)) * pull
                            coin["y"] += ((by - coin["y"]) / (dist + 0.1)) * pull

                for coin in coins:
                    coin["x"] -= coin["speed"] * slow_mult * dt_scale
                coins = [c for c in coins if c["x"] > -100 and not (c["kind"] == "gold" and current_tick >= c["expire"])]

                update_splits(current_tick)  # 분열 카운트는 타임프리즈 중에도 계속 진행
                if not player.freeze_active:  # 타임프리즈: 장애물 정지 (지그재그 흔들림도 같이 멈춤)
                    ob_mult = slow_mult * (TOT_FAST_MULT if player.tot_trick == "fast" else 1.0)   # 2.0.2 트릭: 장애물 가속
                    zz_dph = 2 * math.pi * (dt_scale / REFERENCE_FPS) / ZIGZAG_PERIOD_SEC * ob_mult
                    turn_max = math.radians(L_TURN_DEG) * (dt_scale / REFERENCE_FPS) * ob_mult
                    l_bodies = player_bodies() if player.l_active else None
                    for ob in obstacles:
                        # L 아이템 중: 일반/지그재그/분열탄 본체는 플레이어 쪽으로 서서히 방향을 틂 (분열 조각은 제외). 끝나면 서서히 위쪽으로 복귀
                        if (player.l_active or "hd" in ob) and not (ob["kind"] == "split" and ob["gen"] > 0):
                            h = ob.get("hd", -math.pi / 2)
                            if player.l_active:
                                tx, ty = min(l_bodies, key=lambda b: (b[0] - ob["x"]) ** 2 + (b[1] - ob["y"]) ** 2)
                                want = math.atan2(ty - ob["y"], tx - ob["x"])
                            else:
                                want = -math.pi / 2
                            diff = (want - h + math.pi) % (2 * math.pi) - math.pi
                            h = want if abs(diff) <= turn_max else h + math.copysign(turn_max, diff)
                            if not player.l_active and h == want: ob.pop("hd", None)
                            else: ob["hd"] = h
                            v = ob["speed"] * ob_mult * dt_scale
                            if ob["kind"] == "zigzag": ob["bx"] += math.cos(h) * v   # 지그재그는 흔들림의 기준선(bx)을 옮김
                            else: ob["x"] += math.cos(h) * v
                            ob["y"] += math.sin(h) * v
                        else:
                            ob["y"] -= ob["speed"] * ob_mult * dt_scale
                        if ob["kind"] == "zigzag":  # 사인파 좌우 흔들림 (슬로우 중엔 위상도 같이 느려짐)
                            ob["ph"] += zz_dph
                            ob["x"] = ob["bx"] + ZIGZAG_AMP * math.sin(ob["ph"])
                if player.kk_active and not player.freeze_active: kk_push(player_bodies(), dt_scale, slow_mult)   # 2.4 꼰대 동전
                # 분열 조각은 회피 횟수에 넣지 않음 (한 번 쪼개진 탄이 여러 번 세어지는 것 방지)
                dodged = sum(1 for o in obstacles if o["y"] <= -100 and not (o["kind"] == "split" and o["gen"] > 0))
                if dodged:
                    if add_mission_counter("total_obstacles_dodged", dodged) >= 300:
                        unlock_mission("unlock_timefreeze")
                obstacles = [o for o in obstacles if o["y"] > -100]
                obstacles = [o for o in obstacles if not ("hd" in o and (o["x"] < -200 or o["x"] > WIDTH + 200 or o["y"] > HEIGHT + 300))]   # 2.0.1: 방향이 틀어져 멀리 벗어난 장애물 정리

                for item in items:
                    item["x"] -= 5 * slow_mult * dt_scale
                items = [i for i in items if i["x"] > -100]

                for coin in coins[:]:
                    if player_dist(coin["x"], coin["y"]) < (eff_player_r() + coin["r"]):
                        if coin["kind"] == "bomb":  # 폭탄 코인: 점수 없음, 콤보 초기화 (누나 면역이 있으면 1회 소모하고 콤보 유지)
                            bpos, had_combo = (coin["x"], coin["y"]), player.combo
                            coins.remove(coin)
                            immune = sister_save_combo()
                            if not immune: reset_combo()
                            fx_bomb_pickup(bpos, had_combo, immune, current_tick)
                            continue
                        if current_tick - last_coin_time > eff_combo_window_ms() and not sister_save_combo():
                            player.combo = 0
                        player.combo += 1
                        last_coin_time = current_tick
                        gain = 1 + player.combo // eff_combo_bonus_step()
                        g = gain * GOLD_COIN_SCORE_MULT if coin["kind"] == "gold" else gain
                        score += g
                        fx_coin_pickup((coin["x"], coin["y"]), g, coin["kind"] == "gold", current_tick)
                        coins.remove(coin)

                        total = add_counter("total_coins")
                        if total >= 1: unlock_achievement("first_coin")
                        if total >= 1000: unlock_achievement("coin_1000")
                        if total >= 5000: unlock_mission("unlock_goldrush")
                        if player.magnet_active:
                            if add_counter("total_magnet_coins") >= 500: unlock_achievement("magnet_500")
                        if player.combo >= 30: unlock_mission("unlock_goldcoin")
                        if player.combo >= 50: unlock_mission("unlock_bombcoin")
                        if player.combo >= 20: unlock_achievement("combo_20")
                        if player.combo >= 50: unlock_achievement("combo_50")
                        if player.combo >= 100: unlock_achievement("combo_100")

                for item in items[:]:
                    if player_dist(item["x"], item["y"]) < (eff_player_r() + 12):
                        itype = item["type"]  # 't'로 쓰면 번역 함수 t()를 덮어써서 크래시 발생
                        if itype == "magnet":
                            # 1.8 밸런스: 골드러시 중에는 이미 떠 있던 자석을 먹어도 효과 없음 (치트는 예외)
                            if not (player.goldrush_active and not cheat_on):
                                player.magnet_active = True
                                player.magnet_end_tick = current_tick + (CHEAT_MAGNET_MS if cheat_on else eff_item_duration_ms(MAGNET_DURATION_MS))
                        elif itype == "slow":
                            player.slow_active = True
                            player.slow_end_tick = current_tick + eff_item_duration_ms(SLOW_DURATION_MS)
                        elif itype == "shield":
                            player.shield_count += 1
                            if player.shield_count >= 3: unlock_achievement("shield_3")
                        elif itype == "heal":
                            player.hp += 1
                        elif itype == "kimchi":
                            player.kimchi_active = True
                            player.kimchi_end_tick = current_tick + eff_item_duration_ms(KIMCHI_DURATION_MS)
                            player.session_kimchi_used = True
                            if add_counter("total_kimchi") >= 100: unlock_achievement("kimchi_100")
                        elif itype == "timefreeze":
                            player.freeze_active = True
                            player.freeze_end_tick = current_tick + eff_item_duration_ms(NEW_ITEM_DURATION_MS)
                        elif itype == "goldrush":
                            player.goldrush_active = True
                            player.goldrush_end_tick = current_tick + eff_item_duration_ms(NEW_ITEM_DURATION_MS)
                            if not cheat_on:  # 1.8 밸런스: 골드러시를 먹는 순간 활성 중인 자석 효과를 끊음 (치트는 예외)
                                player.magnet_active = False
                        elif itype == "minime":
                            player.minime_active = True
                            player.minime_end_tick = current_tick + eff_item_duration_ms(NEW_ITEM_DURATION_MS)
                        elif itype == "rewind":
                            player.rewind_charges += 1
                        elif itype == "l":   # 2.0.1: 다시 먹으면 16초와 자막이 처음부터 다시 시작
                            player.l_active = True
                            player.l_start_tick = current_tick
                            player.l_end_tick = current_tick + L_DURATION_MS
                        elif itype == "bat":   # 2.4 빠따
                            player.bat_count = BAT_ITEM_USES
                        elif itype == "tot":   # 2.0.2 트릭 오어 트릿
                            score += resolve_tot(item["x"], item["y"], current_tick)
                        fx_item_pickup(itype, (item["x"], item["y"]), current_tick)
                        items.remove(item)

                for ob in obstacles[:]:
                    if player_dist(ob["x"], ob["y"]) < (eff_player_r() + ob["r"]):
                        if current_tick < player.dodge_until: continue   # 2.4 정윤재 샨셴부
                        if hit_ignore_chance(equipped_skin) > 0:  # 삼촌 / 송윤채: 장애물마다 한 번만 추첨해 무시 여부 결정
                            if "ignore" not in ob:
                                ob["ignore"] = random.random() < hit_ignore_chance(equipped_skin)
                            if ob["ignore"]:
                                continue
                        if player.rewind_charges > 0:
                            target = None
                            for tck, px, py in reversed(player.pos_history):
                                if current_tick - tck >= REWIND_LOOKBACK_MS:
                                    target = (px, py)
                                    break
                            if target:
                                player.x, player.y = target
                            player.rewind_charges -= 1
                            obstacles.remove(ob)
                            continue  # 되감기로 회피 - 데미지 없음, 다음 장애물 계속 검사
                        obstacles.remove(ob)
                        if current_tick - last_hit_time >= INV_SEC:
                            last_hit_time = current_tick
                            if player.kimchi_active:
                                pass
                            elif player.shield_count > 0:
                                player.shield_count -= 1
                                fx_shield_block(current_tick)
                                player.session_shield_used = True  # 실제로 피해를 막았을 때만 '사용'으로 판정
                            elif bubble_block(current_tick):
                                fx_shield_block(current_tick)
                            else:
                                player.hp -= 1
                                fx_hit(current_tick)
                                player.session_hits += 1
                                if add_counter("total_hits") >= 1: unlock_achievement("first_hit")
                                player.combo_hit_count += 1
                                if player.combo_hit_count >= 2:
                                    if sister_save_combo(): player.combo_hit_count = 0
                                    else: reset_combo()
                                if player.hp <= 0:
                                    fx_flash_start = current_tick
                                    end_game()

        if net_playing or game_state in ("ONLINE_WAIT", "ONLINE_ROOM", "ONLINE_PLAY", "ONLINE_RESULT", "ONLINE_SPEC", "ONLINE_SPEC_RESULT"):   # 2.2 온라인: 받은 메시지 처리
            net_update(current_tick)
        if admin_pending or game_state == "ADMIN":   # 2.2 관리자 요청 결과 처리
            admin_poll(current_tick)
        if rank_reqs or (game_state == "HIGHSCORE" and rank_tab == "online"):   # 2.3 온라인 랭킹
            rank_update(current_tick)
        game_status_update(current_tick)   # 2.4 게임 전체 닫기 확인

        if game_state == "VS_COUNTDOWN":   # 2.1 대결
            update_vs_countdown(current_tick)
        elif game_state == "VERSUS":
            if net_playing: online_host_step(current_tick, dt_scale)   # 2.2 온라인 방장
            else: update_versus(current_tick, dt_scale)

        screen.fill(bg_color())
        fx_draw_flash(current_tick)

        if game_state == "MAIN":
            draw_text_center(screen, font_large, t("title"), WHITE, (WIDTH // 2, 100))
            for btn in main_buttons:
                btn.draw(screen)
            if anniv_now():   # 2.4 1주년 기념 배너
                draw_text_center(screen, font_mid, t("anniv_title"), (255, 200, 90), (WIDTH // 2, 28))
            v_txt = font_small.render("ver 2.4 ANNIVERSARY", True, WHITE)
            screen.blit(v_txt, v_txt.get_rect(bottomright=(WIDTH - 10, HEIGHT - 8)))

        elif game_state == "DIFF_SELECT":
            draw_text_center(screen, font_large, t("difficulty_title"), WHITE, (WIDTH // 2, 80))
            for btn in diff_buttons:
                btn.draw(screen)
            for btn in diff_buttons_back:
                btn.draw(screen)
            if diff_select_status:
                draw_text_center(screen, font_small, diff_select_status, YELLOW, (WIDTH // 2, 430))

        elif game_state == "MODE_SELECT":
            draw_text_center(screen, font_large, t("mode_title"), WHITE, (WIDTH // 2, 70))
            for btn in mode_select_buttons:
                btn.draw(screen)
            if mode_select_status:
                draw_text_center(screen, font_small, mode_select_status, YELLOW, (WIDTH // 2, 400))

        elif game_state == "UPDATE_INFO":
            y_offset = 46
            for line_key, is_header in UPDATE_INFO_LINES:
                color = YELLOW if is_header else WHITE
                text_lines = (t(line_key) if line_key else "").split("\n")  # 문장 안의 줄바꿈(\n)마다 한 줄씩 그림
                for sub_line in text_lines:
                    draw_text_center(screen, font_small, sub_line, color, (WIDTH // 2, y_offset))
                    y_offset += 22
            for btn in info_buttons:
                btn.draw(screen)

        elif game_state in ("HOWTO", "HISTORY"):
            prefix, total, btns = (("howto", HOWTO_PAGES, howto_buttons) if game_state == "HOWTO"
                                   else ("history", HISTORY_PAGES, history_buttons))
            draw_text_center(screen, font_large, t(prefix), WHITE, (WIDTH // 2, 40))
            y_offset = 82
            for line in wrap_text(font_buff, t(f"{prefix}_p{page_idx[game_state] + 1}"), WIDTH - 120):
                if line:
                    screen.blit(font_buff.render(line, True, YELLOW if line.startswith("[") else WHITE), (60, y_offset))
                y_offset += 21
            draw_text_center(screen, font_small, f"{page_idx[game_state] + 1} / {total}", YELLOW, (WIDTH // 2, 424))
            for btn in btns:
                btn.draw(screen)

        elif game_state == "CREDITS":
            draw_text_center(screen, font_large, t("credits"), WHITE, (WIDTH // 2, 40))
            y_offset = 100
            for line in wrap_text(font_small, t("credits_body", ver=VERSION_NUMBER), WIDTH - 120):
                if line:
                    draw_text_center(screen, font_small, line, WHITE, (WIDTH // 2, y_offset))
                y_offset += 28
            for btn in credits_buttons:
                btn.draw(screen)

        elif game_state == "HIGHSCORE":
            draw_text_center(screen, font_large, t("highscore"), WHITE, (WIDTH // 2, 70))
            hs = load_highscores()
            y_offset = 105
            rank_draw_tabs()
            if rank_tab == "online":
                rank_draw_online(pygame.time.get_ticks())
            elif rank_tab == "hall":
                rank_draw_hall(pygame.time.get_ticks())
            else:
                for d in REVEALED_DIFFICULTIES:
                    if d == "speedrun":
                        sv = hs.get(d, 0)
                        line = f"{diff_label(d)} : {t('no_record') if sv == 0 else str(sv) + t('sec_unit')}"
                    else:
                        line = f"{diff_label(d)} : {hs.get(d, 0)}{t('no_score')}"
                    draw_text_center(screen, font_small, line, WHITE, (WIDTH // 2, y_offset))
                    y_offset += 32
            for btn in highscore_buttons:
                btn.draw(screen)

        elif game_state == "ACHIEVEMENTS":
            draw_text_center(screen, font_large, t("achievements"), WHITE, (WIDTH // 2, 40))
            left_cats = CATEGORY_ORDER[:3]
            right_cats = CATEGORY_ORDER[3:]

            def draw_category_column(cats, cx, y0):
                y = y0
                for cat in cats:
                    draw_text_center(screen, font_mid, f"[{cat_label(cat)}]", WHITE, (cx, y)); y += 26
                    cat_items = [(aid, name_dict, hidden) for aid, (name_dict, c2, hidden) in ACHIEVEMENTS.items() if c2 == cat]
                    next_shown = False
                    for aid, name_dict, hidden in cat_items:
                        done = ach_unlocked.get(aid, False)
                        name = name_dict[lang]
                        if done:
                            line, col = f"v {name}", (120, 255, 120)
                        elif hidden:
                            line, col = t("hidden_achv"), GRAY
                        elif not next_shown:
                            line, col = f"- {name} ({t('next_goal')})", YELLOW
                            next_shown = True
                        else:
                            line, col = "???", GRAY
                        draw_text_center(screen, font_small, line, col, (cx, y)); y += 20
                    y += 10
                return y

            draw_category_column(left_cats, WIDTH // 2 - 200, 90)
            draw_category_column(right_cats, WIDTH // 2 + 200, 90)

            unlocked_n = sum(1 for k_, v in ach_unlocked.items() if v and not k_.startswith("code_"))
            draw_text_center(screen, font_mid, t("achv_progress", n=unlocked_n, total=len(ACHIEVEMENTS)), WHITE, (WIDTH // 2, HEIGHT - 70))
            for btn in achievements_buttons:
                btn.draw(screen)

        elif game_state == "MISSIONS":
            draw_text_center(screen, font_large, t("missions"), WHITE, (WIDTH // 2, 40))

            def draw_mission_column(cat, cx, y0):
                y = y0
                draw_text_center(screen, font_mid, f"[{cat_label(cat)}]", WHITE, (cx, y)); y += 30
                cat_items = [(mid, name_dict, cond_dict) for mid, (name_dict, c2, cond_dict) in MISSIONS.items() if c2 == cat]
                for mid, name_dict, cond_dict in cat_items:
                    done = mission_unlocked.get(mid, False)
                    name, cond = name_dict[lang], cond_dict[lang]
                    if done:
                        draw_text_center(screen, font_small, f"v {name}", (120, 255, 120), (cx, y)); y += 20
                        draw_text_center(screen, font_small, f"({cond})", GRAY, (cx, y)); y += 28
                    elif cat == "모드":
                        draw_text_center(screen, font_small, f"- {t('mode_hidden')}", YELLOW, (cx, y)); y += 28
                    else:
                        draw_text_center(screen, font_small, f"- {name}", YELLOW, (cx, y)); y += 20
                        draw_text_center(screen, font_small, f"({cond})", GRAY, (cx, y)); y += 28

            draw_mission_column("아이템", WIDTH // 2 - 200, 90)
            draw_mission_column("모드", WIDTH // 2 + 200, 90)
            # 1.8: 신규 장애물/코인 - 모드 열 아래에 한 줄씩 (영문에서도 옆 열과 겹치지 않도록)
            ny = 278
            draw_text_center(screen, font_mid, f"[{cat_label('신규')}]", WHITE, (WIDTH // 2 + 200, ny)); ny += 26
            for mid, (name_dict, c2, cond_dict) in MISSIONS.items():
                if c2 != "신규": continue
                done = mission_unlocked.get(mid, False)
                line = f"{'v' if done else '-'} {name_dict[lang]} ({cond_dict[lang]})"
                draw_text_center(screen, font_buff, line, (120, 255, 120) if done else YELLOW, (WIDTH // 2 + 200, ny)); ny += 20

            mission_n = sum(1 for v in mission_unlocked.values() if v)
            draw_text_center(screen, font_mid, t("achv_progress", n=mission_n, total=len(MISSIONS)), WHITE, (WIDTH // 2, HEIGHT - 70))
            for btn in mission_buttons:
                btn.draw(screen)

        elif game_state == "SKINS":
            draw_text_center(screen, font_large, t("family"), WHITE, (WIDTH // 2, 32))
            for i, sid in enumerate(SKIN_ORDER):
                if i // SKIN_PER_PAGE != skin_page: continue
                y = SKIN_ROW_Y0 + (i % SKIN_PER_PAGE) * SKIN_ROW_STEP
                info = SKIN_MAP[sid]
                unlocked = is_skin_unlocked(sid)
                mark = f" {t('equipped')}" if sid == equipped_skin else ""
                skin_label = info["label"][lang]
                if sid == HIDDEN_SKIN and not unlocked: skin_label = "???"   # 2.0.1: 숨겨진 스킨
                if unlocked:
                    label, col = f"{skin_label}{mark}", (120, 255, 120) if sid == equipped_skin else WHITE
                    sub = f"{t('ability')}: {info['ability'][lang]}"
                else:
                    req_name = ach_name(info["unlock"])
                    label, col = f"\U0001F512 {skin_label}", GRAY
                    sub = "???" if sid == HIDDEN_SKIN else f"{t('unlock_cond')}: {t('unlock_achv_of', name=req_name)}"
                    if info.get("code"):   # 2.4 고유 스킨: 이름은 숨기고 코드 안내
                        label, sub = "\U0001F512 ???", t("code_locked")
                pv = info.get("preview_key", info["image_key"])  # 스킨 이미지 미리보기 (잠긴 스킨은 실루엣)
                pv_surf = img.get(pv if unlocked else "sil_" + pv)
                if pv_surf:
                    screen.blit(pv_surf, pv_surf.get_rect(center=(48, y + 8)))
                lt = font_mid.render(label, True, col)
                screen.blit(lt, lt.get_rect(midleft=(84, y)))
                st = font_small.render(sub, True, GRAY)
                screen.blit(st, st.get_rect(midleft=(84, y + 20)))
            if SKIN_PAGES > 1:
                draw_text_center(screen, font_buff, f"{skin_page + 1} / {SKIN_PAGES}", YELLOW, (WIDTH // 2, SKIN_NAV_Y))
            for btn in visible_skin_buttons():
                btn.draw(screen)
            if code_edit:
                pygame.draw.rect(screen, (0, 0, 60), (WIDTH // 2 - 230, 190, 460, 110), border_radius=10)
                pygame.draw.rect(screen, WHITE, (WIDTH // 2 - 230, 190, 460, 110), 2, border_radius=10)
                draw_text_center(screen, font_small, t("code_prompt"), YELLOW, (WIDTH // 2, 214))
                box = pygame.Rect(WIDTH // 2 - 190, 238, 380, 40)
                pygame.draw.rect(screen, BLACK, box); pygame.draw.rect(screen, WHITE, box, 2)
                draw_text_center(screen, font_mid, code_buf + ("_" if (current_tick // 400) % 2 == 0 else ""), WHITE, box.center)
            if current_tick < code_msg_until:
                draw_text_center(screen, font_mid, code_msg, (120, 255, 120) if t("code_bad") != code_msg else RED, (WIDTH // 2, 400))

        elif game_state == "SETTINGS":
            draw_text_center(screen, font_large, t("settings_title"), WHITE, (WIDTH // 2, 60))
            for row_y, row_txt in zip(SET_ROW_Y, [f"{t('volume')}: {int(volume*100)}%", t('bgm'),
                                                  f"{t('max_frame')}: {FPS} FPS",
                                                  f"{t('language')}: {'한국어' if lang == 'ko' else 'English'}",
                                                  t('twisted_content'), t('anim_label'), t('halloween_content'),
                                                  f"{t('net_rate')}: {net_rate}{t('net_rate_unit')}"]):
                lbl = font_mid.render(row_txt, True, WHITE)
                screen.blit(lbl, lbl.get_rect(midleft=(SET_LABEL_X, row_y)))
            desc = font_small.render(t('twisted_desc'), True, (150, 150, 150))
            screen.blit(desc, desc.get_rect(midleft=(SET_LABEL_X, SET_ROW_Y[4] + 26)))
            desc2 = font_small.render(t('halloween_desc'), True, (150, 150, 150))   # 2.0.2
            screen.blit(desc2, desc2.get_rect(midleft=(SET_LABEL_X, SET_ROW_Y[6] + 26)))
            for btn in settings_buttons:
                btn.draw(screen)

        elif game_state == "PLAYING":
            p_key = SKIN_MAP.get(equipped_skin, SKIN_MAP["normal"])["image_key"]
            if player.shield_count > 0:
                skin_key = f"p_{equipped_skin}_shield"
                p_key = skin_key if img.get(skin_key) else "p_shield"
            if player.kimchi_active:
                skin_key = f"p_{equipped_skin}_kimchi"
                p_key = skin_key if img.get(skin_key) else "p_kimchi"
            p_color = RED if p_key == "p_normal" else (GRAY if "shield" in p_key else ORANGE)
            blink_hide = anim_on and current_tick < fx_blink_until and (current_tick // 80) % 2 == 1   # 피격 후 무적시간 깜빡임
            for bx, by in ([] if blink_hide else player_bodies()):
                draw_sprite_or_fallback(
                    p_key, bx, by,
                    lambda bx=bx, by=by: pygame.draw.circle(screen, p_color, (int(bx), int(by)), PLAYER_R)
                )
            if equipped_skin == "submarine" and not blink_hide: draw_bubble(player.x, player.y, player.bubble, player.bubble_at, current_tick)
            draw_cast(player, current_tick)

            for coin in coins:
                if coin["kind"] == "gold":
                    if coin["expire"] - current_tick <= GOLD_COIN_BLINK_MS and (current_tick // 100) % 2:
                        continue  # 사라지기 직전 1초는 깜빡임
                    draw_sprite_or_fallback(
                        "coin_gold", coin["x"], coin["y"],
                        lambda c=coin: pygame.draw.circle(screen, (255, 215, 0), (int(c["x"]), int(c["y"])), c["r"])
                    )
                elif coin["kind"] == "bomb":
                    draw_sprite_or_fallback(
                        "coin_bomb", coin["x"], coin["y"],
                        lambda c=coin: pygame.draw.circle(screen, (60, 60, 60), (int(c["x"]), int(c["y"])), c["r"])
                    )
                else:
                    draw_sprite_or_fallback(
                        "coin", coin["x"], coin["y"],
                        lambda c=coin: pygame.draw.circle(screen, ORANGE, (int(c["x"]), int(c["y"])), c["r"])
                    )

            for ob in obstacles:
                if cfg["inv_obs"]:
                    rect_obj = pygame.Rect(ob["x"] - ob["r"], ob["y"] - ob["r"], ob["r"] * 2, ob["r"] * 2)
                    pygame.draw.rect(screen, bg_color(), rect_obj, 1)
                else:
                    if ob["kind"] == "zigzag":
                        ob_key, ob_col = ob_img("ob_zigzag"), (80, 230, 80)
                    elif ob["kind"] == "split":
                        ob_key, ob_col = ob_img(f"ob_split_{ob['gen']}"), (230, 70, 70)
                    else:
                        ob_key, ob_col = ob_img("obstacle"), YELLOW
                    draw_sprite_or_fallback(
                        ob_key, ob["x"], ob["y"],
                        lambda o=ob, col=ob_col: pygame.draw.rect(
                            screen, col,
                            pygame.Rect(o["x"] - o["r"], o["y"] - o["r"], o["r"] * 2, o["r"] * 2)
                        )
                    )

            for item in items:
                key = f"item_{item['type']}"
                color = FALLBACK_COLOR.get(key, WHITE)
                draw_sprite_or_fallback(
                    key, item["x"], item["y"],
                    lambda it=item, col=color: pygame.draw.circle(screen, col, (int(it["x"]), int(it["y"])), 12)
                )

            fx_draw(current_tick)

            if endless_mode:
                t_color = WHITE
            elif speedrun_mode:
                t_color = RED if time_left >= diff_settings["speedrun"]["time"] - 5 else WHITE
            else:
                t_color = RED if time_left < 6 else WHITE
            draw_text_center(screen, font_small, "TIME", t_color, (50, 30))
            draw_text_center(screen, font_mid, str(time_left), t_color, (50, 50))

            draw_text_center(screen, font_small, "SCORE", WHITE, (150, 30))
            draw_text_center(screen, font_mid, str(score), WHITE, (150, 50))

            hp_color = RED if player.hp < 2 else WHITE
            draw_text_center(screen, font_small, "HP", hp_color, (200, 30))
            draw_text_center(screen, font_mid, str(player.hp), hp_color, (200, 50))

            if player.combo >= 2:
                bonus = player.combo // eff_combo_bonus_step()
                txt = f"COMBO x{player.combo}" + (f" (+{bonus})" if bonus > 0 else "") + (f" [{t('hud_immune')} {player.sister_charges}]" if equipped_skin == "sister" else "")
                popping = False
                if anim_on:   # 콤보 마일스톤(10/25/50/100): 콤보 글자가 잠깐 커졌다 돌아옴
                    for m in COMBO_MILESTONES:
                        if player.combo >= m > fx_milestone_done:
                            fx_milestone_done = m; fx_combo_pop_until = current_tick + 300
                    popping = current_tick < fx_combo_pop_until
                draw_text_center(screen, font_pop if popping else font_buff, txt, YELLOW, (400, 30))
            else:
                fx_milestone_done = 0
            draw_hud_icons(current_tick)

            if player.l_active and not player.kk_active:   # 2.0.1: L 아이템 자막 (2.4: 꼰대 동전 자막이 우선) (줄당 2초, 'L을 가져가' 줄은 노랑, 마지막 줄은 초록)
                cap_i = min(len(L_CAPTIONS) - 1, int((current_tick - player.l_start_tick) // L_LINE_MS))
                cap_col = (120, 255, 120) if cap_i == len(L_CAPTIONS) - 1 else (YELLOW if cap_i % 2 == 0 else WHITE)
                draw_text_center(screen, font_cap, L_CAPTIONS[cap_i], BLACK, (WIDTH // 2 + 2, HEIGHT - 40))
                draw_text_center(screen, font_cap, L_CAPTIONS[cap_i], cap_col, (WIDTH // 2, HEIGHT - 42))
            if player.tot_trick:   # 2.0.2: 트릭 오어 트릿 안내 (트릭은 걸려 있는 동안, 트릿은 TOT_MSG_MS)
                tot_txt = f"{t('tot_trick_' + player.tot_trick)}  ({max(0, player.tot_end_tick - current_tick) / 1000:.1f})"
                draw_text_center(screen, font_buff, tot_txt, BLACK, (WIDTH // 2 + 1, HEIGHT - 75))
                draw_text_center(screen, font_buff, tot_txt, (230, 150, 255), (WIDTH // 2, HEIGHT - 76))
            elif current_tick < player.tot_msg_until:
                draw_text_center(screen, font_buff, player.tot_msg, BLACK, (WIDTH // 2 + 1, HEIGHT - 75))
                draw_text_center(screen, font_buff, player.tot_msg, ORANGE, (WIDTH // 2, HEIGHT - 76))
            if player.kk_active:   # 2.4: 꼰대 동전 자막 (줄당 2초)
                kc = min(len(KK_CAPTIONS) - 1, int((current_tick - player.kk_start_tick) // KK_LINE_MS))
                draw_text_center(screen, font_cap, KK_CAPTIONS[kc], BLACK, (WIDTH // 2 + 2, HEIGHT - 40))
                draw_text_center(screen, font_cap, KK_CAPTIONS[kc], (255, 200, 90), (WIDTH // 2, HEIGHT - 42))
            if equipped_skin == "submarine":   # 2.4: 거품 상태 표시
                if player.bubble: bb_txt, bb_col = t("bubble_on", n=player.bubble_left), (120, 220, 255)
                elif player.bubble_at: bb_txt, bb_col = t("bubble_reload", sec=f"{max(0, player.bubble_at - current_tick) / 1000:.1f}"), GRAY
                else: bb_txt, bb_col = t("bubble_none"), GRAY
                draw_text_center(screen, font_small, bb_txt, bb_col, (WIDTH - 80, 30))
            if skin_has_o(equipped_skin):   # 2.0.1: O 키 쿨타임 표시 (개발자/꼰대)
                dev_left = player.dev_cd_until - current_tick
                if dev_left > 0:
                    draw_text_center(screen, font_small, t("dev_cd", sec=f"{dev_left / 1000:.1f}"), GRAY, (WIDTH - 80, 30))
                else:
                    draw_text_center(screen, font_small, t("dev_ready"), (120, 255, 120), (WIDTH - 80, 30))

            if current_tick < achievement_toast_until:
                draw_text_center(screen, font_buff, achievement_toast_msg, YELLOW, (WIDTH // 2, 110))
            elif newly_unlocked_queue:
                aid = newly_unlocked_queue.pop(0)
                achievement_toast_msg = t("achv_unlocked_toast", name=ach_name(aid))
                achievement_toast_until = current_tick + 2500
            elif newly_unlocked_mission_queue:
                mid = newly_unlocked_mission_queue.pop(0)
                achievement_toast_msg = t("mission_unlocked_toast", name=mission_name(mid))
                achievement_toast_until = current_tick + 2500

            if dev_mode:
                update_dev_info(current_tick)

        elif game_state == "PLAY_TYPE":
            draw_play_type()

        elif game_state == "MULTI_MENU":
            draw_multi_menu()

        elif game_state == "ONLINE_MENU":
            draw_online_menu(current_tick)

        elif game_state == "ONLINE_JOIN":
            draw_online_join(current_tick)

        elif game_state == "ONLINE_WAIT":
            draw_online_wait(current_tick)

        elif game_state == "ONLINE_ROOM":
            draw_online_room(current_tick)

        elif game_state == "ADMIN":
            draw_admin(current_tick)

        elif game_state == "CLOSED":
            draw_closed(current_tick)

        elif game_state == "ONLINE_PLAY":
            draw_online_guest(current_tick)

        elif game_state == "ONLINE_RESULT":
            draw_vs_result(online_result_buttons)

        elif game_state == "ONLINE_SPEC":
            draw_spec(current_tick)
            for btn in spec_buttons:
                btn.draw(screen)

        elif game_state == "ONLINE_SPEC_RESULT":
            draw_vs_result(spec_result_buttons)

        elif game_state == "VS_SETUP":
            draw_vs_setup(current_tick)

        elif game_state in ("VS_COUNTDOWN", "VERSUS"):
            draw_versus(current_tick, countdown=(game_state == "VS_COUNTDOWN"))

        elif game_state == "VS_RESULT":
            draw_vs_result()

        elif game_state == "GAMEOVER":
            if current_tick - gameover_entered_tick >= 10000:
                if unlock_achievement("gameover_stare"):
                    flush_achievements()
            draw_text_center(screen, font_large, t("game_over"), WHITE, (WIDTH // 2, HEIGHT // 2 - 60))

            if difficulty == "speedrun":
                res_text = t(speedrun_result_key, sec=speedrun_final_sec)
            else:
                res_text = t("score_result", score=score, rank=rank_for_score(score))
            draw_text_center(screen, font_mid, res_text, WHITE, (WIDTH // 2, HEIGHT // 2))
            if ach_unlocked.get("anniv_clear"):   # 2.4 기념 칭호 (기존 랭크 칭호 옆에)
                draw_text_center(screen, font_small, t("anniv_badge"), (255, 200, 90), (WIDTH // 2, HEIGHT // 2 - 28))

            if new_record:
                draw_text_center(screen, font_buff,
                                  t("new_record_msg", label=diff_label(new_record_diff_label)),
                                  YELLOW, (WIDTH // 2, HEIGHT // 2 + 30))
            if rank_gameover_msg:
                draw_text_center(screen, font_small, rank_gameover_msg, (120, 255, 120), (WIDTH // 2, HEIGHT // 2 + 49))

            for btn in gameover_buttons:
                btn.draw(screen)

            draw_text_center(screen, font_small, f"FPS:{fps_current}  AVG:{fps_avg}  RENDER:{render_count}",
                              WHITE, (WIDTH // 2, HEIGHT - 15))

        if cheat_on:
            draw_text_center(screen, font_small, "똥쩐꼐임 ON", YELLOW, (60, HEIGHT - 15))

        touch_draw()   # 2.4 터치 조이스틱/버튼 (맨 위에 그림)
        pygame.display.flip()


asyncio.run(main())
